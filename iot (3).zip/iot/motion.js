(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (reducedMotion.matches) return;

  const revealSelectors = [
    '.dashboard-intro',
    '.dashboard-header-context',
    '.dashboard-avatar',
    '.profile-avatar',
    '.sidebar-profile',
    '.dashboard-stat-card',
    '.home-card',
    '.home-preview-card',
    '.homes-card',
    '.home-room-tile',
    '.room-card',
    '.device-card',
    '.device-row',
    '.metric-card',
    '.energy-metric',
    '.trend-card',
    '.switch-row',
    '.energy-dashboard-card',
    '.energy-chart',
    '.chart-card',
    '.consumption-chart',
    '.camera-card',
    '.camera-preview',
    '.camera-preview-note',
    '.environment-card',
    '.weather-card',
    '.temperature-card',
    '.assistant-card',
    '.dashboard-primary-link',
    '.dashboard-side-link',
    '.mobile-tab',
    '.nav-item',
    '.project-card',
    '.project-row',
    '.automation-card',
    '.settings-category-card',
    '.settings-profile-banner',
    '.settings-panel',
    '.advanced-panel',
    '.homes-panel',
    '.panel',
    '[data-advanced-item]',
  ];
  const revealSelector = revealSelectors.join(',');
  const cardSelector = [
    '.dashboard-stat-card', '.home-card', '.home-preview-card', '.homes-card',
    '.home-room-tile', '.room-card', '.device-card', '.device-row',
    '.metric-card', '.energy-metric', '.trend-card', '.switch-row',
    '.energy-dashboard-card',
    '.energy-chart', '.chart-card', '.consumption-chart', '.camera-card',
    '.environment-card', '.weather-card', '.temperature-card',
    '.assistant-card', '.project-card', '.project-row', '.automation-card',
    '.settings-category-card', '.settings-panel', '.advanced-panel',
    '.homes-panel', '.panel',
    '[data-advanced-item]',
  ].join(',');
  const pageSelectors = [
    '#dashboard-content',
    '#device-management',
    '#device-detail-page',
    '#advanced-features',
    '#settings-module',
    '#homes-module',
  ];
  const routeHistories = new Map();
  let activeRoute = '';
  let activeSurface = null;
  let contentObserver = null;
  let pageEntranceTimer;

  const revealObserver = 'IntersectionObserver' in window
    ? new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 })
    : null;

  function isVisible(element) {
    return !element.hidden && getComputedStyle(element).display !== 'none'
      && element.getClientRects().length > 0;
  }

  function findSurface(route) {
    if (document.body.classList.contains('flow-dashboard')) {
      const visiblePage = pageSelectors
        .map((selector) => document.querySelector(selector))
        .find((element) => element && isVisible(element));
      return visiblePage || document.querySelector('#screen-dashboard');
    }

    if (document.body.classList.contains('flow-active')) {
      return document.querySelector('.flow-screen:not([hidden])');
    }

    if (!document.querySelector('#app-shell')?.hidden) {
      return document.querySelector('.view.active');
    }

    return document.querySelector(`#view-${CSS.escape(route)}`);
  }

  function identityFor(element, index) {
    const dataKey = [
      element.dataset.deviceCard,
      element.dataset.roomFilter,
      element.dataset.homeId,
      element.dataset.homeRoute,
      element.dataset.dashRoute,
      element.dataset.deviceId,
      element.dataset.advancedItem,
    ].filter(Boolean).join('|');
    const title = element.querySelector(
      'h1,h2,h3,.dashboard-stat-label,.room-card-copy b,.device-card-title h3,[data-motion-title]',
    )?.textContent.trim();
    const label = element.getAttribute('aria-label');
    const parentKey = element.parentElement?.id || element.parentElement?.className || '';
    const stableClasses = [...element.classList]
      .filter((name) => !name.startsWith('is-') && !name.startsWith('homiot-') && name !== 'active' && name !== 'selected')
      .sort()
      .join(' ');
    return `${parentKey}|${element.tagName}|${stableClasses}|${dataKey}|${title || label || index}`;
  }

  function animateReveals(surface) {
    if (!surface) return;
    const history = routeHistories.get(activeRoute);
    if (!history) return;
    const candidates = [];
    if (surface.matches?.(revealSelector)) candidates.push(surface);
    candidates.push(...surface.querySelectorAll(revealSelector));

    candidates.forEach((element, index) => {
      const identity = identityFor(element, index);
      if (history.has(identity)) return;
      history.add(identity);
      element.classList.add('homiot-reveal');
      element.style.setProperty('--homiot-delay', `${Math.min(index, 7) * 78}ms`);
      if (element.matches(cardSelector)) element.classList.add('homiot-card-float');

      if (revealObserver) {
        element.classList.remove('is-visible');
        revealObserver.observe(element);
      } else {
        element.classList.add('is-visible');
      }
    });
  }

  function transitionTo(route) {
    if (!route || route === activeRoute) {
      if (route && activeSurface) animateReveals(activeSurface);
      return;
    }
    activeRoute = route;
    routeHistories.set(route, new Set());

    const surface = findSurface(route);
    if (!surface) return;
    if (activeSurface && activeSurface !== surface) {
      activeSurface.classList.remove('homiot-page-enter');
    }
    activeSurface = surface;
    clearTimeout(pageEntranceTimer);
    surface.classList.remove('homiot-page-enter');
    void surface.offsetWidth;
    surface.classList.add('homiot-page-enter');
    pageEntranceTimer = window.setTimeout(() => {
      surface.classList.remove('homiot-page-enter');
    }, 760);

    contentObserver?.disconnect();
    animateReveals(surface);
    if ('MutationObserver' in window) {
      contentObserver = new MutationObserver(() => animateReveals(surface));
      contentObserver.observe(surface, { childList: true, subtree: true });
    }
  }

  function currentRoute() {
    return document.body.dataset.flowRoute
      || (document.body.classList.contains('flow-active')
        ? document.body.dataset.flowScreen
        : location.hash.slice(1))
      || 'welcome';
  }

  window.addEventListener('app-route-change', () => {
    requestAnimationFrame(() => transitionTo(currentRoute()));
  });

  window.addEventListener('hashchange', () => {
    requestAnimationFrame(() => transitionTo(currentRoute()));
  });

  document.addEventListener('click', (event) => {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) {
      requestAnimationFrame(() => transitionTo(viewButton.dataset.view));
    }
  });

  const assistantStatus = document.querySelector('#assistant-status');
  const assistantCard = document.querySelector('.assistant-card');
  if (assistantStatus && assistantCard && 'MutationObserver' in window) {
    let speakingTimer;
    new MutationObserver(() => {
      assistantStatus.classList.remove('homiot-message-enter');
      void assistantStatus.offsetWidth;
      assistantStatus.classList.add('homiot-message-enter');

      const message = assistantStatus.textContent.toLowerCase();
      assistantCard.classList.toggle('homiot-listening', message.startsWith('listening'));
      assistantCard.classList.remove('homiot-speaking');
      clearTimeout(speakingTimer);
      if (message.startsWith('opening ')) {
        assistantCard.classList.add('homiot-speaking');
        speakingTimer = window.setTimeout(() => assistantCard.classList.remove('homiot-speaking'), 1800);
      }
    }).observe(assistantStatus, { childList: true, characterData: true, subtree: true });
  }

  transitionTo(currentRoute());
})();
