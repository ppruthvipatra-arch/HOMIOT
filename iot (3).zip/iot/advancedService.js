(() => {
  const STORAGE_KEY = 'smartnest.advanced.preview.v1';
  const ruleTriggers = new Set(['MANUAL', 'TIME', 'SENSOR_VALUE', 'DEVICE_STATE', 'ENERGY_THRESHOLD']);
  const permissions = new Set(['Owner', 'Administrator', 'Member', 'Guest']);
  const presets = [
    { id: 'welcome-home', name: 'Welcome home', description: 'Light a gentle path into your home.', icon: '⌂', type: 'homecoming' },
    { id: 'good-morning', name: 'Good morning', description: 'Bring the living space to life.', icon: '☀', type: 'morning' },
    { id: 'good-night', name: 'Good night', description: 'Switch off available demo appliances.', icon: '☾', type: 'off' },
    { id: 'movie-time', name: 'Movie time', description: 'Dim lights and ready the TV.', icon: '▣', type: 'movie' },
    { id: 'work-mode', name: 'Work mode', description: 'Set a focused, comfortable workspace.', icon: '⌘', type: 'work' },
    { id: 'relax-mode', name: 'Relax mode', description: 'Set a softer evening atmosphere.', icon: '☾', type: 'relax' },
    { id: 'away-mode', name: 'Away mode', description: 'Switch off demo loads; sensors remain illustrative.', icon: '⌂', type: 'off' },
    { id: 'vacation-mode', name: 'Vacation mode', description: 'A preview only—no security system is connected.', icon: '✈', type: 'off' },
    { id: 'energy-saving', name: 'Energy saving', description: 'Turn off online preview devices.', icon: 'ϟ', type: 'off' },
  ];
  const initialState = {
    automations: [
      { id: 'rule-morning', name: 'Morning routine', trigger: { type: 'TIME', value: '06:00' }, condition: 'ALWAYS', actions: [{ deviceId: 'lights', on: true }, { deviceId: 'fan', on: true }], enabled: true, createdAt: new Date().toISOString() },
      { id: 'rule-goodnight', name: 'Good night', trigger: { type: 'TIME', value: '23:00' }, condition: 'ALWAYS', actions: [{ deviceId: 'lights', on: false }, { deviceId: 'tv', on: false }], enabled: true, createdAt: new Date().toISOString() },
      { id: 'rule-energy', name: 'Energy check-in', trigger: { type: 'ENERGY_THRESHOLD', value: '5' }, condition: 'ALWAYS', actions: [{ deviceId: 'plug', on: false }], enabled: false, createdAt: new Date().toISOString() },
    ],
    history: [],
    schedules: null,
    customScenes: [],
    notifications: [
      { id: 'notice-demo-1', title: 'Preview is ready', message: 'Your device controls are simulated in this browser.', type: 'info', read: false, createdAt: new Date().toISOString() },
      { id: 'notice-demo-2', title: 'Energy snapshot updated', message: 'Illustrative data only; no meter is connected.', type: 'success', read: false, createdAt: new Date(Date.now() - 60000).toISOString() },
    ],
    members: [
      { id: 'member-owner', name: 'Home owner', email: 'owner@example.demo', role: 'Owner', devices: ['all'], status: 'Active' },
      { id: 'member-sam', name: 'Sam Morgan', email: 'sam@example.demo', role: 'Member', devices: ['lights', 'fan', 'tv'], status: 'Invited' },
    ],
    settings: { tariff: 8, fixedCharges: 0, additionalCharges: 0, billingDays: 30, dailyKwh: 4.8, energyThreshold: 5, securityAlerts: true, energyAlerts: true, deviceAlerts: true },
    security: { awayMode: false, door: 'closed', motion: 'clear' },
  };
  let state = null;

  const clone = (value) => JSON.parse(JSON.stringify(value));
  const validTime = (value) => typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
  let stateScope = '';

  function currentScope() {
    return window.SmartNestHomeService?.getCurrentHomeId() || 'my-home';
  }

  function storageKey() {
    return stateScope === 'my-home' ? STORAGE_KEY : `${STORAGE_KEY}.home.${encodeURIComponent(stateScope)}`;
  }

  function persist(next) {
    try {
      localStorage.setItem(storageKey(), JSON.stringify({ version: 1, ...next }));
    } catch (error) {
      throw new Error(`Could not save advanced preview data: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
  }

  function ensureLoaded() {
    const scope = currentScope();
    if (state && stateScope === scope) return;
    state = null;
    stateScope = scope;
    let stored;
    try {
      stored = localStorage.getItem(storageKey());
      if (stored === null) {
        state = clone(initialState);
        persist(state);
        return;
      }
      const parsed = JSON.parse(stored);
      if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.automations)
        || !Array.isArray(parsed.notifications) || !Array.isArray(parsed.members)
        || !Array.isArray(parsed.customScenes) || !parsed.settings || !parsed.security) {
        throw new Error('Saved advanced preview data has an unsupported format.');
      }
      state = { ...clone(initialState), ...parsed };
    } catch (error) {
      state = null;
      throw error instanceof Error ? error : new Error('Advanced preview data could not be read.');
    }
  }

  function commit(mutator) {
    ensureLoaded();
    const next = clone(state);
    mutator(next);
    persist(next);
    state = next;
    window.dispatchEvent(new CustomEvent('smartnest-advanced-changed'));
    return getSnapshot();
  }

  function getSnapshot() {
    ensureLoaded();
    const devices = window.SmartNestDeviceService.getDevices();
    const schedules = window.SmartNestDeviceService.getSchedules();
    return clone({ ...state, schedules, presets, devices });
  }

  function validateAutomation(rule) {
    if (!rule || typeof rule.name !== 'string' || !rule.name.trim() || rule.name.trim().length > 48
      || !rule.trigger || !ruleTriggers.has(rule.trigger.type)
      || !Array.isArray(rule.actions) || !rule.actions.length || rule.actions.length > 32
      || !['ALWAYS', 'DEVICE_ON', 'DEVICE_OFF', 'ENERGY_ABOVE', 'TEMPERATURE_ABOVE'].includes(rule.condition)) {
      throw new Error('Enter a rule name, valid trigger and condition, and at least one device action.');
    }
    if (rule.trigger.type === 'TIME' && !validTime(rule.trigger.value)) throw new Error('Choose a valid trigger time.');
    if (['ENERGY_THRESHOLD', 'SENSOR_VALUE'].includes(rule.trigger.type)
      && (!Number.isFinite(Number(rule.trigger.value)) || Number(rule.trigger.value) < 0 || Number(rule.trigger.value) > 10000)) {
      throw new Error('Choose a valid demo threshold.');
    }
    if (rule.trigger.type === 'DEVICE_STATE' && !rule.trigger.deviceId) throw new Error('Choose a device-state trigger.');
    if (['DEVICE_ON', 'DEVICE_OFF'].includes(rule.condition) && !rule.conditionDeviceId) {
      throw new Error('Choose the device to check for this condition.');
    }
    if (['ENERGY_ABOVE', 'TEMPERATURE_ABOVE'].includes(rule.condition)
      && (!Number.isFinite(Number(rule.conditionValue)) || Number(rule.conditionValue) < 0)) {
      throw new Error('Enter a valid condition threshold.');
    }
    const devices = window.SmartNestDeviceService.getDevices();
    const seen = new Set();
    rule.actions.forEach((action) => {
      const device = devices.find((item) => item.id === action?.deviceId);
      if (!action || typeof action.deviceId !== 'string' || seen.has(action.deviceId)
        || !device || typeof action.on !== 'boolean'
        || (action.settings && (typeof action.settings !== 'object' || Array.isArray(action.settings)))) {
        throw new Error('Choose a valid, unique device and on/off action for every rule action.');
      }
      const settings = action.settings || {};
      const allowed = {
        light: ['brightness', 'lightMode'],
        fan: ['speed'],
        ac: ['temperature', 'fanSpeed', 'acMode'],
        tv: ['volume'],
        geyser: ['temperature'],
        pump: [],
        plug: [],
        exhaust: ['speed'],
      }[device.kind] || [];
      for (const [key, value] of Object.entries(settings)) {
        if (!action.on || !allowed.includes(key)) throw new Error(`${key} cannot be applied to ${device.name} with this action.`);
        if (key === 'brightness' && (!Number.isInteger(value) || value < 0 || value > 100)) throw new Error('Brightness must be from 0 to 100%.');
        if (key === 'volume' && (!Number.isInteger(value) || value < 0 || value > 100)) throw new Error('Volume must be from 0 to 100%.');
        if (['speed', 'fanSpeed'].includes(key) && (!Number.isInteger(value) || value < 1 || value > 5)) throw new Error('Fan speed must be from 1 to 5.');
        if (key === 'temperature') {
          const bounds = device.kind === 'ac' ? [16, 30] : [30, 75];
          if (!Number.isInteger(value) || value < bounds[0] || value > bounds[1]) throw new Error(`Temperature must be from ${bounds[0]} to ${bounds[1]}°C.`);
        }
        if (key === 'lightMode' && !['warm', 'neutral', 'cool'].includes(value)) throw new Error('Choose a supported lighting tone.');
        if (key === 'acMode' && !['cool', 'heat', 'dry', 'fan'].includes(value)) throw new Error('Choose a supported air conditioner mode.');
      }
      seen.add(action.deviceId);
    });
  }

  function saveAutomation(rule) {
    validateAutomation(rule);
    const normalized = { ...clone(rule), name: rule.name.trim() };
    return commit((next) => {
      if (normalized.id) {
        const index = next.automations.findIndex((item) => item.id === normalized.id);
        if (index < 0) throw new Error('This automation rule could not be found.');
        next.automations[index] = { ...next.automations[index], ...normalized };
      } else {
        normalized.id = `rule-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        normalized.createdAt = new Date().toISOString();
        next.automations.unshift(normalized);
      }
    });
  }

  function setAutomationEnabled(id, enabled) {
    if (typeof enabled !== 'boolean') throw new Error('Choose whether this demo rule is enabled.');
    return commit((next) => {
      const rule = next.automations.find((item) => item.id === id);
      if (!rule) throw new Error('This automation rule could not be found.');
      rule.enabled = enabled;
    });
  }

  function deleteAutomation(id) {
    return commit((next) => { next.automations = next.automations.filter((item) => item.id !== id); });
  }

  function recordHistory(next, entry) {
    next.history.unshift({ id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, createdAt: new Date().toISOString(), ...entry });
    next.history = next.history.slice(0, 60);
    next.notifications.unshift({
      id: `notice-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: entry.success ? `${entry.name} preview ran` : `${entry.name} preview needs attention`,
      message: entry.message,
      type: entry.success ? 'success' : 'warning',
      read: false,
      createdAt: new Date().toISOString(),
    });
    next.notifications = next.notifications.slice(0, 50);
  }

  function executeAutomation(id) {
    ensureLoaded();
    const rule = state.automations.find((item) => item.id === id);
    if (!rule) throw new Error('This automation rule could not be found.');
    if (!rule.enabled) throw new Error('Enable this demo rule before running its preview.');
    validateAutomation(rule);
    const devices = window.SmartNestDeviceService.getDevices();
    const watched = devices.find((device) => device.id === rule.conditionDeviceId);
    const energy = devices.reduce((total, device) => {
      const reading = window.SmartNestDeviceService.getEnergyConsumption(device.id);
      return total + (reading.available ? reading.dailyKwh : 0);
    }, 0);
    const conditionMet = rule.condition === 'ALWAYS'
      || (rule.condition === 'DEVICE_ON' && Boolean(watched?.online && watched.on))
      || (rule.condition === 'DEVICE_OFF' && Boolean(watched?.online && !watched.on))
      || (rule.condition === 'ENERGY_ABOVE' && energy > Number(rule.conditionValue || 0))
      || (rule.condition === 'TEMPERATURE_ABOVE' && 23.6 > Number(rule.conditionValue || 0));
    if (!conditionMet) {
      const message = 'Condition was not met; no device actions were applied. This was a manual preview check.';
      commit((next) => recordHistory(next, { ruleId: id, name: rule.name, success: true, message, applied: [], skipped: [] }));
      return { applied: [], skipped: [], conditionMet: false };
    }
    let outcome;
    try {
      outcome = window.SmartNestDeviceService.applyDeviceActions(rule.actions);
    } catch (error) {
      commit((next) => recordHistory(next, { ruleId: id, name: rule.name, success: false, message: error.message || 'No demo actions were applied.' }));
      throw error;
    }
    const message = `${outcome.applied.length} demo action${outcome.applied.length === 1 ? '' : 's'} applied locally; ${outcome.skipped.length} skipped. No hardware commands were sent.`;
    commit((next) => recordHistory(next, { ruleId: id, name: rule.name, success: outcome.skipped.length === 0, message, ...outcome }));
    return { ...outcome, conditionMet: true };
  }

  function getHistory() {
    ensureLoaded();
    return clone(state.history);
  }

  function saveSettings(settings) {
    const ranges = { tariff: [0, 100000], fixedCharges: [0, 1000000], additionalCharges: [0, 1000000], billingDays: [1, 366], dailyKwh: [0, 10000], energyThreshold: [0.1, 10000] };
    for (const [key, bounds] of Object.entries(ranges)) {
      if (key in settings && (!Number.isFinite(Number(settings[key])) || Number(settings[key]) < bounds[0] || Number(settings[key]) > bounds[1])) {
        throw new Error(`${key} is outside its supported demo range.`);
      }
    }
    return commit((next) => { next.settings = { ...next.settings, ...settings }; });
  }

  function createScene(scene) {
    if (!scene || typeof scene.name !== 'string' || !scene.name.trim() || scene.name.trim().length > 40
      || !Array.isArray(scene.actions) || !scene.actions.length) throw new Error('Enter a scene name and select at least one appliance.');
    const devices = window.SmartNestDeviceService.getDevices();
    const seen = new Set();
    scene.actions.forEach((action) => {
      if (!action || !devices.some((device) => device.id === action.deviceId) || seen.has(action.deviceId) || typeof action.on !== 'boolean') {
        throw new Error('Choose a valid unique device and target state for this scene.');
      }
      seen.add(action.deviceId);
    });
    return commit((next) => {
      next.customScenes.unshift({
        id: `scene-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: scene.name.trim(),
        description: scene.description?.trim().slice(0, 100) || 'A custom local preview scene.',
        actions: clone(scene.actions),
      });
    });
  }

  function updateCustomScene(id, scene) {
    if (typeof id !== 'string' || !id.trim() || !scene || typeof scene.name !== 'string'
      || !scene.name.trim() || scene.name.trim().length > 40
      || !Array.isArray(scene.actions) || !scene.actions.length) {
      throw new Error('Enter a scene name and select at least one appliance.');
    }
    const devices = window.SmartNestDeviceService.getDevices();
    const seen = new Set();
    scene.actions.forEach((action) => {
      if (!action || !devices.some((device) => device.id === action.deviceId)
        || seen.has(action.deviceId) || typeof action.on !== 'boolean') {
        throw new Error('Choose a valid unique device and target state for this scene.');
      }
      seen.add(action.deviceId);
    });
    return commit((next) => {
      const current = next.customScenes.find((item) => item.id === id);
      if (!current) throw new Error('This custom preview scene could not be found.');
      current.name = scene.name.trim();
      current.description = scene.description?.trim().slice(0, 100) || 'A custom local preview scene.';
      current.actions = clone(scene.actions);
    });
  }

  function activateScene(id) {
    const devices = window.SmartNestDeviceService.getDevices();
    const scene = presets.find((item) => item.id === id) || getSnapshot().customScenes.find((item) => item.id === id);
    if (!scene) throw new Error('This demo scene could not be found.');
    let actions = scene.actions;
    if (!actions) {
      const selectedDevices = scene.type === 'morning' ? devices.filter((device) => ['light', 'fan', 'plug'].includes(device.kind))
        : scene.type === 'homecoming' ? devices.filter((device) => device.kind === 'light')
          : scene.type === 'work' ? devices.filter((device) => ['light', 'ac', 'plug'].includes(device.kind))
            : scene.type === 'movie' ? devices.filter((device) => ['light', 'tv'].includes(device.kind))
              : scene.type === 'relax' ? devices.filter((device) => ['light', 'fan'].includes(device.kind))
                : devices;
      actions = selectedDevices.map((device) => ({
        deviceId: device.id,
        on: scene.type === 'morning' || scene.type === 'homecoming' || scene.type === 'work' || scene.type === 'relax'
          || (scene.type === 'movie' && ['light', 'tv'].includes(device.kind)),
        ...(scene.type === 'movie' && device.kind === 'light' ? { settings: { brightness: 20 } } : {}),
        ...(scene.type === 'homecoming' && device.kind === 'light' ? { settings: { brightness: 65 } } : {}),
        ...(scene.type === 'work' && device.kind === 'light' ? { settings: { brightness: 70 } } : {}),
        ...(scene.type === 'work' && device.kind === 'ac' ? { settings: { temperature: 23 } } : {}),
        ...(scene.type === 'morning' && device.kind === 'light' ? { settings: { brightness: 75 } } : {}),
        ...(scene.type === 'relax' && device.kind === 'light' ? { settings: { brightness: 35 } } : {}),
        ...(scene.type === 'relax' && device.kind === 'fan' ? { settings: { speed: 1 } } : {}),
      }));
    }
    const outcome = window.SmartNestDeviceService.applyDeviceActions(actions);
    const message = `${outcome.applied.length} demo device${outcome.applied.length === 1 ? '' : 's'} updated; ${outcome.skipped.length} offline or missing device${outcome.skipped.length === 1 ? '' : 's'} skipped.`;
    commit((next) => recordHistory(next, { name: scene.name, success: outcome.skipped.length === 0, message, ...outcome }));
    return outcome;
  }

  function deleteCustomScene(id) {
    return commit((next) => { next.customScenes = next.customScenes.filter((item) => item.id !== id); });
  }

  function addNotification(notification) {
    return commit((next) => {
      next.notifications.unshift({
        id: `notice-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        title: String(notification.title || 'Home update').slice(0, 80),
        message: String(notification.message || '').slice(0, 200),
        type: ['info', 'success', 'warning'].includes(notification.type) ? notification.type : 'info',
        read: false,
        createdAt: new Date().toISOString(),
      });
      next.notifications = next.notifications.slice(0, 50);
    });
  }

  function markNotificationRead(id, read = true) {
    return commit((next) => {
      const notice = next.notifications.find((item) => item.id === id);
      if (notice) notice.read = Boolean(read);
    });
  }

  function clearNotifications() {
    return commit((next) => { next.notifications = []; });
  }

  function addFamilyMember(member) {
    if (!member || typeof member.name !== 'string' || !member.name.trim() || member.name.trim().length > 60
      || typeof member.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(member.email)
      || !permissions.has(member.role) || member.role === 'Owner') {
      throw new Error('Enter a valid name, email and non-owner demo role.');
    }
    return commit((next) => {
      if (next.members.some((item) => item.email.toLowerCase() === member.email.trim().toLowerCase())) {
        throw new Error('This email already exists in the demo family list.');
      }
      next.members.push({
        id: `member-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: member.name.trim(),
        email: member.email.trim(),
        role: member.role,
        devices: member.role === 'Guest' ? [] : ['all'],
        status: 'Invited',
      });
    });
  }

  function updateFamilyMember(id, changes) {
    if ('role' in changes && (!permissions.has(changes.role) || changes.role === 'Owner')) {
      throw new Error('Choose a valid non-owner demo permission.');
    }
    return commit((next) => {
      const member = next.members.find((item) => item.id === id);
      if (!member || member.role === 'Owner') throw new Error('This family member cannot be changed in the demo.');
      if ('role' in changes) member.role = changes.role;
      if ('devices' in changes && Array.isArray(changes.devices)) member.devices = changes.devices.slice(0, 32);
    });
  }

  function removeFamilyMember(id) {
    return commit((next) => {
      const member = next.members.find((item) => item.id === id);
      if (!member || member.role === 'Owner') throw new Error('The owner access cannot be revoked.');
      next.members = next.members.filter((item) => item.id !== id);
    });
  }

  function updateSecurity(changes) {
    return commit((next) => { next.security = { ...next.security, ...changes }; });
  }

  function reset() {
    stateScope = currentScope();
    state = clone(initialState);
    persist(state);
    window.dispatchEvent(new CustomEvent('smartnest-advanced-changed'));
    return getSnapshot();
  }

  function removeHomeContext(homeId) {
    if (!homeId || homeId === 'my-home' || homeId === currentScope()) {
      throw new Error('Cannot remove the active or default automation context.');
    }
    try {
      localStorage.removeItem(`${STORAGE_KEY}.home.${encodeURIComponent(homeId)}`);
    } catch (error) {
      throw new Error(`Could not remove this home’s automation preview: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
  }

  window.addEventListener('storage', (event) => {
    if (event.key !== STORAGE_KEY) return;
    state = null;
    try {
      ensureLoaded();
      window.dispatchEvent(new CustomEvent('smartnest-advanced-changed'));
    } catch (error) {
      window.dispatchEvent(new CustomEvent('smartnest-storage-error', { detail: { message: error.message } }));
    }
  });

  window.SmartNestAdvancedService = {
    getSnapshot,
    saveAutomation,
    setAutomationEnabled,
    deleteAutomation,
    executeAutomation,
    getHistory,
    saveSettings,
    createScene,
    updateCustomScene,
    activateScene,
    deleteCustomScene,
    addNotification,
    markNotificationRead,
    clearNotifications,
    addFamilyMember,
    updateFamilyMember,
    removeFamilyMember,
    updateSecurity,
    removeHomeContext,
    reset,
    presets: () => clone(presets),
  };
})();