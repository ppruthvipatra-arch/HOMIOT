(() => {
  const STORAGE_KEY = 'smartnest.settings.preview.v1';
  const defaultRooms = [
    { id: 'living-room', name: 'Living Room', icon: '⌂' },
    { id: 'bedroom', name: 'Bedroom', icon: '◷' },
    { id: 'kitchen', name: 'Kitchen', icon: '♨' },
    { id: 'bathroom', name: 'Bathroom', icon: '◌' },
    { id: 'balcony', name: 'Balcony', icon: '☼' },
    { id: 'outdoor', name: 'Outdoor', icon: '♧' },
  ];
  const initialState = {
    rooms: defaultRooms,
    pairedDevices: [
      { id: 'esp32-living-demo', name: 'Living room gateway', deviceId: 'SN-ESP32-2048', mac: 'A4:CF:12:8B:20:48', room: 'Living Room', status: 'Online', signal: 91, firmware: '1.4.2', lastSeen: 'Just now' },
      { id: 'esp32-garden-demo', name: 'Garden sensor bridge', deviceId: 'SN-ESP32-7310', mac: '84:F3:EB:7A:73:10', room: 'Outdoor', status: 'Offline', signal: 34, firmware: '1.3.8', lastSeen: '24 min ago' },
    ],
    wifi: { status: 'Connected', ssid: 'HomeNet_5G', signal: 86, ip: '192.168.1.24', type: 'Wi-Fi 5 GHz', lastConnected: 'Today, 9:42 AM' },
    profile: { name: 'Home owner', preferredName: '', preferredLanguage: 'en', avatar: '', email: 'owner@example.demo', phone: '+1 555 010 2048', home: 'My Home', location: '' },
    preferences: { language: 'en', temperature: 'C', energy: 'kWh', notifications: true, sounds: false, vibration: true, autoRefresh: true, dataSaver: false },
    remote: { enabled: true, cloud: 'Connected', gateway: 'Online', lastSync: 'A few seconds ago', permissions: { familyControl: true, remoteViewing: true } },
    privacy: { dataSharing: false },
    twoFactor: false,
  };
  const clone = (value) => JSON.parse(JSON.stringify(value));
  let state;
  let pairedScope = '';
  let legacyPairedDevices = clone(initialState.pairedDevices);

  function currentScope() {
    return window.SmartNestHomeService?.getCurrentHomeId() || 'my-home';
  }

  function pairedStorageKey(scope = currentScope()) {
    return `${STORAGE_KEY}.paired.${encodeURIComponent(scope)}`;
  }

  function load() {
    if (state) return;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) {
        state = clone(initialState);
        legacyPairedDevices = clone(initialState.pairedDevices);
        persist(state);
        return;
      }
      const parsed = JSON.parse(saved);
      if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.rooms)
        || !Array.isArray(parsed.pairedDevices) || !parsed.wifi || !parsed.profile
        || !parsed.preferences || !parsed.remote || !parsed.privacy) {
        throw new Error('Saved settings preview has an unsupported format.');
      }
      const hadLegacyTheme = Object.prototype.hasOwnProperty.call(parsed.preferences, 'theme');
      const preferences = { ...clone(initialState.preferences), ...parsed.preferences };
      delete preferences.theme;
      state = {
        ...clone(initialState),
        ...parsed,
        profile: { ...clone(initialState.profile), ...parsed.profile },
        preferences,
        remote: { ...clone(initialState.remote), ...parsed.remote, permissions: { ...clone(initialState.remote.permissions), ...parsed.remote.permissions } },
      };
      legacyPairedDevices = clone(state.pairedDevices);
      if (hadLegacyTheme) persist(state);
    } catch (error) {
      state = null;
      throw error instanceof Error ? error : new Error('Settings preview could not be loaded.');
    }
  }

  function persist(value) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, ...value }));
      localStorage.setItem(pairedStorageKey(), JSON.stringify(value.pairedDevices));
    } catch (error) {
      throw new Error(`Could not save settings preview: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
  }

  function ensurePairedScope() {
    load();
    const scope = currentScope();
    if (scope === pairedScope) return;
    let saved;
    try {
      saved = localStorage.getItem(pairedStorageKey(scope));
      if (saved === null) {
        state.pairedDevices = scope === 'my-home' ? clone(legacyPairedDevices) : [];
      } else {
        const parsed = JSON.parse(saved);
        if (!Array.isArray(parsed) || parsed.some((device) => !device || typeof device.id !== 'string'
          || typeof device.deviceId !== 'string' || typeof device.name !== 'string' || typeof device.room !== 'string')) {
          throw new Error('Saved gateway preview data has an unsupported format.');
        }
        state.pairedDevices = parsed;
      }
      pairedScope = scope;
    } catch (error) {
      throw error instanceof Error ? error : new Error('Gateway preview data could not be loaded.');
    }
  }

  function commit(change) {
    load();
    ensurePairedScope();
    const next = clone(state);
    change(next);
    persist(next);
    state = next;
    window.dispatchEvent(new CustomEvent('smartnest-settings-changed'));
    return getSnapshot();
  }

  function getSnapshot() {
    load();
    ensurePairedScope();
    return clone(state);
  }

  function saveProfile(profile) {
    const fields = ['name', 'email', 'phone', 'home', 'location'];
    const next = {};
    for (const field of fields) {
      const value = String(profile[field] || '').trim();
      if (field === 'location') {
        if (value.length > 80) throw new Error('Location must be 80 characters or fewer.');
        next[field] = value;
        continue;
      }
      if (!value || value.length > (field === 'email' ? 120 : 80)) throw new Error(`Enter a valid ${field === 'home' ? 'home name' : field}.`);
      next[field] = value;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email)) throw new Error('Enter a valid email address.');
    if (!/^[+\d\s().-]{7,24}$/.test(next.phone)) throw new Error('Enter a valid phone number.');
    const preferredName = String(profile.preferredName || '').trim();
    if (preferredName.length > 40) throw new Error('Preferred name must be 40 characters or fewer.');
    const preferredLanguage = profile.preferredLanguage || getSnapshot().profile.preferredLanguage || 'en';
    if (!['en', 'hi', 'or'].includes(preferredLanguage)) throw new Error('Choose English, Hindi, or Odia as your preferred language.');
    const avatar = profile.avatar === undefined ? getSnapshot().profile.avatar : String(profile.avatar);
    if (avatar && (!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(avatar) || avatar.length > 700000)) {
      throw new Error('Choose a PNG, JPEG, or WebP profile image under 512 KB.');
    }
    next.preferredName = preferredName;
    next.preferredLanguage = preferredLanguage;
    next.avatar = avatar;
    return commit((data) => { data.profile = next; });
  }

  function saveWifiConnection(ssid) {
    const name = String(ssid || '').trim();
    if (!name || name.length > 64) throw new Error('Choose a valid Wi-Fi network name.');
    return commit((data) => { data.wifi = { ...data.wifi, status: 'Connected', ssid: name, lastConnected: 'Just now' }; });
  }

  function setWifiStatus(status) {
    if (!['Connected', 'Connecting', 'Disconnected', 'Connection Failed'].includes(status)) throw new Error('Choose a valid connection status.');
    return commit((data) => { data.wifi.status = status; });
  }

  function savePreferences(values) {
    const allowed = {
      language: ['en', 'hi', 'or', 'es', 'fr'],
      temperature: ['C', 'F'], energy: ['kWh'],
    };
    if ('theme' in values) throw new Error('Theme preferences are unavailable; HOMIOT uses dark appearance.');
    for (const [key, choices] of Object.entries(allowed)) {
      if (key in values && !choices.includes(values[key])) throw new Error(`Unsupported ${key} preference.`);
    }
    for (const key of ['notifications', 'sounds', 'vibration', 'autoRefresh', 'dataSaver']) {
      if (key in values && typeof values[key] !== 'boolean') throw new Error(`Invalid ${key} preference.`);
    }
    return commit((data) => { data.preferences = { ...data.preferences, ...values }; });
  }

  function saveSecurityPreferences(values) {
    if ('twoFactor' in values && typeof values.twoFactor !== 'boolean') throw new Error('Invalid two-factor preference.');
    if ('remoteEnabled' in values && typeof values.remoteEnabled !== 'boolean') throw new Error('Invalid remote-access preference.');
    if ('dataSharing' in values && typeof values.dataSharing !== 'boolean') throw new Error('Invalid data-sharing preference.');
    return commit((data) => {
      if ('twoFactor' in values) data.twoFactor = values.twoFactor;
      if ('remoteEnabled' in values) data.remote.enabled = values.remoteEnabled;
      if ('dataSharing' in values) data.privacy.dataSharing = values.dataSharing;
    });
  }

  function saveRemotePreview(changes) {
    const cloudStates = ['Connected', 'Cloud disconnected'];
    const gatewayStates = ['Online', 'Gateway offline'];
    const syncStates = ['A few seconds ago', 'Synchronization failed'];
    if ('cloud' in changes && !cloudStates.includes(changes.cloud)) throw new Error('Unsupported cloud preview state.');
    if ('gateway' in changes && !gatewayStates.includes(changes.gateway)) throw new Error('Unsupported gateway preview state.');
    if ('lastSync' in changes && !syncStates.includes(changes.lastSync)) throw new Error('Unsupported synchronization preview state.');
    if (changes.permissions && Object.values(changes.permissions).some((value) => typeof value !== 'boolean')) throw new Error('Invalid remote-access permission.');
    return commit((data) => {
      data.remote = { ...data.remote, ...changes, permissions: { ...data.remote.permissions, ...changes.permissions } };
    });
  }

  function saveRoom(room) {
    const name = String(room.name || '').trim();
    if (!name || name.length > 32) throw new Error('Room names must be 1–32 characters.');
    return commit((data) => {
      if (data.rooms.some((item) => item.name.toLowerCase() === name.toLowerCase() && item.id !== room.id)) throw new Error('A room with this name already exists.');
      if (room.id) {
        const existing = data.rooms.find((item) => item.id === room.id);
        if (!existing) throw new Error('This room no longer exists.');
        const previousName = existing.name;
        existing.name = name;
        if (room.icon) existing.icon = room.icon;
        if (previousName !== name) {
          window.SmartNestDeviceService.renameRoomDevices(previousName, name);
          data.pairedDevices.forEach((device) => { if (device.room === previousName) device.room = name; });
        }
      } else {
        data.rooms.push({ id: `room-${Date.now()}`, name, icon: room.icon || '⌂' });
      }
    });
  }

  function removeRoom(id) {
    return commit((data) => {
      const room = data.rooms.find((item) => item.id === id);
      if (!room) throw new Error('This room no longer exists.');
      if (window.SmartNestDeviceService.getDevices().some((device) => device.room === room.name)) {
        throw new Error('Reassign the devices in this room before removing it.');
      }
      if (data.rooms.length <= 1) throw new Error('Keep at least one room in your home.');
      data.rooms = data.rooms.filter((item) => item.id !== id);
    });
  }

  function addPairedDevice(device) {
    const name = String(device.name || '').trim();
    if (!name || name.length > 40 || !device.deviceId || !device.room) throw new Error('Enter a device name, ID, and room.');
    return commit((data) => {
      if (data.pairedDevices.some((item) => item.deviceId === device.deviceId)) throw new Error('This device is already in your paired-device list.');
      data.pairedDevices.push({
        id: `paired-${Date.now()}`, name, deviceId: String(device.deviceId).trim(),
        mac: 'Not disclosed in pairing preview', room: device.room, status: 'Online',
        signal: 78, firmware: 'Preview · unknown', lastSeen: 'Just now',
      });
    });
  }

  function updatePairedDevice(id, changes) {
    return commit((data) => {
      const device = data.pairedDevices.find((item) => item.id === id);
      if (!device) throw new Error('This paired preview device no longer exists.');
      if (changes.name !== undefined) {
        const name = String(changes.name).trim();
        if (!name || name.length > 40) throw new Error('Device name must be 1–40 characters.');
        device.name = name;
      }
      if (changes.room !== undefined) device.room = changes.room;
      if (changes.status !== undefined && !['Online', 'Offline'].includes(changes.status)) throw new Error('Choose a valid simulated connection state.');
      if (changes.status !== undefined) device.status = changes.status;
    });
  }

  function removePairedDevice(id) {
    return commit((data) => { data.pairedDevices = data.pairedDevices.filter((item) => item.id !== id); });
  }

  function reset() {
    pairedScope = currentScope();
    state = clone(initialState);
    state.pairedDevices = pairedScope === 'my-home' ? clone(initialState.pairedDevices) : [];
    legacyPairedDevices = clone(initialState.pairedDevices);
    persist(state);
    window.dispatchEvent(new CustomEvent('smartnest-settings-changed'));
    return getSnapshot();
  }

  function removeHomeContext(homeId) {
    if (!homeId || homeId === currentScope()) throw new Error('Cannot remove the active home’s gateway preview.');
    try {
      localStorage.removeItem(pairedStorageKey(homeId));
    } catch (error) {
      throw new Error(`Could not remove this home’s gateway preview: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
  }

  window.SmartNestSettingsService = {
    getSnapshot, saveProfile, saveWifiConnection, setWifiStatus, savePreferences, saveSecurityPreferences, saveRemotePreview,
    saveRoom, removeRoom, addPairedDevice, updatePairedDevice, removePairedDevice, removeHomeContext, reset,
  };
})();
