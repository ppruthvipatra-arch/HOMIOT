(() => {
  const accounts = new Map();
  let pendingVerification = null;
  let recoveryAccount = null;
  let recoveryExpiresAt = 0;
  const codeLifetimeMs = 10 * 60 * 1000;
  const resendDelayMs = 30 * 1000;
  const loginAttemptLimit = 5;
  const loginWindowMs = 60 * 60 * 1000;
  const loginAttemptsStorageKey = 'homiot.demo.login-attempts';

  function normalizeEmail(email) {
    return String(email).trim().toLowerCase();
  }

  function emptyLoginAttempts() {
    return { windowStartedAt: 0, failedAttempts: 0, lockedUntil: 0 };
  }

  function saveLoginAttempts(attempts) {
    try {
      localStorage.setItem(loginAttemptsStorageKey, JSON.stringify(attempts));
    } catch (error) {
      console.error('The sign-in attempt limit could not be saved.', error);
      throw new Error('Sign-in protection could not be saved in this browser. Check storage settings and try again.');
    }
  }

  function getLoginAttempts() {
    let raw;
    try {
      raw = localStorage.getItem(loginAttemptsStorageKey);
    } catch (error) {
      console.error('The sign-in attempt limit could not be read.', error);
      throw new Error('Sign-in protection could not be checked in this browser. Check storage settings and try again.');
    }
    if (!raw) return emptyLoginAttempts();

    let attempts;
    try {
      attempts = JSON.parse(raw);
    } catch (error) {
      console.error('The saved sign-in attempt limit is invalid.', error);
      throw new Error('Saved sign-in protection data is invalid. Clear this site’s browser data or contact support.');
    }
    if (!attempts || !Number.isSafeInteger(attempts.windowStartedAt)
      || !Number.isInteger(attempts.failedAttempts)
      || attempts.failedAttempts < 0 || attempts.failedAttempts > loginAttemptLimit
      || !Number.isSafeInteger(attempts.lockedUntil)
      || (attempts.failedAttempts === loginAttemptLimit) !== (attempts.lockedUntil > 0)) {
      throw new Error('Saved sign-in protection data is invalid. Clear this site’s browser data or contact support.');
    }

    const now = Date.now();
    if (attempts.lockedUntil > now) return attempts;
    if (attempts.lockedUntil || (attempts.windowStartedAt && now - attempts.windowStartedAt >= loginWindowMs)) {
      const reset = emptyLoginAttempts();
      saveLoginAttempts(reset);
      return reset;
    }
    return attempts;
  }

  function getLoginLockout() {
    const attempts = getLoginAttempts();
    const remainingMs = Math.max(0, attempts.lockedUntil - Date.now());
    return {
      locked: remainingMs > 0,
      remainingMs,
      attemptsRemaining: Math.max(0, loginAttemptLimit - attempts.failedAttempts),
    };
  }

  function loginLockoutMessage(remainingMs) {
    const minutes = Math.max(1, Math.ceil(remainingMs / 60000));
    return `Too many unsuccessful sign-in attempts. Try again in about ${minutes} minute${minutes === 1 ? '' : 's'}.`;
  }

  function recordLoginFailure(attempts) {
    const now = Date.now();
    const next = {
      windowStartedAt: attempts.windowStartedAt || now,
      failedAttempts: attempts.failedAttempts + 1,
      lockedUntil: 0,
    };
    if (next.failedAttempts >= loginAttemptLimit) {
      next.failedAttempts = loginAttemptLimit;
      next.lockedUntil = now + loginWindowMs;
    }
    saveLoginAttempts(next);
    return next;
  }

  function validatePassword(password) {
    if (password.length < 8) return 'Use at least 8 characters.';
    if (!/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
      return 'Include uppercase and lowercase letters and a number.';
    }
    return '';
  }

  async function hashPassword(password) {
    if (!window.crypto?.subtle) {
      throw new Error('Secure browser cryptography is unavailable. Use a current browser over localhost or HTTPS.');
    }
    const bytes = new TextEncoder().encode(password);
    const digest = await window.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function createCode() {
    if (!window.crypto?.getRandomValues) {
      throw new Error('Secure code generation is unavailable in this browser.');
    }
    const value = new Uint32Array(1);
    window.crypto.getRandomValues(value);
    return String(value[0] % 1000000).padStart(6, '0');
  }

  function createPending(type, account) {
    const now = Date.now();
    recoveryAccount = null;
    recoveryExpiresAt = 0;
    pendingVerification = {
      type,
      account,
      code: createCode(),
      expiresAt: now + codeLifetimeMs,
      resendAt: now + resendDelayMs,
    };
    return { code: pendingVerification.code, resendAt: pendingVerification.resendAt };
  }

  async function beginRegistration(details) {
    const email = normalizeEmail(details.email);
    if (accounts.has(email)) throw new Error('An account with this email already exists in this page session.');
    const passwordError = validatePassword(details.password);
    if (passwordError) throw new Error(passwordError);
    const account = {
      name: String(details.name).trim(),
      email,
      phone: String(details.phone).trim(),
      passwordHash: await hashPassword(details.password),
    };
    return createPending('registration', account);
  }

  async function login(emailInput, password) {
    const attempts = getLoginAttempts();
    if (attempts.lockedUntil > Date.now()) {
      throw new Error(loginLockoutMessage(attempts.lockedUntil - Date.now()));
    }
    const identifier = normalizeEmail(emailInput);
    const account = accounts.get(identifier)
      || (() => {
        const matchingNames = [...accounts.values()].filter((item) => normalizeEmail(item.name) === identifier);
        return matchingNames.length === 1 ? matchingNames[0] : null;
      })();
    const submittedHash = await hashPassword(password);
    if (!account || account.passwordHash !== submittedHash) {
      const updatedAttempts = recordLoginFailure(attempts);
      if (updatedAttempts.lockedUntil > Date.now()) {
        throw new Error(loginLockoutMessage(updatedAttempts.lockedUntil - Date.now()));
      }
      const attemptsRemaining = loginAttemptLimit - updatedAttempts.failedAttempts;
      const attemptsWord = attemptsRemaining === 1 ? 'attempt remains' : 'attempts remain';
      throw new Error(`Email or password is incorrect. ${attemptsRemaining} ${attemptsWord} before sign-in is locked for one hour.`);
    }
    saveLoginAttempts(emptyLoginAttempts());
    return { name: account.name, email: account.email, phone: account.phone };
  }

  function beginRecovery(emailInput) {
    const account = accounts.get(normalizeEmail(emailInput));
    if (!account) throw new Error('No verified demo account with that email exists in this page session.');
    return createPending('recovery', account);
  }

  function verify(code) {
    if (!pendingVerification) throw new Error('There is no active verification. Start the flow again.');
    if (Date.now() > pendingVerification.expiresAt) {
      pendingVerification = null;
      throw new Error('This code has expired. Request a new code.');
    }
    if (String(code) !== pendingVerification.code) throw new Error('That code is not correct. Try again.');

    const result = { type: pendingVerification.type, account: pendingVerification.account };
    if (result.type === 'registration') accounts.set(result.account.email, result.account);
    if (result.type === 'recovery') {
      recoveryAccount = result.account;
      recoveryExpiresAt = Date.now() + codeLifetimeMs;
    }
    pendingVerification = null;
    return {
      type: result.type,
      account: { name: result.account.name, email: result.account.email, phone: result.account.phone },
    };
  }

  function resend() {
    if (!pendingVerification) throw new Error('There is no active verification. Start the flow again.');
    if (Date.now() < pendingVerification.resendAt) {
      throw new Error('Please wait for the resend countdown to finish.');
    }
    return createPending(pendingVerification.type, pendingVerification.account);
  }

  async function resetPassword(password) {
    if (!recoveryAccount || Date.now() > recoveryExpiresAt) {
      recoveryAccount = null;
      throw new Error('Verify a password recovery code before changing the password.');
    }
    const passwordError = validatePassword(password);
    if (passwordError) throw new Error(passwordError);
    recoveryAccount.passwordHash = await hashPassword(password);
    recoveryAccount = null;
    recoveryExpiresAt = 0;
  }

  window.HOMIOTDemoAuthService = Object.freeze({
    beginRegistration,
    beginRecovery,
    login,
    getLoginLockout,
    resend,
    resetPassword,
    validatePassword,
    verify,
  });
})();
