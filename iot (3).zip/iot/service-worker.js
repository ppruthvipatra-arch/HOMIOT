const CACHE_NAME = 'homiot-shell-v73';
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './welcome.css',
  './auth.css',
  './dashboard.css',
  './dashboard-upgrade.css',
  './motion.css',
  './assistant-widget.css',
  './deviceService.js',
  './homeService.js',
  './dashboard.js',
  './connectivityClient.js',
  './device-management.css',
  './deviceManagement.js',
  './advanced-features.css',
  './advancedService.js',
  './advancedFeatures.js',
  './settings.css',
  './settingsService.js',
  './settingsModule.js',
  './homeModule.js',
  './longpress-delete.js',
  './authService.js',
  './homes.css',
  './homiot-premium.css',
  './glass-theme.css',
  './assets/backgrounds/living-room.jpg',
  './assets/backgrounds/home-interior.jpg',
  './assets/backgrounds/bedroom.jpg',
  './assets/backgrounds/sustainable-home.jpg',
  './assets/backgrounds/office-security.jpg',
  './auth.js',
  './app.js',
  './motion.js',
  './assistantWidget.js',
  './manifest.json',
  './icons/icon.svg',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './pwa.css',
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(
    APP_SHELL.map((asset) => new Request(asset, { cache: 'reload' })),
  )));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(
    keys.filter((key) => key.startsWith('homiot-shell-') && key !== CACHE_NAME).map((key) => caches.delete(key)),
  )));
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  const url = new URL(request.url);
  const path = url.pathname.toLowerCase();
  const sensitivePath = /\/(?:api|auth|login|devices?|cameras?|cctv|streams?|recordings?)(?:\/|$)/i;
  const privateRequest = sensitivePath.test(path)
    || url.search.length > 0
    || request.destination === 'video'
    || request.destination === 'audio'
    || request.headers.has('range');
  if (privateRequest) {
    event.respondWith(fetch(request));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(async () => (
      await caches.match('./index.html') || Response.error()
    )));
    return;
  }

  event.respondWith(caches.match(request).then((cached) => cached || fetch(request)));
});
