(() => {
  const widget = document.querySelector('#homiot-assistant');
  const launcher = document.querySelector('#homiot-assistant-launcher');
  const panel = document.querySelector('#homiot-assistant-panel');
  const closeButton = document.querySelector('#homiot-assistant-close');
  const form = document.querySelector('#homiot-assistant-form');
  const input = document.querySelector('#homiot-assistant-input');
  const messages = document.querySelector('#homiot-assistant-messages');
  const voiceButton = document.querySelector('#homiot-assistant-voice');
  const readButton = document.querySelector('#homiot-assistant-read');
  if (!widget || !launcher || !panel || !closeButton || !form || !input || !messages) return;

  const positionKey = 'homiot-assistant-position-v1';
  const minimumEdge = 12;
  let pointerStart = null;
  let dragOffset = null;
  let dragged = false;
  let suppressClick = false;
  let recognition = null;

  function reportStorageError(error) {
    console.error('HOMIOT assistant position could not be saved.', error);
  }

  function clampPosition(left, top) {
    const bounds = widget.getBoundingClientRect();
    return {
      left: Math.max(minimumEdge, Math.min(left, window.innerWidth - bounds.width - minimumEdge)),
      top: Math.max(minimumEdge, Math.min(top, window.innerHeight - bounds.height - minimumEdge)),
    };
  }

  function setPosition(left, top, save = false) {
    const position = clampPosition(left, top);
    widget.style.left = `${position.left}px`;
    widget.style.top = `${position.top}px`;
    widget.style.right = 'auto';
    widget.style.bottom = 'auto';
    if (save) {
      try {
        localStorage.setItem(positionKey, JSON.stringify(position));
      } catch (error) {
        reportStorageError(error);
      }
    }
    if (!panel.hidden) positionPanel();
  }

  function loadPosition() {
    try {
      const saved = localStorage.getItem(positionKey);
      if (!saved) return;
      const position = JSON.parse(saved);
      if (Number.isFinite(position.left) && Number.isFinite(position.top)) {
        setPosition(position.left, position.top);
      }
    } catch (error) {
      reportStorageError(error);
    }
  }

  function positionPanel() {
    if (panel.hidden) return;
    const launcherBounds = launcher.getBoundingClientRect();
    const panelWidth = panel.getBoundingClientRect().width;
    const panelHeight = panel.getBoundingClientRect().height;
    const left = Math.max(minimumEdge, Math.min(
      launcherBounds.right - panelWidth,
      window.innerWidth - panelWidth - minimumEdge,
    ));
    const above = launcherBounds.top - panelHeight - 12;
    const top = above >= minimumEdge
      ? above
      : Math.min(launcherBounds.bottom + 12, window.innerHeight - panelHeight - minimumEdge);
    panel.style.left = `${left}px`;
    panel.style.top = `${Math.max(minimumEdge, top)}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  }

  function setOpen(open) {
    panel.hidden = !open;
    launcher.setAttribute('aria-expanded', String(open));
    if (!open) {
      if (recognition) recognition.abort();
      launcher.focus();
      return;
    }
    positionPanel();
    input.focus({ preventScroll: true });
  }

  function addMessage(text, sender = 'assistant', action = null) {
    const message = document.createElement('p');
    message.className = `homiot-assistant-message${sender === 'user' ? ' is-user' : ''}`;
    message.textContent = text;
    messages.append(message);
    if (action) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'homiot-assistant-message-action';
      button.dataset.assistantRoute = action.route;
      button.textContent = action.label;
      messages.append(button);
    }
    messages.scrollTop = messages.scrollHeight;
    return message;
  }

  function helpFor(message) {
    const query = message.toLowerCase();
    if (/energy|kwh|bill|electric|usage|power|cost|consumption/.test(query)) {
      return {
        text: 'Live energy use and the bill are not available yet: no compatible meter reading or utility tariff is connected. HOMIOT will not substitute demo numbers for real totals.',
        action: { route: 'dash-energy', label: 'Open Energy' },
      };
    }
    if (/gateway|connect|mqtt|home assistant|wifi|wi-fi|integration/.test(query)) {
      const state = window.HomiotConnectivityClient?.getSnapshot();
      const connected = state?.connected
        && state.integrations.some((integration) => integration.status === 'connected');
      return {
        text: connected
          ? 'The backend session is connected. Check Device Integrations to review the adapter’s verified gateway status.'
          : 'No verified home gateway is connected. Open Device Integrations to configure an authorized backend connection. Do not enter Wi-Fi passwords in HOMIOT.',
        action: { route: 'dash-connectivity', label: 'Open Device Integrations' },
      };
    }
    if (/device|switch|appliance|control/.test(query)) {
      return {
        text: 'My Devices shows the local preview inventory and simulated controls. For verified hardware, configure a supported backend in Device Integrations; preview controls do not operate appliances.',
        action: { route: 'dash-devices', label: 'Open Devices' },
      };
    }
    if (/automation|routine|schedule|rule/.test(query)) {
      return {
        text: 'Open Automation to review local preview rules. They are not run automatically and do not control physical devices.',
        action: { route: 'dash-automation', label: 'Open Automation' },
      };
    }
    if (/profile|account|settings/.test(query)) {
      return {
        text: 'Your profile and preferences are available from the Profile section.',
        action: { route: 'dash-profile', label: 'Open Profile' },
      };
    }
    if (/help|chat|what can|how do i|navigate|where/.test(query)) {
      return {
        text: 'I can point you to Home, Devices, Automation, Energy, Profile, and Device Integrations. This is on-device help; a generative AI service is not connected.',
      };
    }
    return {
      text: 'I can help with energy availability, gateway setup, preview device controls, automation, and navigation. This local helper does not connect to a cloud AI service.',
    };
  }

  function answer(message) {
    const question = message.trim();
    if (!question) return;
    addMessage(question, 'user');
    input.value = '';
    const reply = helpFor(question);
    addMessage(reply.text, 'assistant', reply.action);
  }

  function positionFromSavedOrDefault() {
    loadPosition();
  }

  launcher.addEventListener('pointerdown', (event) => {
    if (!event.isPrimary || event.button !== 0) return;
    const bounds = launcher.getBoundingClientRect();
    pointerStart = { x: event.clientX, y: event.clientY };
    dragOffset = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    dragged = false;
    launcher.setPointerCapture(event.pointerId);
  });

  launcher.addEventListener('pointermove', (event) => {
    if (!pointerStart || !dragOffset) return;
    const distance = Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y);
    if (distance < 7 && !dragged) return;
    dragged = true;
    setPosition(event.clientX - dragOffset.x, event.clientY - dragOffset.y);
  });

  function finishDrag(event) {
    if (!pointerStart) return;
    if (dragged) {
      const bounds = widget.getBoundingClientRect();
      setPosition(bounds.left, bounds.top, true);
      suppressClick = true;
      window.setTimeout(() => { suppressClick = false; }, 0);
    }
    pointerStart = null;
    dragOffset = null;
  }

  launcher.addEventListener('pointerup', finishDrag);
  launcher.addEventListener('pointercancel', finishDrag);
  launcher.addEventListener('click', (event) => {
    if (suppressClick) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    setOpen(panel.hidden);
  });

  launcher.addEventListener('keydown', (event) => {
    if (!event.altKey || !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const bounds = widget.getBoundingClientRect();
    const step = event.shiftKey ? 30 : 12;
    const left = bounds.left + (event.key === 'ArrowLeft' ? -step : event.key === 'ArrowRight' ? step : 0);
    const top = bounds.top + (event.key === 'ArrowUp' ? -step : event.key === 'ArrowDown' ? step : 0);
    setPosition(left, top, true);
  });

  closeButton.addEventListener('click', () => setOpen(false));
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    answer(input.value);
  });

  document.addEventListener('click', (event) => {
    const prompt = event.target.closest('[data-assistant-prompt]');
    if (prompt) {
      answer(prompt.dataset.assistantPrompt);
      return;
    }
    const route = event.target.closest('[data-assistant-route]');
    if (route) {
      window.setRoute(route.dataset.assistantRoute);
      setOpen(false);
    }
  });

  if (voiceButton) {
    voiceButton.addEventListener('click', () => {
      const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!Recognition) {
        addMessage('Voice input is not supported in this browser. You can type a question instead.');
        return;
      }
      if (recognition) recognition.abort();
      recognition = new Recognition();
      recognition.lang = window.SmartNestSettingsService?.getSnapshot().profile.preferredLanguage || navigator.language;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      voiceButton.disabled = true;
      voiceButton.querySelector('span').textContent = 'Listening…';
      recognition.onresult = (event) => answer(event.results[0][0].transcript);
      recognition.onerror = (event) => addMessage(`Voice input unavailable: ${event.error}. You can type your question instead.`);
      recognition.onend = () => {
        voiceButton.disabled = false;
        voiceButton.querySelector('span').textContent = 'Ask by voice';
        recognition = null;
      };
      try {
        recognition.start();
      } catch (error) {
        addMessage(`Voice input could not start: ${error instanceof Error ? error.message : 'browser permission is unavailable'}.`);
        voiceButton.disabled = false;
        voiceButton.querySelector('span').textContent = 'Ask by voice';
        recognition = null;
      }
    });
  }

  if (readButton) {
    readButton.addEventListener('click', () => {
      if (!('speechSynthesis' in window)) {
        addMessage('Spoken replies are not supported in this browser.');
        return;
      }
      const latestReply = [...messages.querySelectorAll('.homiot-assistant-message:not(.is-user)')].at(-1);
      if (!latestReply) return;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(latestReply.textContent));
    });
  }

  window.addEventListener('resize', () => {
    const bounds = widget.getBoundingClientRect();
    setPosition(bounds.left, bounds.top);
    if (!panel.hidden) positionPanel();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !panel.hidden) setOpen(false);
  });

  positionFromSavedOrDefault();
})();
