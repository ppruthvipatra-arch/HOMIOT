(() => {
  const homes = window.SmartNestHomeService;
  const devices = window.SmartNestDeviceService;
  const root = document.querySelector('#homes-module');
  const selector = document.querySelector('#global-home-selector');
  const actionDialog = document.querySelector('#home-action-dialog');
  if (!homes || !devices || !root) return;

  const routes = new Set([
    'dash-homes', 'dash-add-home', 'dash-home-overview', 'dash-home-rooms',
    'dash-room-detail', 'dash-home-settings', 'dash-add-device', 'dash-cameras',
    'dash-camera-live', 'dash-recordings',
    'dash-all-devices',
  ]);
  const applianceKinds = [
    ['light', 'Smart light'], ['fan', 'Ceiling fan'], ['ac', 'Air conditioner'],
    ['tv', 'Television'], ['geyser', 'Water heater'], ['pump', 'Water pump'],
    ['plug', 'Smart plug'], ['exhaust', 'Exhaust fan'],
  ];
  const deviceCatalog = [
    ['Climate Control', [
      ['Ceiling Fan', 'fan', '✳'], ['Exhaust Fan', 'exhaust', '◉'], ['Air Conditioner', 'ac', '❄'],
      ['Heater', 'geyser', '♨'], ['Air Purifier', 'plug', '✧'], ['Smart Thermostat', 'ac', '◉'],
    ]],
    ['Lighting', [
      ['Smart Bulb', 'light', '☼'], ['LED Strip', 'light', '〰'], ['Smart Tube Light', 'light', '┃'],
      ['RGB Light', 'light', '◉'], ['Ceiling Light', 'light', '☼'], ['Outdoor Light', 'light', '☼'],
      ['Decorative Light', 'light', '✧'],
    ]],
    ['Entertainment', [
      ['Smart TV', 'tv', '▣'], ['Home Theatre', 'tv', '♫'], ['Smart Speaker', 'tv', '◖'],
      ['Projector', 'tv', '▰'], ['Media Player', 'tv', '▷'],
    ]],
    ['Office Equipment', [
      ['Desktop Computer', 'plug', '▣'], ['Laptop', 'plug', '▱'], ['Printer', 'plug', '▤'],
      ['Conference Display', 'tv', '▣'], ['Video Conferencing System', 'tv', '◉'],
      ['Smart Whiteboard', 'tv', '▱'], ['Meeting Room Display', 'tv', '▣'],
      ['Smart Office Lighting', 'light', '☼'], ['Office AC', 'ac', '❄'],
    ]],
    ['Security', [
      ['CCTV Camera', 'camera', '◉'],
      ['Smart Door Lock', 'plug', '◇'], ['Motion Sensor', 'plug', '⌁'], ['Door Sensor', 'plug', '⌑'],
      ['Window Sensor', 'plug', '▱'], ['Smoke Detector', 'plug', '◉'], ['Fire Alarm', 'plug', '⚑'],
    ]],
    ['Other Appliances', [
      ['Refrigerator', 'plug', '▯'], ['Washing Machine', 'plug', '◉'], ['Microwave', 'plug', '▣'],
      ['Smart Plug', 'plug', '⌁'], ['Smart Curtains', 'plug', '〰'], ['Water Pump', 'pump', '⌁'],
    ]],
  ].flatMap(([category, items]) => items.map(([name, kind, icon]) => ({ category, name, kind, icon })));
  const nonAppliances = ['ESP32 controller', 'Security sensor', 'Smart meter', 'Other'];
  const defaultRooms = [
    ['Living Room', '⌂'], ['Bedroom', '◷'], ['Kitchen', '♨'],
    ['Bathroom', '◌'], ['Outdoor', '♧'],
  ];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[char]);
  const attr = (value) => esc(value).replace(/`/g, '&#96;');
  const iconChoices = ['☼', '✳', '◉', '❄', '▣', '⌁', '♨', '⌂', '◷', '♧', '▦', '◇'];
  let activeRoute = '';
  let roomId = '';
  let cameraId = '';
  let selectedCatalogName = '';
  let catalogSearch = '';
  let preferredRoom = '';
  let centralFilters = { search: '', home: 'All homes', room: 'All rooms', category: 'All categories', status: 'All devices' };
  let wizardStep = 1;
  let wizardRooms = homes.roomCategories.map((room) => ({
    ...room,
    selected: ['Living Room', 'Bedroom', 'Kitchen'].includes(room.name),
  }));
  let toastTimer;

  function toast(message, error = false) {
    const node = document.querySelector('#dashboard-toast');
    if (!node) return;
    node.textContent = message;
    node.classList.toggle('is-error', error);
    node.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('is-visible'), 3600);
  }

  function run(action, success) {
    try {
      const result = action();
      if (success) toast(success);
      render();
      refreshSelector();
      return result;
    } catch (error) {
      toast(error instanceof Error ? error.message : 'This local home preview action could not be completed.', true);
      return null;
    }
  }

  function go(route) {
    if (window.setRoute) window.setRoute(route);
    else window.location.hash = route;
  }

  function refreshSelector() {
    if (!selector) return;
    try {
      const state = homes.getSnapshot();
      selector.innerHTML = `${state.homes.map((home) => `<option value="${attr(home.id)}"${home.id === state.selectedHomeId ? ' selected' : ''}>${esc(home.icon)} ${esc(home.name)}${home.isDefault ? ' · Default' : ''}</option>`).join('')}<option value="__manage_homes__">Manage homes…</option>`;
      selector.setAttribute('aria-label', `Selected home: ${state.selectedHome.name}`);
      const homeName = document.querySelector('#dashboard-home-name');
      if (homeName) homeName.textContent = state.selectedHome.name;
      const homeCity = document.querySelector('#dashboard-home-location');
      if (homeCity) homeCity.textContent = [state.selectedHome.city, state.selectedHome.state].filter(Boolean).join(', ') || 'Your selected home';
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Home selector could not be refreshed.', true);
    }
  }

  function heading(kicker, title, description, actions = '') {
    return `<header class="homes-heading"><div><p class="dashboard-kicker"><span class="dashboard-live-pip"></span> HOMIOT <i>·</i> ${esc(kicker)}</p><h1>${title}</h1><p>${description}</p></div><div class="homes-heading-actions">${actions}</div></header>`;
  }

  function note(message) {
    return `<div class="homes-demo-note" role="note"><b>Local demo preview.</b> ${message}</div>`;
  }

  function actionMenu(type, id, entries) {
    return `<details class="home-action-menu"><summary aria-label="More ${type} actions" title="More actions">•••</summary><div class="home-action-menu-list" role="menu">${entries.map(([action, label, danger = false]) => `<button type="button" role="menuitem" data-home-action="${action}" data-item-id="${attr(id)}"${danger ? ' class="is-danger"' : ''}>${label}</button>`).join('')}</div></details>`;
  }

  function homeMenu(home) {
    return actionMenu('home', home.id, [
      ['home-view', 'View home'], ['home-edit', 'Edit home'], ['home-rename', 'Rename home'],
      ['home-wallpaper', 'Change home wallpaper'],
    ]);
  }

  function roomMenu(room) {
    return actionMenu('room', room.id, [
      ['room-open', 'Open room'], ['room-edit', 'Edit room'], ['room-rename', 'Rename room'],
      ['room-wallpaper', 'Change wallpaper'], ['room-add-device', 'Add device'],
    ]);
  }

  function deviceMenu(device) {
    return actionMenu('device', device.id, [
      ['device-settings', 'Device settings'], ['device-rename', 'Rename device'],
      ['device-edit', 'Edit device'], ['device-icon', 'Change device icon'],
      ['device-move', 'Move to another room'],
    ]).replace('class="home-action-menu"', `class="home-action-menu" data-home-id="${attr(device.homeId || homes.getCurrentHomeId())}"`);
  }

  function showActionDialog(title, description, fields, submitLabel, options = {}) {
    if (!actionDialog) {
      toast('Home management dialog is unavailable.', true);
      return;
    }
    actionDialog.innerHTML = `<form id="home-action-form" data-action-type="${attr(options.action || '')}" data-item-id="${attr(options.id || '')}" data-room-id="${attr(options.roomId || '')}"><header><span class="home-dialog-kicker">HOMIOT · LOCAL PREVIEW</span><button type="button" class="home-dialog-close" data-home-dialog-close aria-label="Close dialog">×</button></header><h2 id="home-action-title">${esc(title)}</h2><p class="home-dialog-description">${description}</p><div class="home-dialog-fields">${fields}</div><p class="home-dialog-error" aria-live="polite"></p><footer><button type="button" class="homes-secondary" data-home-dialog-close>Cancel</button><button type="submit" class="${options.danger ? 'home-dialog-danger' : 'homes-primary'}">${esc(submitLabel)}</button></footer></form>`;
    actionDialog.showModal();
  }

  function textField(label, name, value, maxLength = 60, required = true) {
    return `<label>${label}<input name="${name}" value="${attr(value)}" maxlength="${maxLength}"${required ? ' required' : ''}></label>`;
  }

  function selectField(label, name, options, selected) {
    return `<label>${label}<select name="${name}" required>${options.map(([value, title]) => `<option value="${attr(value)}"${value === selected ? ' selected' : ''}>${esc(title)}</option>`).join('')}</select></label>`;
  }

  function roomSelectOptions(home, selected, omitId = '') {
    return home.rooms.filter((room) => room.id !== omitId).map((room) => [room.name, room.name]);
  }

  function showRoomRemoval(room, home) {
    const assignedDevices = devices.getDevices().filter((device) => device.room === room.name);
    const assignedCameras = home.cameras.filter((camera) => camera.room === room.name);
    const assignedEquipment = home.equipment.filter((item) => item.room === room.name);
    const destinations = roomSelectOptions(home, '', room.id);
    const assignments = [
      ...assignedDevices.map((device) => selectField(`Move appliance · ${esc(device.name)}`, `devices:${device.id}`, destinations)),
      ...assignedCameras.map((camera) => selectField(`Move camera · ${esc(camera.name)}`, `cameras:${camera.id}`, destinations)),
      ...assignedEquipment.map((item) => selectField(`Move equipment · ${esc(item.name)}`, `equipment:${item.id}`, destinations)),
    ].join('');
    showActionDialog('Remove this room?', `Removing <b>${esc(room.name)}</b> affects its room organization. Move every assigned appliance, camera, and equipment entry to another room first.`, `${assignments || '<p class="home-dialog-empty">No entries are assigned to this room.</p>'}${destinations.length ? '' : '<p class="home-dialog-error">This home needs another room before this room can be removed.</p>'}`, 'Move items & remove room', {
      action: 'room-remove', id: room.id, danger: true,
    });
    const submit = actionDialog.querySelector('[type="submit"]');
    submit.disabled = home.rooms.length <= 1 || !destinations.length;
    if (home.rooms.length <= 1) submit.title = 'Keep at least one room in the home.';
  }

  function openHomeAction(action, id) {
    const home = homes.getSnapshot().homes.find((item) => item.id === id);
    if (!home) { toast('Home not found.', true); return; }
    if (action === 'home-view') {
      run(() => homes.selectHome(home.id), 'Home opened. Device data is now scoped to this home.');
      go('dash-home-overview');
    } else if (action === 'home-edit' || action === 'home-rename') {
      const fields = action === 'home-rename'
        ? textField('Home name', 'name', home.name)
        : `${textField('Home name', 'name', home.name)}${selectField('Home type', 'type', ['House','Apartment','Villa','Office','Farmhouse','Other'].map((value) => [value, value]), home.type)}${selectField('Home icon', 'icon', iconChoices.map((icon) => [icon, icon]), home.icon || '⌂')}${textField('Street address', 'address', home.address || '', 120, false)}${textField('City', 'city', home.city || '', 60, false)}${textField('State / region', 'state', home.state || '', 60, false)}${textField('Country', 'country', home.country || '', 60, false)}`;
      showActionDialog(action === 'home-rename' ? 'Rename home' : 'Edit home details', 'Changes are saved to this browser’s home preview.', fields, 'Save changes', { action, id });
    } else if (action === 'home-wallpaper') {
      showActionDialog('Change home wallpaper', `Choose a visual for <b>${esc(home.name)}</b>.`, selectField('Wallpaper', 'wallpaper', [['','Default exterior'], ...[['living','Luxury living room'],['bedroom','Warm bedroom'],['kitchen','Modern kitchen'],['garden','Garden / outdoor']]], home.wallpaper || ''), 'Save wallpaper', { action, id });
    } else if (action === 'home-remove') {
      showActionDialog('Remove this home?', `Removing <b>${esc(home.name)}</b> also deletes its ${home.rooms.length} room${home.rooms.length === 1 ? '' : 's'}, ${home.deviceCount} appliance/equipment entr${home.deviceCount === 1 ? 'y' : 'ies'}, and ${home.cameraCount} camera entr${home.cameraCount === 1 ? 'y' : 'ies'} from this browser. This cannot be undone. Switch away and change the default home before deleting it.`, `<p class="home-dialog-impact">Home data and local device settings are removed together; other homes are not affected.</p>`, 'Remove home', { action, id, danger: true });
      actionDialog.querySelector('[type="submit"]').disabled = home.id === homes.getCurrentHomeId() || home.isDefault || homes.getSnapshot().homes.length <= 1;
    }
  }

  function openRoomAction(action, id) {
    const home = homes.getCurrentHome();
    const room = home.rooms.find((item) => item.id === id);
    if (!room) { toast('Room not found.', true); return; }
    if (action === 'room-open') {
      roomId = room.id;
      go('dash-room-detail');
    } else if (action === 'room-add-device') {
      preferredRoom = room.name;
      go('dash-add-device');
    } else if (action === 'room-remove') {
      showRoomRemoval(room, home);
    } else if (action === 'room-rename' || action === 'room-edit') {
      const fields = action === 'room-rename'
        ? textField('Room name', 'name', room.name, 32)
        : `${textField('Room name', 'name', room.name, 32)}${selectField('Room category', 'category', homes.roomCategories.map((item) => [item.name, item.name]), room.category || 'Other')}${selectField('Room icon', 'icon', iconChoices.map((icon) => [icon, icon]), room.icon)}`;
      showActionDialog(action === 'room-rename' ? 'Rename room' : 'Edit room', 'Renaming a room also updates appliance and camera assignments.', fields, 'Save changes', { action, id, roomId: id });
    } else if (action === 'room-wallpaper') {
      showActionDialog('Change room wallpaper', `Choose a visual for <b>${esc(room.name)}</b>.`, selectField('Wallpaper', 'wallpaper', [['','Automatic room style'], ...[['living','Luxury living room'],['bedroom','Warm bedroom'],['kitchen','Modern kitchen'],['bathroom','Calm bathroom'],['dining','Elegant dining room'],['study','Study room'],['office','Professional office'],['meeting','Meeting room'],['conference','Conference room'],['hall','Spacious hall'],['garden','Garden / outdoor']]], room.wallpaper || ''), 'Save wallpaper', { action, id });
    }
  }

  function openDeviceAction(action, id, homeId = '') {
    if (homeId && homeId !== homes.getCurrentHomeId()) {
      try { homes.selectHome(homeId); } catch (error) { toast(error instanceof Error ? error.message : 'Device home could not be selected.', true); return; }
    }
    let device;
    try { device = devices.getDeviceById(id); } catch (error) { toast(error.message, true); return; }
    const home = homes.getCurrentHome();
    if (action === 'device-settings') {
      go(`dash-device-${encodeURIComponent(device.id)}`);
    } else if (action === 'device-rename') {
      showActionDialog('Rename device', 'This changes only the local inventory label.', textField('Device name', 'name', device.name, 40), 'Save name', { action, id });
    } else if (action === 'device-edit') {
      const fields = `${textField('Device name', 'name', device.name, 40)}${selectField('Room', 'room', roomSelectOptions(home, device.room), device.room)}${selectField('Device icon', 'icon', iconChoices.map((icon) => [icon, icon]), device.icon || '⌁')}`;
      showActionDialog('Edit device', 'Update this device’s local label, icon, or room assignment.', fields, 'Save device', { action, id });
    } else if (action === 'device-icon') {
      showActionDialog('Change device icon', 'Choose an icon for this inventory entry.', selectField('Device icon', 'icon', iconChoices.map((icon) => [icon, icon]), device.icon || '⌁'), 'Save icon', { action, id });
    } else if (action === 'device-move') {
      showActionDialog('Move device', `Move <b>${esc(device.name)}</b> to another room in ${esc(home.name)}.`, selectField('Destination room', 'room', roomSelectOptions(home, device.room), device.room), 'Move device', { action, id });
    } else if (action === 'device-remove') {
      showActionDialog('Remove this device?', `Remove <b>${esc(device.name)}</b> from ${esc(device.room)}? Only this device and its local schedules will be removed. Other devices and their states will remain unchanged.`, '<p class="home-dialog-impact">No hardware command will be sent. This affects only the local demo inventory.</p>', 'Remove device', { action, id, danger: true });
    }
  }

  function wallpaperStyle(room) {
    return room.wallpaper?.startsWith('data:image/')
      ? ` style="background-image:linear-gradient(135deg,#10213966,#10213930),url('${attr(room.wallpaper)}')"`
      : '';
  }

  function homeCards() {
    const state = homes.getSnapshot();
    return `${heading('YOUR HOMES', 'Homes that feel <em>in sync.</em>', 'Switch between the places you care for, with separate rooms and demo device inventories.', '<button class="homes-primary" data-home-route="dash-add-home">＋ Add a home</button>')}
      ${note('Home, device and room data is stored in this browser only. It is not shared with family members, gateways, or physical hardware.')}
      <div class="homes-summary"><div><b>${state.homes.length}</b><span>Homes in this preview</span></div><div><b>${state.homes.reduce((sum, home) => sum + home.deviceCount, 0)}</b><span>Appliances &amp; equipment</span></div><div><b>${state.homes.reduce((sum, home) => sum + home.cameraCount, 0)}</b><span>Camera entries · offline</span></div></div>
      <section class="homes-card-grid" aria-label="Your homes">${state.homes.map((home) => `<article class="home-preview-card${home.id === state.selectedHomeId ? ' is-selected' : ''}" data-delete-action="home-remove" data-item-id="${attr(home.id)}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this card and press Delete.">
        <div class="home-card-art home-card-art-${esc(home.icon === '♧' ? 'garden' : home.type.toLowerCase())} home-wallpaper-${attr(home.wallpaper || 'default')}"><span class="home-card-symbol">${esc(home.icon)}</span><span class="home-card-state">${home.id === state.selectedHomeId ? 'SELECTED' : home.isDefault ? 'DEFAULT' : 'LOCAL PREVIEW'}</span><button type="button" class="home-favorite" data-home-favorite="${attr(home.id)}" aria-label="${home.favorite ? 'Remove from' : 'Add to'} favorites" aria-pressed="${home.favorite}">${home.favorite ? '★' : '☆'}</button>${homeMenu(home)}</div>
        <div class="home-card-copy"><div><span class="home-type-label">${esc(home.type)}${home.isDefault ? ' · Default' : ''}</span><h2>${esc(home.name)}</h2><p>${esc([home.address, home.city, home.state].filter(Boolean).join(', ') || 'Location not set')}</p></div>
        <div class="home-card-stats"><span>⌂ <b>${home.rooms.length}</b> rooms</span><span>▦ <b>${home.deviceCount}</b> devices</span><span>◉ <b>${home.cameraCount}</b> cameras</span></div>
        <div class="home-card-connect"><i class="${home.connection.startsWith('Online') ? 'is-demo-online' : ''}"></i><span>${esc(home.connection)}</span><small>${esc(home.lastSync)}</small></div>
        <div class="home-card-actions"><button type="button" class="homes-primary" data-home-open="${attr(home.id)}">${home.id === state.selectedHomeId ? 'Open home' : 'Switch to home'} <span>↗</span></button></div>
      </div></article>`).join('')}</section>
      <section class="homes-recent-panel"><div class="homes-section-title"><div><span>QUICK ACCESS</span><h2>Recent homes</h2></div></div><div class="homes-recent-list">${state.recentHomeIds.map((id) => state.homes.find((home) => home.id === id)).filter(Boolean).map((home) => `<button type="button" data-home-open="${attr(home.id)}"><span>${esc(home.icon)}</span><b>${esc(home.name)}</b><small>${esc(home.city || 'Location not set')}</small><i>↗</i></button>`).join('') || '<p>No recent homes yet.</p>'}</div></section>`;
  }

  function wizard() {
    const state = homes.getSnapshot();
    const roomRows = wizardRooms.map((room, index) => `<label class="home-wizard-room"><input type="checkbox" data-wizard-room="${index}"${room.selected ? ' checked' : ''}><span>${esc(room.icon)}</span><b>${esc(room.name)}</b></label>`).join('');
    const body = wizardStep === 1
      ? `<div class="home-wizard-fields"><label>Home name<input name="name" maxlength="60" required placeholder="e.g. Lake House"></label><label>Home type<select name="type"><option>House</option><option>Apartment</option><option>Villa</option><option>Office</option><option>Farmhouse</option><option>Other</option></select></label><label>Street address<input name="address" maxlength="120" autocomplete="street-address" placeholder="Optional"></label><label>City<input name="city" maxlength="60" autocomplete="address-level2" placeholder="Optional"></label><label>State / region<input name="state" maxlength="60" autocomplete="address-level1" placeholder="Optional"></label><label>Country<input name="country" maxlength="60" autocomplete="country-name" placeholder="Optional"></label></div>`
      : wizardStep === 2
        ? `<p class="home-wizard-help">Choose up to eight rooms. These are local labels; empty rooms are welcome.</p><div class="home-wizard-room-grid">${roomRows}</div><div class="home-wizard-add-room"><input id="wizard-custom-room" maxlength="32" placeholder="Add a custom room"><button type="button" data-wizard-add-room>＋ Add room</button></div>`
        : `<p class="home-wizard-help">Choose appliance types to add to this home’s simulated inventory. No hardware is discovered or controlled.</p><div class="home-wizard-fields"><label>Appliance type<select name="kind">${applianceKinds.map(([kind, label]) => `<option value="${kind}">${label}</option>`).join('')}</select></label><label>Device name<input name="deviceName" maxlength="40" placeholder="e.g. Hallway light"></label><label>Room<select name="deviceRoom">${wizardRooms.filter((room) => room.selected).map((room) => `<option>${esc(room.name)}</option>`).join('')}</select></label><button type="button" class="homes-secondary" data-wizard-add-device>Add demo appliance</button></div><div class="home-wizard-added">${(wizardDevices || []).map((device, index) => `<span>${esc(device.name)} · ${esc(device.room)} <button type="button" data-wizard-remove-device="${index}" aria-label="Remove ${attr(device.name)}">×</button></span>`).join('')}</div>
          <div class="home-wizard-fields home-wizard-extra"><label>Other equipment<select name="equipmentType"><option value="">No additional equipment</option>${nonAppliances.map((type) => `<option>${type}</option>`).join('')}</select></label><label>Equipment name<input name="equipmentName" maxlength="48" placeholder="Optional"></label><label>Room<select name="equipmentRoom">${wizardRooms.filter((room) => room.selected).map((room) => `<option>${esc(room.name)}</option>`).join('')}</select></label><button type="button" class="homes-secondary" data-wizard-add-equipment>Add equipment</button></div><div class="home-wizard-added">${(wizardEquipment || []).map((item, index) => `<span>${esc(item.name)} · ${esc(item.category)} <button type="button" data-wizard-remove-equipment="${index}" aria-label="Remove ${attr(item.name)}">×</button></span>`).join('')}</div>`;
    return `${heading('ADD HOME', 'Set up a new <em>space.</em>', 'A few details are enough to create a home preview.', '')}
      ${note('This setup creates local demo entries only. It does not configure Wi-Fi, invite members, or connect a controller.')}
      <section class="home-wizard"><div class="home-wizard-progress" aria-label="Step ${wizardStep} of 3">${[1, 2, 3].map((step) => `<span class="${step === wizardStep ? 'is-current' : step < wizardStep ? 'is-complete' : ''}"><i>${step < wizardStep ? '✓' : step}</i>${['Home details', 'Rooms', 'Equipment'][step - 1]}</span>`).join('')}</div><form id="home-wizard-form"><h2>${['Home details', 'Create your rooms', 'Add demo devices'][wizardStep - 1]}</h2>${body}<p class="homes-form-error" id="home-wizard-error" aria-live="polite"></p><div class="home-wizard-actions"><button type="button" class="homes-secondary" data-home-route="dash-homes">Cancel</button>${wizardStep > 1 ? '<button type="button" class="homes-secondary" data-wizard-back>Back</button>' : ''}<button type="submit" class="homes-primary">${wizardStep === 3 ? 'Create home' : 'Continue'} <span>→</span></button></div></form></section>`;
  }

  let wizardDevices = [];
  let wizardEquipment = [];
  let wizardDetails = null;

  function homeOverview() {
    const home = homes.getCurrentHome();
    const inventory = devices.getDevices();
    const state = homes.getSnapshot();
    const summary = state.selectedHome;
    return `${heading('HOME OVERVIEW', `Welcome to <em>${esc(home.name)}.</em>`, 'A quick view of this home’s rooms, devices, and connection status.', '<button type="button" class="homes-secondary" data-home-route="dash-home-rooms">Manage rooms</button><button type="button" class="homes-primary" data-home-route="dash-add-device">＋ Add device</button>')}
      ${note('Demo devices and telemetry are local simulations. No gateway, appliance, or camera is connected.')}
      <section class="home-overview-hero"><div><span>${esc(home.icon)} ${esc(home.type)} · SELECTED HOME</span><h2>${esc(home.name)}</h2><p>${esc([home.address, home.city, home.state, home.country].filter(Boolean).join(', ') || 'Add a location in Home Settings')}</p><div class="home-overview-actions"><button type="button" class="homes-primary" data-home-route="dash-devices">Control appliances <span>↗</span></button><button type="button" class="homes-secondary" data-home-route="dash-home-settings">Home settings</button></div></div><div class="home-overview-metrics"><span><b>${home.rooms.length}</b>Rooms</span><span><b>${summary.deviceCount}</b>Devices</span><span><b>${home.cameras.length}</b>Cameras</span><span><b>${summary.energyKwh}</b>Demo kWh today</span></div></section>
      <div class="homes-overview-grid">      <section class="homes-panel"><div class="homes-section-title"><div><span>ROOMS</span><h2>Spaces in this home</h2></div><button type="button" data-home-route="dash-home-rooms">View all →</button></div><div class="home-room-tile-grid">${home.rooms.map((room) => `<button type="button" class="home-room-tile home-wallpaper-${attr(['living', 'bedroom', 'kitchen', 'bathroom', 'dining', 'study', 'office', 'meeting', 'conference', 'hall', 'garden'].includes(room.wallpaper) ? room.wallpaper : 'living')}"${wallpaperStyle(room)} data-open-room="${attr(room.id)}"><span>${esc(room.icon)}</span><b>${esc(room.name)}</b><small>${inventory.filter((device) => device.room === room.name).length} appliances</small><i>↗</i></button>`).join('') || '<p class="homes-empty">No rooms yet. Add one to organize this home.</p>'}</div></section>
      <section class="homes-panel"><div class="homes-section-title"><div><span>CONNECTIVITY</span><h2>Home system status</h2></div><span class="homes-status-pill">PREVIEW</span></div><div class="home-health-row"><i></i><span><b>Gateway</b><small>No gateway connected</small></span><strong>Not connected</strong></div><div class="home-health-row"><i></i><span><b>Appliances</b><small>State is local demo data</small></span><strong>${inventory.length} entries</strong></div><div class="home-health-row"><i></i><span><b>Security cameras</b><small>No media service available</small></span><strong>${home.cameras.length} offline</strong></div><button type="button" class="homes-wide-link" data-home-route="dash-cameras">Open camera dashboard <span>→</span></button></section></div>`;
  }

  function roomDeviceCard(device) {
    return `<article class="home-device-inventory-card" data-delete-action="device-remove" data-item-id="${attr(device.id)}" data-home-id="${attr(device.homeId || homes.getCurrentHomeId())}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this card and press Delete."><span class="device-kind-glyph">${esc(device.icon || applianceKinds.find(([kind]) => kind === device.kind)?.[1]?.slice(0, 1) || '•')}</span><span><b>${esc(device.name)}</b><small>${esc(device.displayType || device.kind)} · simulated · ${device.online ? (device.on ? 'On' : 'Off') : 'Offline, state unknown'}</small></span>${deviceMenu(device)}</article>`;
  }

  function roomListCard(item, home, inventory) {
    const wallpapers = [['living','Living room'],['bedroom','Bedroom'],['kitchen','Kitchen'],['bathroom','Bathroom'],['dining','Dining room'],['study','Study room'],['office','Office'],['meeting','Meeting room'],['conference','Conference room'],['hall','Hall'],['garden','Garden']];
    return `<article class="home-room-list-card" data-delete-action="room-remove" data-item-id="${attr(item.id)}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this card and press Delete."><span class="home-room-mini-art home-wallpaper-${attr(['living', 'bedroom', 'kitchen', 'bathroom', 'dining', 'study', 'office', 'meeting', 'conference', 'hall', 'garden'].includes(item.wallpaper) ? item.wallpaper : 'living')}"${wallpaperStyle(item)}>${esc(item.icon)}</span><div><b>${esc(item.name)}</b><small>${inventory.filter((device) => device.room === item.name).length} appliances · ${home.cameras.filter((camera) => camera.room === item.name).length} cameras</small></div><select data-room-category="${attr(item.id)}" aria-label="Category for ${attr(item.name)}">${homes.roomCategories.map((category) => `<option value="${attr(category.name)}"${(item.category || homes.roomCategories.find((entry) => entry.name === item.name)?.name || 'Other') === category.name ? ' selected' : ''}>${esc(category.name)}</option>`).join('')}</select><select data-room-wallpaper="${attr(item.id)}" aria-label="Wallpaper for ${attr(item.name)}">${wallpapers.map(([value,label])=>`<option value="${value}"${(item.wallpaper || 'living') === value ? ' selected' : ''}>${label}</option>`).join('')}</select><button type="button" data-room-open="${attr(item.id)}">Open</button>${roomMenu(item)}</article>`;
  }

  function roomsPage() {
    const home = homes.getCurrentHome();
    const room = roomId ? home.rooms.find((item) => item.id === roomId) : null;
    const inventory = devices.getDevices();
    const selectedRoom = room?.name;
    return `${heading(room ? 'ROOM DETAILS' : 'ROOM MANAGEMENT', room ? `${esc(room.icon)} <em>${esc(room.name)}.</em>` : 'Every room, <em>in its place.</em>', room ? `Appliances assigned to ${esc(room.name)} in ${esc(home.name)}.` : `Organize spaces in ${esc(home.name)}. A home can have up to eight rooms.`, `<button type="button" class="homes-secondary" data-home-route="dash-home-overview">← Home overview</button>${room ? roomMenu(room) : ''}<button type="button" class="homes-primary" ${room ? `data-room-add-device="${attr(room.name)}"` : 'data-home-route="dash-add-device"'}>＋ Add device</button>`)}
      ${note('Rooms are isolated by home. Changing a room name updates appliance and camera labels stored for this home only.')}
      <div class="homes-overview-grid"><section class="homes-panel"><div class="homes-section-title"><div><span>${room ? 'ROOM INVENTORY' : 'ROOMS'}</span><h2>${room ? esc(room.name) : `${home.rooms.length} of 8 rooms`}</h2></div></div>
        ${room ? `<div class="home-room-inventory">${inventory.filter((device) => device.room === selectedRoom).map(roomDeviceCard).join('') || '<p class="homes-empty">This room has no appliances assigned.</p>'}<button type="button" class="homes-wide-link" data-room-add-device="${attr(room.name)}">＋ Add a device to ${esc(room.name)}</button><button type="button" class="homes-wide-link" data-home-route="dash-devices">Open device controls <span>→</span></button></div>${['Meeting Room','Conference Room','Board Room','Reception Area','Workstation Area'].includes(room.category) || /meeting|conference|office/i.test(room.name) ? `<section class="office-room-panel"><div class="homes-section-title"><div><span>WORKPLACE CONTROL</span><h2>${esc(room.category || 'Office')} overview</h2></div><span class="homes-status-pill">LOCAL DEMO</span></div><div class="office-room-status"><span>Availability <b>Available · preview</b></span><span>Room devices <b>${inventory.filter((device) => device.room === room.name).length}</b></span><span>Connection <b>Not verified</b></span></div><p>Room devices can be managed from the centralized device page. Display, projector, climate and lighting controls are simulated.</p><button type="button" class="homes-secondary" data-home-route="dash-all-devices">Open workplace device controls</button></section>` : ''}`
          : `<div class="home-room-list">${home.rooms.map((item) => roomListCard(item, home, inventory)).join('') || '<p class="homes-empty">No rooms yet.</p>'}</div>
          <form id="home-room-form" class="home-add-room-form"><h3>Add a room <small>${home.rooms.length}/8</small></h3><div><label>Room category<select id="home-room-category" name="category">${homes.roomCategories.map((item) => `<option value="${attr(item.name)}">${esc(item.name)}</option>`).join('')}<option value="Custom">Custom</option></select></label><label>Room name<input name="name" maxlength="32" required placeholder="Category name or custom label"></label><label>Icon<select name="icon"><option>⌂</option><option>◷</option><option>♨</option><option>◌</option><option>☼</option><option>♧</option><option>▦</option></select></label><label>Interior wallpaper<select name="wallpaper"><option value="">Automatic room style</option><option value="living">Luxury living room</option><option value="bedroom">Warm bedroom</option><option value="kitchen">Modern kitchen</option><option value="bathroom">Calm bathroom</option><option value="dining">Elegant dining room</option><option value="study">Study room</option><option value="office">Professional office</option><option value="meeting">Meeting room</option><option value="conference">Conference room</option><option value="hall">Spacious hall</option><option value="garden">Garden / outdoor</option></select></label><label>Or upload a wallpaper<input id="home-room-wallpaper-file" type="file" accept="image/png,image/jpeg,image/webp"><input id="home-room-wallpaper-data" name="wallpaperFile" type="hidden"></label><button class="homes-primary" type="submit"${home.rooms.length >= 8 ? ' disabled' : ''}>Add room</button></div><p class="home-add-room-help">Choose a preset or upload PNG, JPEG, or WebP under 512 KB. Wallpaper files remain local in this browser.</p><p class="homes-form-error" aria-live="polite"></p></form>`}
      </section><section class="homes-panel"><div class="homes-section-title"><div><span>ASSIGNMENTS</span><h2>Appliances by room</h2></div></div><div class="home-room-assignments">${inventory.map((device) => `<label><span><b>${esc(device.name)}</b><small>${esc(device.kind)} · local demo</small></span><select data-home-device-room="${attr(device.id)}" aria-label="Assign ${attr(device.name)} to a room">${home.rooms.map((item) => `<option value="${attr(item.name)}"${item.name === device.room ? ' selected' : ''}>${esc(item.name)}</option>`).join('')}${!home.rooms.some((item) => item.name === device.room) ? `<option selected value="${attr(device.room)}">${esc(device.room)} (unassigned)</option>` : ''}</select></label>`).join('') || '<p class="homes-empty">No appliances in this home. Add demo devices to begin.</p>'}</div></section></div>`;
  }

  function addDevicePage() {
    const home = homes.getCurrentHome();
    if (!home.rooms.some((room) => room.name === preferredRoom)) preferredRoom = '';
    const categories = [...new Set(deviceCatalog.map((item) => item.category))];
    return `${heading('ADD DEVICE', 'Bring a device into <em>${esc(home.name)}.</em>', 'Search the device catalog, select a room, and add one or more local preview devices.', '<button type="button" class="homes-secondary" data-home-route="dash-home-overview">← Home overview</button>')}
      ${note('Adding a device creates a simulated local entry. It does not pair, discover, or send commands to hardware.')}
      <section class="homes-panel home-add-device-panel"><div class="home-catalog-controls"><label>Search devices<input id="device-catalog-search" type="search" value="${attr(catalogSearch)}" placeholder="e.g. ceiling fan, projector" aria-label="Search device catalog"></label><label>Category<select id="device-catalog-category"><option>All categories</option>${categories.map((category) => `<option>${esc(category)}</option>`).join('')}</select></label></div>
      <div class="home-device-catalog">${catalogGroups()}</div>
      <form id="home-add-device-form"><h2>Add selected device</h2><p class="home-selected-device" id="home-selected-device">${selectedCatalogName ? `Selected: ${esc(selectedCatalogName)}` : 'Select a device category above.'}</p><input type="hidden" name="kind" value="${attr(deviceCatalog.find((item) => item.name === selectedCatalogName)?.kind || '')}"><input type="hidden" name="displayType" value="${attr(selectedCatalogName)}"><input type="hidden" name="category" value="${attr(deviceCatalog.find((item) => item.name === selectedCatalogName)?.category || '')}"><input type="hidden" name="icon" value="${attr(deviceCatalog.find((item) => item.name === selectedCatalogName)?.icon || '')}"><div class="home-wizard-fields"><label>Custom device name<input name="name" maxlength="40" required value="${attr(selectedCatalogName)}" placeholder="Name this device"></label><label>Destination room<select name="room" required>${home.rooms.map((item) => `<option${item.name === preferredRoom ? ' selected' : ''}>${esc(item.name)}</option>`).join('')}</select></label></div><p class="home-safety-copy">Safety-critical and high-power hardware labels are illustrative only. Use rated, isolated equipment installed by a qualified electrician.</p><p class="homes-form-error" aria-live="polite"></p><button class="homes-primary" type="submit"${!selectedCatalogName ? ' disabled' : ''}>Add to local inventory <span>→</span></button></form></section>`;
  }

  function catalogGroups() {
    const query = catalogSearch.trim().toLowerCase();
    const category = document.querySelector('#device-catalog-category')?.value || 'All categories';
    const matching = deviceCatalog.filter((item) => (category === 'All categories' || item.category === category)
      && (!query || `${item.name} ${item.category}`.toLowerCase().includes(query)));
    if (!matching.length) return '<p class="homes-empty">No device types match. Try another search.</p>';
    return [...new Set(matching.map((item) => item.category))].map((group) => `<section class="home-catalog-group"><h3>${esc(group)}</h3><div>${matching.filter((item) => item.category === group).map((item) => `<button type="button" class="home-catalog-item${item.name === selectedCatalogName ? ' is-selected' : ''}" data-catalog-device="${attr(item.name)}"><span>${esc(item.icon)}</span><b>${esc(item.name)}</b><small>${esc(group)}</small></button>`).join('')}</div></section>`).join('');
  }

  function applianceForm(home) {
    return `<div class="home-wizard-fields"><label>Appliance type<select name="kind">${applianceKinds.map(([kind, label]) => `<option value="${kind}">${label}</option>`).join('')}</select></label><label>Display name<input name="name" maxlength="40" required placeholder="e.g. Hallway light"></label><label>Room<select name="room" required>${home.rooms.map((item) => `<option>${esc(item.name)}</option>`).join('')}</select></label></div><p class="home-safety-copy">Demo only. High-power devices need properly rated, isolated equipment installed by a qualified electrician. Protective systems must never be bypassed.</p>`;
  }

  function equipmentForm(home) {
    return `<div class="home-wizard-fields"><label>Equipment type<select name="category">${nonAppliances.map((item) => `<option>${item}</option>`).join('')}</select></label><label>Display name<input name="name" maxlength="48" required placeholder="e.g. ESP32 gateway"></label><label>Room<select name="room">${home.rooms.map((item) => `<option>${esc(item.name)}</option>`).join('')}</select></label><label>Demo identifier<input name="identifier" maxlength="64" placeholder="Optional, no secrets"></label></div><p class="home-safety-copy">This is an inventory label only. No controller, sensor, cloud API, or protocol connection is established.</p>`;
  }

  function centralizedDevices() {
    const state = homes.getSnapshot();
    const records = state.homes.flatMap((home) => [
      ...devices.getDevicesForHome(home.id).map((device) => ({
        ...device, displayType: device.displayType || applianceKinds.find(([kind]) => kind === device.kind)?.[1] || device.kind,
        category: device.category || (['light'].includes(device.kind) ? 'Lighting'
          : ['fan', 'exhaust', 'ac', 'geyser'].includes(device.kind) ? 'Climate Control'
            : ['tv'].includes(device.kind) ? 'Entertainment' : 'Other Appliances'),
        homeId: home.id, homeName: home.name, recordType: 'appliance',
      })),
      ...home.equipment.map((item) => ({
        id: item.id, name: item.name, room: item.room || 'Unassigned',
        displayType: item.category, category: 'Office Equipment', online: false, on: false,
        homeId: home.id, homeName: home.name, recordType: 'equipment',
      })),
      ...home.cameras.map((camera) => ({
        id: camera.id, name: camera.name, room: camera.room || 'Unassigned',
        displayType: camera.cameraType, category: 'Security', online: false, on: false,
        homeId: home.id, homeName: home.name, recordType: 'camera',
      })),
    ]);
    const filtered = records.filter((device) => {
      const stateMatch = centralFilters.status === 'All devices'
        || (centralFilters.status === 'Online' && device.online)
        || (centralFilters.status === 'Offline' && !device.online)
        || (centralFilters.status === 'Active' && device.online && device.on)
        || (centralFilters.status === 'Recently used' && device.recordType === 'appliance' && device.online);
      return stateMatch
        && (centralFilters.home === 'All homes' || device.homeId === centralFilters.home)
        && (centralFilters.room === 'All rooms' || device.room === centralFilters.room)
        && (centralFilters.category === 'All categories' || device.category === centralFilters.category)
        && (!centralFilters.search || `${device.name} ${device.displayType} ${device.room} ${device.homeName}`.toLowerCase().includes(centralFilters.search.toLowerCase()));
    });
    const online = records.filter((item) => item.online).length;
    const offline = records.length - online;
    const roomOptions = [...new Set(records.map((item) => item.room))].sort();
    const categoryOptions = [...new Set(records.map((item) => item.category).filter(Boolean))].sort();
    return `${heading('CENTRAL DEVICE MANAGEMENT', 'Every device, <em>one place.</em>', 'Search and filter the local inventory across all of your homes and workplaces.', '<button type="button" class="homes-primary" data-home-route="dash-add-device">＋ Add device</button>')}
      ${note('Device states are simulated and stored locally per home. Offline entries are unverified and cannot be controlled here.')}
      <div class="homes-summary"><div><b>${records.length}</b><span>Inventory entries</span></div><div><b>${online}</b><span>Online · demo</span></div><div><b>${offline}</b><span>Offline / unverified</span></div></div>
      <section class="homes-panel central-device-panel"><div class="central-device-filters"><label>Search<input id="central-device-search" type="search" value="${attr(centralFilters.search)}" placeholder="Device, home, room"></label><label>Home<select id="central-device-home"><option>All homes</option>${state.homes.map((home) => `<option value="${attr(home.id)}"${centralFilters.home === home.id ? ' selected' : ''}>${esc(home.name)}</option>`).join('')}</select></label><label>Room<select id="central-device-room"><option>All rooms</option>${roomOptions.map((room) => `<option${centralFilters.room === room ? ' selected' : ''}>${esc(room)}</option>`).join('')}</select></label><label>Category<select id="central-device-category"><option>All categories</option>${categoryOptions.map((category) => `<option${centralFilters.category === category ? ' selected' : ''}>${esc(category)}</option>`).join('')}</select></label><label>Status<select id="central-device-status">${['All devices','Online','Offline','Active','Recently used'].map((status) => `<option${centralFilters.status === status ? ' selected' : ''}>${status}</option>`).join('')}</select></label></div>
      <div class="central-device-list">${filtered.map((device) => `<article class="central-device-row"${device.recordType === 'appliance' ? ` data-delete-action="device-remove" data-item-id="${attr(device.id)}" data-home-id="${attr(device.homeId)}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this row and press Delete."` : ''}><span class="central-device-icon">${esc(device.icon || (device.recordType === 'camera' ? '◉' : device.recordType === 'equipment' ? '⌘' : '⌂'))}</span><div class="central-device-name"><b>${esc(device.name)}</b><small>${esc(device.displayType || device.category)} · ${esc(device.room)} · ${esc(device.homeName)}</small></div><span class="central-state ${device.online ? 'is-online' : ''}"><i></i>${device.online ? `${device.on ? 'On' : 'Off'} · demo` : device.recordType === 'camera' ? 'Offline · no stream' : 'Offline · unverified'}</span>${device.recordType === 'appliance' ? `<label class="device-toggle" title="Simulated control for ${attr(device.name)}"><input type="checkbox" data-central-toggle="${attr(device.id)}" data-home-id="${attr(device.homeId)}" aria-label="Turn ${attr(device.name)} ${device.on ? 'off' : 'on'} · demo only"${device.on ? ' checked' : ''}${device.online ? '' : ' disabled'}><span class="device-toggle-track"></span></label>${deviceMenu(device)}<button type="button" data-central-open="${attr(device.homeId)}|${attr(device.id)}">Manage ↗</button>` : '<span class="central-no-control">Inventory only</span>'}</article>`).join('') || '<div class="homes-empty">No entries match those filters.</div>'}</div><p class="central-results">${filtered.length} of ${records.length} entries · all statuses are demo data</p></section>`;
  }

  function camerasPage() {
    const home = homes.getCurrentHome();
    return `${heading('CCTV', `A clearer view of <em>${esc(home.name)}.</em>`, 'Manage camera labels and see connection readiness for this home.', '<button type="button" class="homes-secondary" data-home-route="dash-recordings">Recording history</button>')}
      ${note('No camera stream or recording backend is connected. Camera credentials are never stored. Live view and playback are unavailable in this prototype.')}
      <div class="camera-overview-strip"><span><b>${home.cameras.length}</b> Camera entries</span><span><b>0</b> Connected streams</span><span><b>0</b> Recordings available</span><span class="homes-status-pill">OFFLINE PREVIEW</span></div>
      <div class="camera-layout"><section class="homes-panel camera-add-panel"><div class="homes-section-title"><div><span>LOCAL CAMERA INVENTORY</span><h2>Add a camera</h2></div></div><form id="camera-add-form"><label>Camera name<input name="name" maxlength="48" required placeholder="e.g. Front entrance"></label><label>Camera type<select name="cameraType"><option>IP camera</option><option>RTSP camera</option><option>ONVIF camera</option><option>USB camera</option><option>Other</option></select></label><label>Room<select name="room"><option value="">Unassigned</option>${home.rooms.map((item) => `<option>${esc(item.name)}</option>`).join('')}</select></label><label>Camera address or ID<input name="identifier" maxlength="100" placeholder="Optional"></label><label>Camera password <input name="password" type="password" autocomplete="new-password" placeholder="Never saved or transmitted"></label><p class="homes-form-error" aria-live="polite"></p><button class="homes-primary" type="submit">Add offline camera entry</button></form></section>
      <section class="camera-list">${home.cameras.map((camera) => `<article class="camera-card"><div class="camera-thumbnail"><span>◉</span><b>STREAM UNAVAILABLE</b><small>No authenticated media gateway</small></div><div class="camera-card-content"><span class="homes-status-pill">OFFLINE</span><h2>${esc(camera.name)}</h2><p>${esc(camera.cameraType)}${camera.room ? ` · ${esc(camera.room)}` : ''}</p><small>${esc(camera.identifier || 'No address or ID saved')} · Credentials are not stored</small><div class="camera-card-actions"><button type="button" data-camera-live="${attr(camera.id)}">Try live view</button><button type="button" data-camera-edit="${attr(camera.id)}">Rename</button><button type="button" data-camera-remove="${attr(camera.id)}" aria-label="Remove ${attr(camera.name)}">Remove</button></div></div></article>`).join('') || '<div class="homes-panel homes-empty camera-empty"><span>◉</span><b>No cameras added yet</b><p>Add a camera inventory entry. Live video will remain unavailable until a secure media gateway is integrated.</p></div>'}</section></div>`;
  }

  function liveView() {
    const home = homes.getCurrentHome();
    const camera = home.cameras.find((item) => item.id === cameraId);
    if (!camera) return `${heading('CAMERA VIEW', 'Camera unavailable', 'This camera entry is not in the selected home.', '<button type="button" class="homes-secondary" data-home-route="dash-cameras">← Cameras</button>')}`;
    return `${heading('CAMERA LIVE VIEW', esc(camera.name), `${esc(home.name)} · ${esc(camera.room || 'Room unassigned')}`, '<button type="button" class="homes-secondary" data-home-route="dash-cameras">← Camera dashboard</button>')}
      ${note('The live-view request cannot be made: no authenticated camera/media gateway is configured. This view does not load a stream, snapshot, or recording.')}
      <section class="camera-live-panel"><div class="camera-live-screen" role="img" aria-label="Live camera video unavailable"><div class="camera-offline-mark">◉</div><b>LIVE VIEW UNAVAILABLE</b><p>No secure media gateway is connected to this local demo.</p><span>Camera: ${esc(camera.name)} · ${esc(camera.status)}</span></div><div class="camera-live-controls"><span class="homes-status-pill">NOT CONNECTED</span><button type="button" disabled title="A media gateway is required">Take snapshot</button><button type="button" disabled title="A recording service is required">Start recording</button><button type="button" data-home-route="dash-recordings">Recording history</button></div><div class="camera-live-meta"><span>Camera type <b>${esc(camera.cameraType)}</b></span><span>Last activity <b>${esc(camera.lastActivity)}</b></span><span>Recording state <b>${esc(camera.recording)}</b></span></div></section>`;
  }

  function recordingsPage() {
    const home = homes.getCurrentHome();
    return `${heading('RECORDING HISTORY', 'Your recordings, <em>when connected.</em>', `Browse camera recordings for ${esc(home.name)}.`, '<button type="button" class="homes-secondary" data-home-route="dash-cameras">← Cameras</button>')}
      ${note('Recording storage and playback require a connected camera service. No recordings exist in this prototype; no video is being captured.')}
      <section class="recordings-panel"><div class="recordings-filters"><label>Camera<select><option>All cameras</option>${home.cameras.map((camera) => `<option>${esc(camera.name)}</option>`).join('')}</select></label><label>From<input type="date"></label><label>To<input type="date"></label><button type="button" disabled>Search recordings</button></div><div class="recordings-empty"><span>▣</span><h2>No recordings available</h2><p>Connect an authenticated media gateway and recording service to make video history available.</p></div></section>`;
  }

  function workplaceRoomPanel(room, inventory) {
    return `<section class="office-room-panel"><div class="homes-section-title"><div><span>WORKPLACE CONTROL</span><h2>${esc(room.category || 'Office')} overview</h2></div><span class="homes-status-pill">LOCAL DEMO</span></div><div class="office-room-status"><span>Availability <b>Available · preview</b></span><span>Room devices <b>${inventory.filter((device) => device.room === room.name).length}</b></span><span>Connection <b>Not verified</b></span></div><p>Room devices can be managed from the centralized device page. Display, projector, climate and lighting controls are simulated.</p><button type="button" class="homes-secondary" data-home-route="dash-all-devices">Open workplace device controls</button></section>`;
  }

  function render() {
    if (!routes.has(activeRoute)) return;
    refreshSelector();
    if (activeRoute === 'dash-home-settings') {
      root.hidden = true;
      window.SmartNestSettingsModule?.handleRoute(activeRoute);
      return;
    }
    root.hidden = false;
    root.dataset.route = activeRoute;
    root.innerHTML = activeRoute === 'dash-homes' ? homeCards()
      : activeRoute === 'dash-add-home' ? wizard()
        : activeRoute === 'dash-home-overview' ? homeOverview()
          : activeRoute === 'dash-home-rooms' || activeRoute === 'dash-room-detail' ? roomsPage()
            : activeRoute === 'dash-add-device' ? addDevicePage()
              : activeRoute === 'dash-all-devices' ? centralizedDevices()
              : activeRoute === 'dash-cameras' ? camerasPage()
                  : activeRoute === 'dash-camera-live' ? liveView() : recordingsPage();
    if (activeRoute === 'dash-room-detail' && roomId) {
      const home = homes.getCurrentHome();
      const room = home.rooms.find((item) => item.id === roomId);
      const workplace = room && /office|work|meeting|conference|board/i.test(`${room.name} ${room.category || ''}`);
      const inventory = devices.getDevices();
      if (workplace && !root.querySelector('.office-room-panel')) {
        root.querySelector('.home-room-inventory')?.insertAdjacentHTML('beforeend', workplaceRoomPanel(room, inventory));
      }
    }
    document.querySelector('#dashboard-content').hidden = true;
    document.querySelector('#device-management').hidden = true;
    document.querySelector('#device-detail-page').hidden = true;
    document.querySelector('#advanced-features').hidden = true;
    document.querySelector('#settings-module').hidden = true;
  }

  function handleRoute(route) {
    activeRoute = route;
    root.hidden = !routes.has(route);
    if (routes.has(route)) render();
  }

  function submitWizard(form) {
    const errorNode = document.querySelector('#home-wizard-error');
    if (wizardStep === 1) {
      const data = Object.fromEntries(new FormData(form).entries());
      wizardDetails = data;
      wizardStep = 2;
      render();
      return;
    }
    if (wizardStep === 2) {
      const selected = wizardRooms.filter((room) => room.selected);
      if (!selected.length) { errorNode.textContent = 'Choose at least one room for this home.'; return; }
      if (selected.length > 8) { errorNode.textContent = 'A home can have at most eight rooms.'; return; }
      wizardStep = 3;
      render();
      return;
    }
    try {
      const roomList = wizardRooms.filter((room) => room.selected).map(({ name, icon }) => ({ name, icon }));
      const home = homes.createHome(wizardDetails, roomList);
      wizardDevices.forEach((device) => devices.addDevice(device.kind, device.name, device.room));
      wizardEquipment.forEach((item, index) => homes.addEquipment({ ...item, deviceId: `${home.id}-equipment-${Date.now()}-${index}` }));
      wizardDevices = [];
      wizardEquipment = [];
      wizardDetails = null;
      wizardStep = 1;
      go('dash-home-overview');
    } catch (error) {
      errorNode.textContent = error instanceof Error ? error.message : 'The home could not be created.';
    }
  }

  function handleClick(event) {
    const menuAction = event.target.closest('[data-home-action]');
    if (menuAction) {
      const menu = menuAction.closest('.home-action-menu');
      if (menu) menu.open = false;
      const action = menuAction.dataset.homeAction;
      const id = menuAction.dataset.itemId;
      if (action.startsWith('home-')) openHomeAction(action, id);
      else if (action.startsWith('room-')) openRoomAction(action, id);
      else if (action.startsWith('device-')) openDeviceAction(action, id, menu?.dataset.homeId || menuAction.dataset.homeId || '');
      return;
    }
    if (event.target.closest('[data-home-dialog-close]')) {
      actionDialog.close();
      return;
    }
    const route = event.target.closest('[data-home-route]');
    if (route) { go(route.dataset.homeRoute); return; }
    const centralOpen = event.target.closest('[data-central-open]');
    if (centralOpen) {
      const [homeId, deviceId] = centralOpen.dataset.centralOpen.split('|');
      try {
        homes.selectHome(homeId);
        go(`dash-device-${deviceId}`);
      } catch (error) {
        toast(error instanceof Error ? error.message : 'The device home could not be opened.', true);
      }
      return;
    }
    const open = event.target.closest('[data-home-open]');
    if (open) {
      run(() => homes.selectHome(open.dataset.homeOpen), 'Selected home updated. Device data is now scoped to that home.');
      go('dash-home-overview');
      return;
    }
    const favorite = event.target.closest('[data-home-favorite]');
    if (favorite) { run(() => homes.toggleFavorite(favorite.dataset.homeFavorite), 'Home favorites updated.'); return; }
    const edit = event.target.closest('[data-home-edit]');
    if (edit) {
      const home = homes.getSnapshot().homes.find((item) => item.id === edit.dataset.homeEdit);
      if (!home) return;
      const name = window.prompt('Home name', home.name);
      if (name !== null) run(() => homes.updateHome(home.id, { name }), 'Home name updated.');
      return;
    }
    const remove = event.target.closest('[data-home-remove]');
    if (remove) {
      const home = homes.getSnapshot().homes.find((item) => item.id === remove.dataset.homeRemove);
      if (home && window.confirm(`Remove ${home.name} and its local device preview data? This cannot be undone.`)) run(() => homes.removeHome(home.id), 'Home and its local device data removed.');
      return;
    }
    const back = event.target.closest('[data-wizard-back]');
    if (back) { wizardStep = Math.max(1, wizardStep - 1); render(); return; }
    const addRoom = event.target.closest('[data-wizard-add-room]');
    if (addRoom) {
      const input = document.querySelector('#wizard-custom-room');
      const name = input.value.trim();
      if (!name) { toast('Enter a room name first.', true); return; }
      if (wizardRooms.length >= 8) { toast('A home can have at most eight rooms.', true); return; }
      wizardRooms.push({ name, icon: '⌂', selected: true });
      render();
      return;
    }
    const addDemoDevice = event.target.closest('[data-wizard-add-device]');
    if (addDemoDevice) {
      const form = document.querySelector('#home-wizard-form');
      const name = form.elements.deviceName.value.trim();
      if (!name) { toast('Enter a name for the demo appliance.', true); return; }
      wizardDevices.push({ kind: form.elements.kind.value, name, room: form.elements.deviceRoom.value });
      render();
      return;
    }
    const catalogDevice = event.target.closest('[data-catalog-device]');
    if (catalogDevice) {
      const selected = deviceCatalog.find((item) => item.name === catalogDevice.dataset.catalogDevice);
      if (!selected) return;
      if (selected.kind === 'camera') {
        go('dash-cameras');
        window.setTimeout(() => {
          const cameraName = document.querySelector('#camera-add-form [name="name"]');
          if (cameraName) cameraName.value = 'New camera';
        }, 0);
        return;
      }
      selectedCatalogName = selected.name;
      render();
      return;
    }
    const removeWizardDevice = event.target.closest('[data-wizard-remove-device]');
    if (removeWizardDevice) { wizardDevices.splice(Number(removeWizardDevice.dataset.wizardRemoveDevice), 1); render(); return; }
    const addEquipment = event.target.closest('[data-wizard-add-equipment]');
    if (addEquipment) {
      const form = document.querySelector('#home-wizard-form');
      const category = form.elements.equipmentType.value;
      const name = form.elements.equipmentName.value.trim();
      if (!category || !name) { toast('Choose an equipment type and enter its display name.', true); return; }
      wizardEquipment.push({ category, name, room: form.elements.equipmentRoom.value });
      render();
      return;
    }
    const removeWizardEquipment = event.target.closest('[data-wizard-remove-equipment]');
    if (removeWizardEquipment) { wizardEquipment.splice(Number(removeWizardEquipment.dataset.wizardRemoveEquipment), 1); render(); return; }
    const roomOpen = event.target.closest('[data-room-open], [data-open-room]');
    if (roomOpen) {
      roomId = roomOpen.dataset.roomOpen || roomOpen.dataset.openRoom;
      go(roomOpen.hasAttribute('data-open-room') ? 'dash-room-detail' : 'dash-home-rooms');
      return;
    }
    const roomAddDevice = event.target.closest('[data-room-add-device]');
    if (roomAddDevice) {
      preferredRoom = roomAddDevice.dataset.roomAddDevice;
      go('dash-add-device');
      return;
    }
    const roomEdit = event.target.closest('[data-room-edit-home]');
    if (roomEdit) {
      const room = homes.getRooms().find((item) => item.id === roomEdit.dataset.roomEditHome);
      if (!room) return;
      const name = window.prompt('Room name', room.name);
      if (name !== null) run(() => homes.saveRoom({ id: room.id, name }), 'Room name updated.');
      return;
    }
    const roomDelete = event.target.closest('[data-room-delete-home]');
    if (roomDelete) {
      const room = homes.getRooms().find((item) => item.id === roomDelete.dataset.roomDeleteHome);
      if (room && window.confirm(`Remove ${room.name}? Reassign devices and cameras first.`)) run(() => homes.removeRoom(room.id), 'Room removed.');
      return;
    }
    const deviceRename = event.target.closest('[data-home-device-rename]');
    if (deviceRename) {
      const device = devices.getDeviceById(deviceRename.dataset.homeDeviceRename);
      const name = window.prompt('Device name', device.name);
      if (name !== null) run(() => devices.updateDeviceName(device.id, name), 'Device name updated.');
      return;
    }
    const addType = event.target.closest('[data-add-device-type]');
    if (addType) {
      const form = document.querySelector('#home-add-device-form');
      form.dataset.mode = addType.dataset.addDeviceType;
      form.querySelectorAll('[data-add-device-type]').forEach((button) => button.classList.toggle('is-active', button === addType));
      document.querySelector('#home-device-form-content').innerHTML = addType.dataset.addDeviceType === 'appliance' ? applianceForm(homes.getCurrentHome()) : equipmentForm(homes.getCurrentHome());
      return;
    }
    const cameraLive = event.target.closest('[data-camera-live]');
    if (cameraLive) { cameraId = cameraLive.dataset.cameraLive; go('dash-camera-live'); return; }
    const cameraRename = event.target.closest('[data-camera-edit]');
    if (cameraRename) {
      const camera = homes.getCurrentHome().cameras.find((item) => item.id === cameraRename.dataset.cameraEdit);
      const name = window.prompt('Camera name', camera?.name || '');
      if (name !== null) run(() => homes.updateCamera(camera.id, { name }), 'Camera inventory label updated.');
      return;
    }
    const cameraRemove = event.target.closest('[data-camera-remove]');
    if (cameraRemove && window.confirm('Remove this offline camera inventory entry? No camera will be changed.')) {
      run(() => homes.removeCamera(cameraRemove.dataset.cameraRemove), 'Camera entry removed.');
    }
  }

  function handleChange(event) {
    if (event.target.matches('#central-device-home, #central-device-room, #central-device-category, #central-device-status')) {
      if (event.target.id === 'central-device-home') centralFilters.home = event.target.value;
      if (event.target.id === 'central-device-room') centralFilters.room = event.target.value;
      if (event.target.id === 'central-device-category') centralFilters.category = event.target.value;
      if (event.target.id === 'central-device-status') centralFilters.status = event.target.value;
      render();
      return;
    }
    const centralToggle = event.target.closest('[data-central-toggle]');
    if (centralToggle) {
      try {
        const device = devices.setDeviceStateForHome(centralToggle.dataset.homeId, centralToggle.dataset.centralToggle, centralToggle.checked);
        toast(`${device.name} ${device.on ? 'on' : 'off'} in local preview · no hardware command was sent.`);
        render();
      } catch (error) {
        centralToggle.checked = !centralToggle.checked;
        toast(error instanceof Error ? error.message : 'This demo device could not be updated.', true);
      }
      return;
    }
    const roomCheck = event.target.closest('[data-wizard-room]');
    if (roomCheck) {
      wizardRooms[Number(roomCheck.dataset.wizardRoom)].selected = roomCheck.checked;
      render();
      return;
    }
    const homeSelect = event.target.closest('#global-home-selector');
    if (homeSelect) {
      if (homeSelect.value === '__manage_homes__') { go('dash-homes'); return; }
      run(() => homes.selectHome(homeSelect.value), 'Switched home. Each home has separate local demo state.');
      if (!routes.has(activeRoute)) go('dashboard');
      return;
    }
    const roomAssignment = event.target.closest('[data-home-device-room]');
    if (roomAssignment) run(() => devices.updateDeviceRoom(roomAssignment.dataset.homeDeviceRoom, roomAssignment.value), 'Device room updated.');
    const roomWallpaper = event.target.closest('[data-room-wallpaper]');
    if (roomWallpaper) {
      const room = homes.getRooms().find((item) => item.id === roomWallpaper.dataset.roomWallpaper);
      if (room) run(() => homes.saveRoom({ id: room.id, wallpaper: roomWallpaper.value }), 'Room wallpaper updated.');
    }
    const roomCategory = event.target.closest('[data-room-category]');
    if (roomCategory) {
      const room = homes.getRooms().find((item) => item.id === roomCategory.dataset.roomCategory);
      if (room) run(() => homes.saveRoom({ id: room.id, category: roomCategory.value }), 'Room category updated.');
    }
    const selectedCategory = event.target.closest('#home-room-category');
    if (selectedCategory) {
      const name = document.querySelector('#home-room-form [name="name"]');
      const icon = document.querySelector('#home-room-form [name="icon"]');
      const category = homes.roomCategories.find((item) => item.name === selectedCategory.value);
      if (category) {
        if (!name.value.trim()) name.value = category.name;
        icon.value = category.icon;
      }
    }
    if (event.target.matches('#device-catalog-category')) {
      const catalog = document.querySelector('.home-device-catalog');
      catalog.innerHTML = catalogGroups();
    }
    const wallpaperFile = event.target.closest('#home-room-wallpaper-file');
    if (wallpaperFile?.files?.[0]) {
      const file = wallpaperFile.files[0];
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 512 * 1024) {
        wallpaperFile.value = '';
        toast('Choose a PNG, JPEG, or WebP room image smaller than 512 KB.', true);
        return;
      }
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        const hidden = document.querySelector('#home-room-wallpaper-data');
        if (hidden) hidden.value = String(reader.result || '');
      });
      reader.addEventListener('error', () => toast('The selected room image could not be read.', true), { once: true });
      reader.readAsDataURL(file);
    }
  }

  function handleInput(event) {
    if (!event.target.matches('#device-catalog-search, #central-device-search')) return;
    const input = event.target;
    if (input.id === 'device-catalog-search') catalogSearch = input.value;
    else centralFilters.search = input.value;
    const selection = input.selectionStart;
    render();
    const replacement = document.getElementById(input.id);
    replacement?.focus();
    replacement?.setSelectionRange(selection, selection);
  }

  function handleSubmit(event) {
    const form = event.target;
    if (form.id === 'home-action-form') {
      event.preventDefault();
      const data = new FormData(form);
      const value = (key) => String(data.get(key) || '');
      const action = form.dataset.actionType;
      const id = form.dataset.itemId;
      let result = null;
      if (action === 'home-edit') {
        result = run(() => homes.updateHome(id, Object.fromEntries(['name','type','icon','address','city','state','country'].map((key) => [key, value(key)]))), 'Home details updated.');
      } else if (action === 'home-rename') {
        result = run(() => homes.updateHome(id, { name: value('name') }), 'Home renamed.');
      } else if (action === 'home-wallpaper') {
        result = run(() => homes.updateHome(id, { wallpaper: value('wallpaper') }), 'Home wallpaper updated.');
      } else if (action === 'home-remove') {
        result = run(() => homes.removeHome(id), 'Home and its local rooms, devices, and settings removed.');
      } else if (action === 'room-edit') {
        result = run(() => homes.saveRoom({ id, name: value('name'), category: value('category'), icon: value('icon') }), 'Room details updated.');
      } else if (action === 'room-rename') {
        result = run(() => homes.saveRoom({ id, name: value('name') }), 'Room renamed.');
      } else if (action === 'room-wallpaper') {
        result = run(() => homes.saveRoom({ id, wallpaper: value('wallpaper') }), 'Room wallpaper updated.');
      } else if (action === 'room-remove') {
        const moves = { devices: {}, cameras: {}, equipment: {} };
        data.forEach((destination, key) => {
          const separator = key.indexOf(':');
          if (separator > 0) {
            const group = key.slice(0, separator);
            const entryId = key.slice(separator + 1);
            if (group in moves) moves[group][entryId] = String(destination);
          }
        });
        result = run(() => homes.removeRoom(id, moves), 'Items reassigned and room removed.');
        if (result && roomId === id) {
          roomId = '';
          go('dash-home-rooms');
        }
      } else if (action === 'device-rename') {
        result = run(() => devices.updateDeviceName(id, value('name')), 'Device renamed.');
      } else if (action === 'device-edit') {
        result = run(() => devices.updateDeviceDetails(id, { name: value('name'), room: value('room'), icon: value('icon') }), 'Device details updated.');
      } else if (action === 'device-icon') {
        result = run(() => devices.updateDeviceIcon(id, value('icon')), 'Device icon updated.');
      } else if (action === 'device-move') {
        result = run(() => devices.updateDeviceRoom(id, value('room')), 'Device moved to another room.');
      } else if (action === 'device-remove') {
        result = run(() => devices.removeDevice(id), 'Device and its own schedules removed. Other devices were not changed.');
      }
      if (result !== null) actionDialog.close();
    } else if (form.id === 'home-wizard-form') {
      event.preventDefault();
      submitWizard(form);
    } else if (form.id === 'home-room-form') {
      event.preventDefault();
      const data = new FormData(form);
      run(() => homes.saveRoom({
        name: data.get('name'), icon: data.get('icon'), category: data.get('category'),
        wallpaper: data.get('wallpaperFile') || data.get('wallpaper'),
      }), 'Room added with its selected local wallpaper.');
    } else if (form.id === 'home-add-device-form') {
      event.preventDefault();
      const data = new FormData(form);
      if (!data.get('kind') || !data.get('displayType')) {
        form.querySelector('.homes-form-error').textContent = 'Select a device category before adding it.';
        return;
      }
      const result = run(() => devices.addDevice(data.get('kind'), data.get('name'), data.get('room'), {
        displayType: data.get('displayType'), category: data.get('category'), icon: data.get('icon'),
      }), 'Device added to local demo inventory. No hardware was paired.');
      if (result) {
        selectedCatalogName = '';
        catalogSearch = '';
        preferredRoom = String(data.get('room'));
        render();
      }
    } else if (form.id === 'camera-add-form') {
      event.preventDefault();
      const password = form.elements.password;
      password.value = '';
      const data = new FormData(form);
      const camera = Object.fromEntries(data.entries());
      delete camera.password;
      run(() => homes.addCamera(camera), 'Offline camera entry added. Credentials were discarded and not saved.');
    } else return;
  }

  document.addEventListener('click', handleClick);
  document.addEventListener('change', handleChange);
  document.addEventListener('input', handleInput);
  document.addEventListener('submit', handleSubmit, true);
  document.addEventListener('homiot-delete-request', (event) => {
    const { action, id, homeId = '' } = event.detail || {};
    if (!action || !id) return;
    if (action.startsWith('home-')) openHomeAction(action, id);
    else if (action.startsWith('room-')) openRoomAction(action, id);
    else if (action.startsWith('device-')) openDeviceAction(action, id, homeId);
  });
  window.addEventListener('smartnest-home-changed', () => { refreshSelector(); if (routes.has(activeRoute)) render(); });
  window.addEventListener('smartnest-homes-changed', () => { refreshSelector(); if (routes.has(activeRoute)) render(); });
  window.addEventListener('smartnest-devices-changed', () => { if (routes.has(activeRoute)) render(); });
  window.SmartNestHomeModule = { handleRoute, render, refreshSelector };
  refreshSelector();
})();
