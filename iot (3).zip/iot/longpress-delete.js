(() => {
  const cardSelector = '[data-delete-action][data-item-id]';
  const ignoredSelector = [
    'input', 'select', 'textarea', 'a', 'summary', 'details',
    '.home-action-menu', '.home-favorite', '.device-toggle',
    '[data-mgmt-range]', '[data-device-setting]', '[data-mgmt-toggle]', '[data-central-toggle]',
  ].join(',');
  const allowedButtons = '.device-card-open, .management-card-open, [data-home-open], [data-device-open], [data-open-device]';
  const holdDuration = 3000;
  const moveThreshold = 12;
  let session = null;
  let holdTimer = 0;
  let suppressClickTimer = 0;
  let suppressNextClick = false;
  let layer;
  let target;
  let ghost;

  function ensureLayer() {
    if (layer) return;
    layer = document.createElement('div');
    layer.className = 'longpress-delete-layer';
    layer.hidden = true;
    layer.innerHTML = '<div class="longpress-delete-ghost" aria-hidden="true"></div><button class="longpress-delete-target" type="button" aria-label="Delete target"><span class="longpress-delete-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5"/></svg></span><span><b>Drop to delete</b><small>Release to review removal</small></span></button><span class="longpress-delete-announcer" role="status" aria-live="polite"></span>';
    document.body.append(layer);
    target = layer.querySelector('.longpress-delete-target');
    ghost = layer.querySelector('.longpress-delete-ghost');
    target.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
    });
  }

  function itemLabel(card) {
    const label = card.querySelector('.home-card-copy h2, .management-card-title b, .device-card-title h3, .home-device-inventory-card b, .home-room-list-card > div > b');
    return label?.textContent?.trim() || 'item';
  }

  function clearSession() {
    clearTimeout(holdTimer);
    if (session?.card) session.card.classList.remove('is-longpress-delete-source');
    session = null;
    document.body.classList.remove('longpress-delete-active');
    if (layer) layer.hidden = true;
  }

  function cancelBeforeHold() {
    clearSession();
  }

  function showDeleteTarget(current, x, y) {
    if (session !== current) return;
    current.active = true;
    current.card.classList.add('is-longpress-delete-source');
    ensureLayer();
    layer.hidden = false;
    document.body.classList.add('longpress-delete-active');
    ghost.textContent = itemLabel(current.card);
    target.classList.remove('is-drop-ready');
    layer.querySelector('.longpress-delete-announcer').textContent =
      `Delete mode for ${itemLabel(current.card)}. Drag to the delete target and release to review.`;
    moveGhost(x, y);
  }

  function moveGhost(x, y) {
    if (!ghost) return;
    ghost.style.transform = `translate3d(${Math.round(x + 14)}px, ${Math.round(y + 14)}px, 0)`;
  }

  function isOverTarget(x, y) {
    if (!target || layer.hidden) return false;
    const rect = target.getBoundingClientRect();
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  }

  function requestDelete(current) {
    const detail = {
      action: current.card.dataset.deleteAction,
      id: current.card.dataset.itemId,
      homeId: current.card.dataset.homeId || '',
    };
    document.dispatchEvent(new CustomEvent('homiot-delete-request', { detail }));
  }

  function onPointerDown(event) {
    if (session || event.button !== 0 || event.isPrimary === false) return;
    const card = event.target.closest?.(cardSelector);
    if (!card || event.target.closest(ignoredSelector)) return;
    if (event.target.closest('button') && !event.target.closest(allowedButtons)) return;
    session = {
      card,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      active: false,
    };
    const current = session;
    holdTimer = window.setTimeout(() => showDeleteTarget(current, current.startX, current.startY), holdDuration);
  }

  function onPointerMove(event) {
    if (!session || event.pointerId !== session.pointerId) return;
    if (!session.active) {
      if (Math.hypot(event.clientX - session.startX, event.clientY - session.startY) > moveThreshold) {
        cancelBeforeHold();
      }
      return;
    }
    event.preventDefault();
    moveGhost(event.clientX, event.clientY);
    target.classList.toggle('is-drop-ready', isOverTarget(event.clientX, event.clientY));
  }

  function onPointerUp(event) {
    if (!session || event.pointerId !== session.pointerId) return;
    const current = session;
    const dropped = current.active && isOverTarget(event.clientX, event.clientY);
    if (current.active) {
      suppressNextClick = true;
      clearTimeout(suppressClickTimer);
      suppressClickTimer = window.setTimeout(() => { suppressNextClick = false; }, 500);
    }
    clearSession();
    if (dropped) requestDelete(current);
  }

  function onClick(event) {
    if (!suppressNextClick || !event.target.closest(cardSelector)) return;
    suppressNextClick = false;
    clearTimeout(suppressClickTimer);
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  function onKeyDown(event) {
    if (event.key !== 'Delete' && event.key !== 'Backspace') return;
    if (event.target.closest('input, select, textarea, [contenteditable="true"]')) return;
    const card = event.target.closest?.(cardSelector);
    if (!card) return;
    event.preventDefault();
    requestDelete({
      card,
      active: false,
    });
  }

  function onContextMenu(event) {
    if (event.target.closest?.(cardSelector)) event.preventDefault();
  }

  function onSelectStart(event) {
    if (session && event.target.closest?.(cardSelector)) event.preventDefault();
  }

  document.addEventListener('pointerdown', onPointerDown, true);
  document.addEventListener('pointermove', onPointerMove, { capture: true, passive: false });
  document.addEventListener('pointerup', onPointerUp, true);
  document.addEventListener('pointercancel', cancelBeforeHold, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('contextmenu', onContextMenu, true);
  document.addEventListener('selectstart', onSelectStart, true);
  window.addEventListener('blur', cancelBeforeHold);
})();
