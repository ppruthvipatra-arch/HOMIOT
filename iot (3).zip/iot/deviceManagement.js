(() => {
  const service = window.SmartNestDeviceService;
  const page = document.querySelector('#device-management');
  if (!service || !page) return;

  const defaultRooms = ['Living Room', 'Bedroom', 'Kitchen', 'Bathroom', 'Outdoor'];
  const roomNames = () => ['All Devices', ...(window.SmartNestHomeService?.getRooms().map((room) => room.name) || defaultRooms)];
  const daysShort = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const labels = {
    light: 'Smart light',
    fan: 'Ceiling fan',
    ac: 'Air conditioner',
    tv: 'Television',
    geyser: 'Water heater',
    pump: 'Water pump',
    plug: 'Smart plug',
    exhaust: 'Exhaust fan',
  };
  const icons = {
    light: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M10 19.5a9 9 0 1 1 12 0c-1.6 1.2-2 2.8-2 3.5h-8c0-.7-.4-2.3-2-3.5Z"/><path d="M12.5 26h7m-6 3h5m-2.5-9v-7m-3 3 3 3 3-3"/></svg>',
    fan: '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="2.5"/><path class="fan-rotor" d="M16 13c-1-8 2-10 5-9s3 7-3 11m1 3c7 1 9 4 7 7s-8 1-10-5m-2-2c-6 5-10 4-11 1s4-7 10-6"/></svg>',
    ac: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="6" width="24" height="13" rx="3"/><path d="M8 14h16m-12 5-2 5m8-5 2 5m-9 0h2m5 0h2"/></svg>',
    tv: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="6" width="24" height="18" rx="3"/><path d="m12 29 4-5 4 5m-7 0h6"/></svg>',
    geyser: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="7" y="4" width="18" height="24" rx="5"/><path d="M12 9h8m-8 5h8m-7 8c0-2 3-3 3-5 2 2 3 4 1 6a2.5 2.5 0 0 1-4-1Z"/></svg>',
    pump: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 24h22M8 24v-9h16v9M11 15v-4h10v4m-7-8a3 3 0 1 1 6 0v4"/><path d="M10 20h12m-9-3v6m6-6v6"/></svg>',
    plug: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M11 7v7m10-7v7m-14 0h18v3a9 9 0 0 1-9 9v4m-4-16v-3a4 4 0 0 1 8 0v3"/></svg>',
    exhaust: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="4" width="24" height="24" rx="4"/><circle cx="16" cy="16" r="2"/><path class="fan-rotor" d="M16 13c-1-6 2-8 4-6s1 5-2 7m1 3c5 1 7 3 5 5s-6 0-7-4m-2-1c-4 3-7 3-7 1s3-5 7-4"/></svg>',
  };

  let devices = [];
  let selectedRoom = 'All Devices';
  let search = '';
  let selectedIds = new Set();
  let activeRoute = 'dashboard';
  let toastTimer;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[character]);
  }

  function toast(message, error = false) {
    const node = document.querySelector('#dashboard-toast');
    node.textContent = message;
    node.classList.toggle('is-error', error);
    node.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('is-visible'), 3600);
  }

  function refreshState() {
    try {
      devices = service.getDevices();
      selectedIds = new Set([...selectedIds].filter((id) => devices.some((device) => device.id === id)));
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Device preview could not be refreshed.', true);
    }
  }

  function run(operation, options = {}) {
    try {
      const result = operation();
      refreshState();
      if (!options.silent) toast(options.message || 'Updated local demo state · no hardware command was sent.');
      if (activeRoute === 'dash-devices') renderPage();
      else if (activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
      return result;
    } catch (error) {
      toast(error instanceof Error ? error.message : 'This demo action could not be completed.', true);
      return null;
    }
  }

  function deviceById(id) {
    return devices.find((device) => device.id === id);
  }

  function fmtCount(value) {
    return `${value} ${value === 1 ? 'device' : 'devices'}`;
  }

  function roomCountId(room) {
    const fixed = { 'All Devices': 'all', 'Living Room': 'living', Bedroom: 'bedroom', Kitchen: 'kitchen', Bathroom: 'bathroom', Outdoor: 'outdoor' };
    return `management-room-${fixed[room] || room.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  }

  function statusText(device) {
    if (!device.online) return 'Offline · state not verified';
    return `${device.on ? 'On' : 'Off'} · simulated`;
  }

  function settingStepper(device, setting, title, min, max, suffix = '') {
    const value = device[setting];
    return `<div class="device-control device-stepper-control"><span>${title}</span><div class="device-stepper"><button type="button" data-mgmt-adjust="${setting}" data-device-id="${escapeHtml(device.id)}" data-step="-1" aria-label="Decrease ${escapeHtml(title.toLowerCase())}"${device.on && device.online ? '' : ' disabled'}>−</button><strong data-device-value="${setting}">${value}<small>${suffix || ` / ${max}`}</small></strong><button type="button" data-mgmt-adjust="${setting}" data-device-id="${escapeHtml(device.id)}" data-step="1" aria-label="Increase ${escapeHtml(title.toLowerCase())}"${device.on && device.online ? '' : ' disabled'}>+</button></div></div>`;
  }

  function rangeControl(device, setting, title, suffix = '%') {
    const value = device[setting];
    return `<div class="device-control device-brightness${device.on && device.online ? '' : ' is-disabled'}"><div class="device-control-heading"><span>${title}</span><strong data-device-value="${setting}">${value}${suffix}</strong></div><input class="device-range" type="range" min="0" max="100" step="1" value="${value}" data-mgmt-range="${setting}" data-device-id="${escapeHtml(device.id)}" aria-label="${escapeHtml(device.name)} ${title}"${device.on && device.online ? '' : ' disabled'}></div>`;
  }

  function modeControls(device, key, values, names) {
    return `<div class="management-extra-controls"><span class="device-control-heading"><span>${key === 'lightMode' ? 'Lighting tone' : 'Operating mode'}</span></span><div class="device-mode-picker">${values.map((value, index) => `<button type="button" class="${device[key] === value ? 'active' : ''}" data-mgmt-setting="${key}" data-setting-value="${value}" data-device-id="${escapeHtml(device.id)}" aria-pressed="${device[key] === value}"${device.online ? '' : ' disabled'}>${names[index]}</button>`).join('')}</div></div>`;
  }

  function extraControls(device) {
    if (device.kind === 'light') return modeControls(device, 'lightMode', ['warm', 'neutral', 'cool'], ['Warm', 'Neutral', 'Cool']);
    if (device.kind === 'ac') {
      return `${modeControls(device, 'acMode', ['cool', 'heat', 'dry', 'fan'], ['Cool', 'Heat', 'Dry', 'Fan'])}<div class="device-control device-stepper-control"><span>Fan speed</span><div class="device-stepper"><button type="button" data-mgmt-adjust="fanSpeed" data-device-id="${escapeHtml(device.id)}" data-step="-1" aria-label="Lower air conditioner fan speed"${device.on && device.online ? '' : ' disabled'}>−</button><strong data-device-value="fanSpeed">${device.fanSpeed}<small> / 5</small></strong><button type="button" data-mgmt-adjust="fanSpeed" data-device-id="${escapeHtml(device.id)}" data-step="1" aria-label="Raise air conditioner fan speed"${device.on && device.online ? '' : ' disabled'}>+</button></div></div>`;
    }
    if (device.kind === 'pump') {
      return `<div class="pump-level"><span>Demo tank level · not live</span><b>${device.tankLevel}%</b><i><span style="width:${device.tankLevel}%"></span></i></div><span class="pump-duration">${device.online ? (device.on ? 'Running · demo duration 00:18' : 'Idle · demo') : 'State unknown · offline'}</span>`;
    }
    if (device.kind === 'geyser' && device.on) return '<div class="device-safety-inline">High-power appliance preview. Use correctly rated, professionally installed switching hardware.</div>';
    return '';
  }

  function primaryControl(device) {
    if (device.kind === 'light') return rangeControl(device, 'brightness', 'Brightness');
    if (device.kind === 'fan' || device.kind === 'exhaust') return settingStepper(device, 'speed', device.kind === 'fan' ? 'Fan speed' : 'Vent speed', 1, 5);
    if (device.kind === 'ac' || device.kind === 'geyser') return settingStepper(device, 'temperature', device.kind === 'ac' ? 'Target temperature' : 'Water temperature', device.kind === 'ac' ? 16 : 30, device.kind === 'ac' ? 30 : 75, '°C');
    if (device.kind === 'tv') return rangeControl(device, 'volume', 'Volume');
    if (device.kind === 'plug') return `<div class="device-control device-text-control"><span>Current draw · demo</span><strong>${device.online ? `${device.on ? device.watts : 0} W` : 'Unavailable · offline'}</strong></div>`;
    return `<div class="device-control device-text-control"><span>Running status</span><strong>${device.online ? `${device.on ? 'Running' : 'Stopped'} · demo` : 'State unknown · offline'}</strong></div>`;
  }

  function card(device) {
    const energy = service.getEnergyConsumption(device.id);
    const selected = selectedIds.has(device.id);
    const fanStyle = device.kind === 'fan' || device.kind === 'exhaust' ? ` style="--fan-speed:${device.speed}"` : '';
    const homeId = window.SmartNestHomeService?.getCurrentHomeId() || '';
    const actions = [['device-settings','Device settings'],['device-rename','Rename device'],['device-edit','Edit device'],['device-icon','Change device icon'],['device-move','Move to another room']];
    return `<article class="management-device-card${device.online && device.on ? ' is-on' : ''}" data-management-card="${escapeHtml(device.id)}" data-device-kind="${escapeHtml(device.kind)}" data-delete-action="device-remove" data-item-id="${escapeHtml(device.id)}" data-home-id="${escapeHtml(homeId)}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this card and press Delete."${fanStyle}>
      <div class="management-card-top">
        <button class="management-card-open" data-open-device="${escapeHtml(device.id)}" aria-label="Open ${escapeHtml(device.name)} controls">
          <span class="device-icon device-icon-${device.kind}">${escapeHtml(device.icon || '')}${device.icon ? '' : icons[device.kind]}</span>
          <span class="management-card-title"><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.room)} · ${escapeHtml(device.displayType || labels[device.kind])}</small></span>
        </button>
        <label class="device-toggle" title="Toggle ${escapeHtml(device.name)}"><input type="checkbox" data-mgmt-toggle="${escapeHtml(device.id)}" aria-label="${device.online ? `Turn ${escapeHtml(device.name)} ${device.on ? 'off' : 'on'}` : `${escapeHtml(device.name)} state unavailable while offline`}" aria-checked="${device.online ? device.on : 'mixed'}"${device.online && device.on ? ' checked' : ''}${device.online ? '' : ' disabled'}><span class="device-toggle-track"></span></label>
        <details class="home-action-menu" data-home-id="${escapeHtml(homeId)}"><summary aria-label="More device actions" title="More actions">•••</summary><div class="home-action-menu-list" role="menu">${actions.map(([action,label]) => `<button type="button" role="menuitem" data-home-action="${action}" data-item-id="${escapeHtml(device.id)}"${action === 'device-remove' ? ' class="is-danger"' : ''}>${label}</button>`).join('')}</div></details>
      </div>
      <div class="management-state-line"><span class="device-state-label"><i></i>${device.online ? `${device.on ? 'On' : 'Off'} · simulated` : 'State unknown · offline'}</span><span><i class="${device.online ? 'state-online-dot' : 'state-offline-dot'}"></i>${device.online ? 'Demo online' : 'Offline · unverified'}</span></div>
      ${primaryControl(device)}
      ${extraControls(device)}
      <div class="management-energy-row"><span>Power <b>${energy.available ? `${energy.watts} W` : 'Unavailable'}</b></span><span>Today <b>${energy.available ? `${energy.dailyKwh.toFixed(2)} kWh` : 'Unavailable'}</b></span></div>
      <div class="management-card-footer"><label><input class="management-card-select" type="checkbox" data-select-device="${escapeHtml(device.id)}" aria-label="Select ${escapeHtml(device.name)} for group control"${selected ? ' checked' : ''}${device.online ? '' : ' disabled'}> Select for group off</label><button type="button" data-open-device="${escapeHtml(device.id)}">Details &amp; history ↗</button></div>
    </article>`;
  }

  function renderSummary() {
    const online = devices.filter((device) => device.online);
    document.querySelector('#management-total').textContent = String(devices.length);
    document.querySelector('#management-on').textContent = String(online.filter((device) => device.on).length);
    document.querySelector('#management-off').textContent = String(online.filter((device) => !device.on).length);
    document.querySelector('#management-offline').textContent = String(devices.filter((device) => !device.online).length);
    for (const room of roomNames()) {
      const inRoom = room === 'All Devices' ? devices : devices.filter((device) => device.room === room);
      const active = inRoom.filter((device) => device.on && device.online).length;
      const node = document.querySelector(`#${roomCountId(room)}`);
      if (node) node.textContent = `${fmtCount(inRoom.length)} · ${active} on`;
    }
    document.querySelector('#management-result-count').textContent = String(filteredDevices().length);
    document.querySelector('#selected-device-count').textContent = String(selectedIds.size);
  }

  function filteredDevices() {
    const query = search.trim().toLowerCase();
    return devices.filter((device) => (selectedRoom === 'All Devices' || device.room === selectedRoom)
      && (!query || device.name.toLowerCase().includes(query) || device.room.toLowerCase().includes(query)
        || (device.displayType || labels[device.kind]).toLowerCase().includes(query)
        || (device.category || '').toLowerCase().includes(query)));
  }

  function renderRooms() {
    const selector = document.querySelector('.management-room-selector');
    selector.querySelectorAll('[data-management-room]').forEach((button) => {
      if (button.dataset.managementRoom !== 'All Devices') button.remove();
    });
    selector.querySelectorAll('[data-generated-management-room]').forEach((button) => button.remove());
    const activeRooms = window.SmartNestHomeService?.getRooms().map((room) => room.name) || defaultRooms;
    if (!activeRooms.includes(selectedRoom) && selectedRoom !== 'All Devices') selectedRoom = 'All Devices';
    activeRooms.forEach((room) => {
      const count = devices.filter((device) => device.room === room);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'management-room';
      button.dataset.managementRoom = room;
      button.dataset.generatedManagementRoom = 'true';
      button.setAttribute('aria-pressed', 'false');
      button.textContent = room;
      const detail = document.createElement('small');
      detail.id = roomCountId(room);
      detail.textContent = fmtCount(count.length);
      button.append(detail);
      selector.append(button);
    });
    document.querySelectorAll('[data-management-room]').forEach((button) => {
      const active = button.dataset.managementRoom === selectedRoom;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function renderSchedules() {
    const schedules = service.getSchedules();
    document.querySelector('#schedule-count').textContent = String(schedules.length);
    const list = document.querySelector('#schedule-list');
    if (!schedules.length) {
      list.innerHTML = '<div class="schedule-empty">No demo schedules yet. Create a local preview rule to see it here.</div>';
      return;
    }
    list.innerHTML = schedules.map((schedule) => {
      const device = deviceById(schedule.deviceId);
      if (!device) return '';
      const repeatedDays = schedule.date
        ? `One time · ${new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(`${schedule.date}T00:00:00`))}`
        : schedule.days.slice().sort((a, b) => a - b).map((day) => dayNames[day]).join(' · ');
      return `<article class="schedule-card" data-schedule-id="${escapeHtml(schedule.id)}">
        <div class="schedule-card-info"><span class="device-icon device-icon-${device.kind}">${icons[device.kind]}</span><span><b>${escapeHtml(device.name)} · daily routine</b><small>${repeatedDays || 'No repeat days'} · local preview rule</small></span></div>
        <span class="schedule-card-time">On ${formatTime(schedule.onTime)} · Off ${formatTime(schedule.offTime)}</span>
        <div class="schedule-card-actions"><label>Enabled <input class="schedule-enable" type="checkbox" data-schedule-toggle="${escapeHtml(schedule.id)}" aria-label="Enable schedule for ${escapeHtml(device.name)}"${schedule.enabled ? ' checked' : ''}></label><button type="button" data-edit-schedule="${escapeHtml(schedule.id)}">Edit</button><button type="button" data-remove-schedule="${escapeHtml(schedule.id)}">Remove</button></div>
      </article>`;
    }).join('');
  }

  function renderPage() {
    document.querySelector('#device-management').dataset.route = activeRoute;
    renderSummary();
    renderRooms();
    const results = filteredDevices();
    document.querySelector('#management-device-grid').innerHTML = results.map(card).join('');
    document.querySelector('#management-device-grid').hidden = results.length === 0;
    document.querySelector('#management-empty').hidden = results.length !== 0;
    renderSchedules();
  }

  function formatTime(value) {
    const [hour, minute] = value.split(':').map(Number);
    const suffix = hour >= 12 ? 'PM' : 'AM';
    return `${hour % 12 || 12}:${String(minute).padStart(2, '0')} ${suffix}`;
  }

  function controlDetail(device) {
    const disabled = !device.on || !device.online;
    if (device.kind === 'light') {
      return `${rangeControl(device, 'brightness', 'Brightness')}${modeControls(device, 'lightMode', ['warm', 'neutral', 'cool'], ['Warm', 'Neutral', 'Cool'])}`;
    }
    if (device.kind === 'fan' || device.kind === 'exhaust') return settingStepper(device, 'speed', 'Speed', 1, 5);
    if (device.kind === 'ac') {
      return `${settingStepper(device, 'temperature', 'Target temperature', 16, 30, '°C')}${modeControls(device, 'acMode', ['cool', 'heat', 'dry', 'fan'], ['Cool', 'Heat', 'Dry', 'Fan'])}<div class="device-control device-stepper-control"><span>Fan speed</span><div class="device-stepper"><button type="button" data-mgmt-adjust="fanSpeed" data-device-id="${escapeHtml(device.id)}" data-step="-1"${disabled ? ' disabled' : ''}>−</button><strong data-device-value="fanSpeed">${device.fanSpeed}<small> / 5</small></strong><button type="button" data-mgmt-adjust="fanSpeed" data-device-id="${escapeHtml(device.id)}" data-step="1"${disabled ? ' disabled' : ''}>+</button></div></div>`;
    }
    if (device.kind === 'geyser') return settingStepper(device, 'temperature', 'Water temperature', 30, 75, '°C');
    if (device.kind === 'tv') return rangeControl(device, 'volume', 'Volume');
    if (device.kind === 'pump')     return `<div class="pump-level"><span>Demo tank level · not live</span><b>${device.tankLevel}%</b><i><span style="width:${device.tankLevel}%"></span></i></div>`;
    return `<div class="device-control device-text-control"><span>Smart plug</span><strong>${device.online ? `${device.on ? device.watts : 0} W · demo` : 'Unavailable · offline'}</strong></div>`;
  }

  function renderDetails(id) {
    let device;
    try {
      device = service.getDeviceById(id);
    } catch {
      toast('This device is no longer in the local preview.', true);
      setRoute('dash-devices');
      return;
    }
    const energy = service.getEnergyConsumption(id);
    const detail = document.querySelector('#device-detail-page');
    detail.dataset.route = 'dash-device-detail';
    const maxKwh = Math.max(...energy.weeklyKwh, 0.1);
    const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    const safety = device.kind === 'geyser' || device.kind === 'pump' || device.kind === 'ac'
      ? '<div class="detail-warning"><b>Safety note.</b> This is a simulated control only. High-power equipment needs properly rated, isolated hardware installed by a qualified electrician. Do not bypass protective systems.</div>'
      : '';
    const reading = !energy.available ? 'Unavailable · device offline' : 'Illustrative demo reading';
    detail.innerHTML = `<button class="detail-back" data-device-back>← <span>Back to My Devices</span></button>
      <div class="detail-layout">
        <div>
          <article class="detail-main-card">
            <div class="detail-device-hero"><span class="device-icon device-icon-${device.kind}">${escapeHtml(device.icon || '')}${device.icon ? '' : icons[device.kind]}</span><div><h1>${escapeHtml(device.name)}</h1><p>${escapeHtml(device.room)} · ${escapeHtml(device.displayType || labels[device.kind])}</p></div><label class="device-toggle" title="Toggle ${escapeHtml(device.name)}"><input type="checkbox" data-mgmt-toggle="${escapeHtml(device.id)}" aria-label="${device.online ? `Turn ${escapeHtml(device.name)} ${device.on ? 'off' : 'on'}` : `${escapeHtml(device.name)} state unavailable while offline`}" aria-checked="${device.online ? device.on : 'mixed'}"${device.online && device.on ? ' checked' : ''}${device.online ? '' : ' disabled'}><span class="device-toggle-track"></span></label></div>
            <span class="detail-demo-status"><i class="${device.online ? 'state-online-dot' : 'state-offline-dot'}"></i>${statusText(device)} · no hardware link</span>
            <h2 class="detail-controls-heading">Appliance controls</h2>
            <div class="detail-controls"><div class="detail-control-panel"><span>Device-specific settings</span>${controlDetail(device)}</div><div class="detail-control-panel"><span>Current state · simulated</span><div class="detail-info-row"><span>State</span><b>${device.online ? (device.on ? 'On · demo' : 'Off · demo') : 'Unknown · offline'}</b></div><div class="detail-info-row"><span>Power</span><b>${energy.available ? `${energy.watts} W` : 'Unavailable'}</b></div><div class="detail-info-row"><span>Connection</span><b>${device.online ? 'Demo online' : 'Offline · unverified'}</b></div></div></div>
            ${safety}
          </article>
          <article class="detail-energy-card"><div class="management-section-heading"><div><p class="section-overline">ILLUSTRATIVE · DEMO DATA</p><h2>Energy history</h2></div><span class="section-meta">${reading}</span></div>
            <div class="detail-energy-summary"><div><span>Live estimate</span><b>${energy.available ? `${energy.watts} <small>W</small>` : 'Unavailable'}</b></div><div><span>Today</span><b>${energy.available ? `${energy.dailyKwh.toFixed(2)} <small>kWh</small>` : 'Unavailable'}</b></div><div><span>This month</span><b>${energy.available ? `${energy.monthlyKwh.toFixed(1)} <small>kWh</small>` : 'Unavailable'}</b></div><div><span>Est. cost</span><b>${energy.available ? `₹${energy.estimatedCost.toFixed(2)}` : 'Unavailable'}</b></div></div>
            <div class="detail-energy-chart${energy.available ? '' : ' is-unavailable'}" role="img" aria-label="${energy.available ? 'Illustrative seven-day energy use chart' : 'Energy readings are unavailable because this device is offline'}">${energy.available ? energy.weeklyKwh.map((value, index) => `<i title="${days[index]}: ${value} kWh" style="height:${Math.max(8, value / maxKwh * 100)}%"></i>`).join('') : '<span>Reading unavailable · offline state is not verified</span>'}</div>
          </article>
        </div>
        <aside class="detail-side-card"><h2>Device information</h2><div class="detail-info-row"><span>Device name</span><b>${escapeHtml(device.name)}</b></div><div class="detail-info-row"><span>Room</span><b>${escapeHtml(device.room)}</b></div><div class="detail-info-row"><span>Appliance</span><b>${labels[device.kind]}</b></div><div class="detail-info-row"><span>Connectivity</span><b>${device.online ? 'Demo online' : 'Offline · no command'}</b></div><div class="detail-info-row"><span>Last updated</span><b>Just now · local</b></div><div class="detail-info-row"><span>Control service</span><b>Local simulation</b></div>
          <div class="detail-device-actions"><button type="button" data-simulate-connection="${escapeHtml(device.id)}">${device.online ? 'Simulate offline' : 'Mark demo online'}</button><button type="button" data-rename-device="${escapeHtml(device.id)}">Rename device</button><button type="button" data-detail-schedule="${escapeHtml(device.id)}">Create schedule</button><button type="button" class="detail-remove" data-remove-device="${escapeHtml(device.id)}">Remove from preview</button></div>${safety}</aside>
      </div>`;
  }

  function setRoute(route) {
    if (typeof window.setRoute === 'function') window.setRoute(route);
    else window.location.hash = route;
  }

  function handleRoute(route) {
    activeRoute = route;
    const isDetail = route.startsWith('dash-device-');
    page.hidden = route !== 'dash-devices';
    const detail = document.querySelector('#device-detail-page');
    detail.hidden = !isDetail;
    const mainContent = document.querySelector('#dashboard-content');
    mainContent.hidden = route === 'dash-devices' || isDetail;
    const tabRoute = isDetail ? 'dash-devices' : route;
    document.querySelectorAll('.dashboard-tab').forEach((tab) => {
      const active = tab.dataset.dashRoute === tabRoute;
      tab.classList.toggle('active', active);
      if (active) tab.setAttribute('aria-current', 'page');
      else tab.removeAttribute('aria-current');
    });
    if (route === 'dash-devices') renderPage();
    if (isDetail) renderDetails(route.slice('dash-device-'.length));
  }

  function openSchedule(deviceId, existing) {
    const form = document.querySelector('#schedule-form');
    form.reset();
    form.elements.id.value = existing?.id || '';
    const select = document.querySelector('#schedule-device');
    select.innerHTML = devices.map((device) => `<option value="${escapeHtml(device.id)}">${escapeHtml(device.name)} · ${escapeHtml(device.room)}</option>`).join('');
    if (deviceId) select.value = deviceId;
    form.elements.enabled.value = String(existing?.enabled ?? true);
    if (existing) {
      form.elements.deviceId.value = existing.deviceId;
      form.elements.onTime.value = existing.onTime;
      form.elements.offTime.value = existing.offTime;
      form.elements.date.value = existing.date || '';
      form.querySelectorAll('[name="days"]').forEach((input) => { input.checked = existing.days.includes(Number(input.value)); });
    }
    document.querySelector('#schedule-dialog-title').textContent = existing ? 'Edit demo schedule' : 'New demo schedule';
    document.querySelector('#schedule-error').textContent = '';
    document.querySelector('#schedule-dialog').showModal();
  }

  function handleRangeInput(event) {
    const input = event.target.closest('[data-mgmt-range]');
    if (!input) return;
    const value = Number(input.value);
    const cardElement = input.closest('.management-device-card, .detail-main-card');
    cardElement?.querySelector(`[data-device-value="${input.dataset.mgmtRange}"]`)?.replaceChildren(document.createTextNode(`${value}%`));
  }

  function handleRangeChange(event) {
    const input = event.target.closest('[data-mgmt-range]');
    if (!input) return;
    const value = Number(input.value);
    const device = deviceById(input.dataset.deviceId);
    const field = input.dataset.mgmtRange;
    try {
      if (field === 'brightness') service.updateBrightness(input.dataset.deviceId, value);
      else service.updateDeviceSettings(input.dataset.deviceId, { volume: value });
      refreshState();
      renderSummary();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'This demo setting could not be saved.', true);
      refreshState();
      input.value = String(device?.[field] ?? 0);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  document.addEventListener('click', (event) => {
    const detailLink = event.target.closest('[data-open-device]');
    if (detailLink) {
      setRoute(`dash-device-${detailLink.dataset.openDevice}`);
      return;
    }
    if (event.target.closest('[data-device-back]')) {
      setRoute('dash-devices');
      return;
    }

    const roomButton = event.target.closest('[data-management-room]');
    if (roomButton) {
      selectedRoom = roomButton.dataset.managementRoom;
      renderPage();
      return;
    }
    if (event.target.closest('[data-management-clear]')) {
      selectedRoom = 'All Devices';
      search = '';
      document.querySelector('#management-search').value = '';
      renderPage();
      return;
    }
    if (event.target.closest('[data-open-add-device]')) {
      document.querySelector('#add-device-error').textContent = '';
      document.querySelector('#add-device-dialog').showModal();
      return;
    }
    if (event.target.closest('[data-open-schedule]')) {
      openSchedule();
      return;
    }
    if (event.target.closest('[data-close-dialog]')) {
      document.querySelector(`#${event.target.closest('[data-close-dialog]').dataset.closeDialog}`).close();
      return;
    }

    const settingButton = event.target.closest('[data-mgmt-setting]');
    if (settingButton) {
      const result = run(() => service.updateDeviceSettings(settingButton.dataset.deviceId, { [settingButton.dataset.mgmtSetting]: settingButton.dataset.settingValue }));
      if (result && activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
      return;
    }

    const adjustButton = event.target.closest('[data-mgmt-adjust]');
    if (adjustButton) {
      const device = deviceById(adjustButton.dataset.deviceId);
      if (!device || !device.online || !device.on) return;
      const setting = adjustButton.dataset.mgmtAdjust;
      const value = device[setting] + Number(adjustButton.dataset.step);
      const method = setting === 'brightness' ? () => service.updateBrightness(device.id, value)
        : setting === 'temperature' ? () => service.updateTemperature(device.id, value)
          : setting === 'fanSpeed' ? () => service.updateDeviceSettings(device.id, { fanSpeed: value })
            : () => service.updateFanSpeed(device.id, value);
      run(method, { silent: true });
      return;
    }

    if (event.target.closest('[data-management-master="on"]')) {
      const available = devices.filter((device) => device.online);
      const offlineCount = devices.length - available.length;
      const updated = run(() => service.setAllDevices(true), { silent: true });
      if (updated) toast(`${available.length} demo device${available.length === 1 ? '' : 's'} updated locally.${offlineCount ? ` ${offlineCount} offline skipped.` : ''} No hardware command was sent.`);
      return;
    }
    if (event.target.closest('[data-management-master="off"]')) {
      const available = devices.filter((device) => device.online);
      const offlineCount = devices.length - available.length;
      if (!window.confirm(`Turn off ${available.length} demo-online device${available.length === 1 ? '' : 's'}? ${offlineCount} offline device${offlineCount === 1 ? '' : 's'} will be skipped. This only changes local preview state.`)) return;
      const updated = run(() => service.setAllDevices(false), { silent: true });
      if (updated) toast(`${available.length} demo device${available.length === 1 ? '' : 's'} updated locally.${offlineCount ? ` ${offlineCount} offline skipped.` : ''} No hardware command was sent.`);
      return;
    }
    if (event.target.closest('[data-management-selected-off]')) {
      const selected = devices.filter((device) => selectedIds.has(device.id) && device.online);
      const offlineCount = [...selectedIds].filter((id) => !deviceById(id)?.online).length;
      if (!selected.length) {
        toast('Select at least one demo-online device first.', true);
        return;
      }
      if (!window.confirm(`Turn off ${selected.length} selected demo device${selected.length === 1 ? '' : 's'}? This only changes local preview state.`)) return;
      const updated = run(() => service.setDevices(selected.map((device) => device.id), false), { silent: true });
      if (updated) toast(`${selected.length} selected demo devices updated locally.${offlineCount ? ` ${offlineCount} offline skipped.` : ''} No hardware command was sent.`);
      return;
    }

    const edit = event.target.closest('[data-edit-schedule]');
    if (edit) {
      openSchedule(null, service.getSchedules().find((schedule) => schedule.id === edit.dataset.editSchedule));
      return;
    }
    const removeSchedule = event.target.closest('[data-remove-schedule]');
    if (removeSchedule) {
      if (!window.confirm('Remove this local demo schedule?')) return;
      run(() => service.removeSchedule(removeSchedule.dataset.removeSchedule), { silent: true });
      return;
    }

    const renameButton = event.target.closest('[data-rename-device]');
    if (renameButton) {
      const device = deviceById(renameButton.dataset.renameDevice);
      if (!device) return;
      const form = document.querySelector('#rename-device-form');
      form.elements.deviceId.value = device.id;
      form.elements.name.value = device.name;
      document.querySelector('#rename-device-error').textContent = '';
      document.querySelector('#rename-device-dialog').showModal();
      form.elements.name.focus();
      return;
    }
    const removeButton = event.target.closest('[data-remove-device]');
    if (removeButton) {
      const device = deviceById(removeButton.dataset.removeDevice);
      if (!device || !window.confirm(`Remove "${device.name}" from this local demo inventory? Its demo schedules will also be removed.`)) return;
      const result = run(() => service.removeDevice(device.id), { silent: true });
      if (result) {
        selectedIds.delete(device.id);
        toast('Device removed from the local preview inventory.');
        setRoute('dash-devices');
      }
      return;
    }
    const detailSchedule = event.target.closest('[data-detail-schedule]');
    if (detailSchedule) {
      openSchedule(detailSchedule.dataset.detailSchedule);
      return;
    }
    const connectionButton = event.target.closest('[data-simulate-connection]');
    if (connectionButton) {
      const device = deviceById(connectionButton.dataset.simulateConnection);
      if (!device) return;
      const online = !device.online;
      const result = run(() => service.setDeviceOnline(device.id, online), { silent: true });
      if (result) toast(`${device.name}: simulated connection ${online ? 'restored' : 'lost'}. Hardware connectivity is not being checked.`);
    }
  });

  document.addEventListener('change', (event) => {
    const toggle = event.target.closest('[data-mgmt-toggle]');
    if (toggle) {
      const device = deviceById(toggle.dataset.mgmtToggle);
      const result = run(() => service.toggleDevice(toggle.dataset.mgmtToggle, toggle.checked), { silent: true });
      if (result && device) toast(`${device.name} ${toggle.checked ? 'on' : 'off'} in local preview · no hardware command was sent.`);
      else if (!result) toggle.checked = !toggle.checked;
      return;
    }
    const checkbox = event.target.closest('[data-select-device]');
    if (checkbox) {
      if (checkbox.checked) selectedIds.add(checkbox.dataset.selectDevice);
      else selectedIds.delete(checkbox.dataset.selectDevice);
      renderSummary();
      return;
    }
    const scheduleToggle = event.target.closest('[data-schedule-toggle]');
    if (scheduleToggle) {
      run(() => service.setScheduleEnabled(scheduleToggle.dataset.scheduleToggle, scheduleToggle.checked), { message: `Local schedule ${scheduleToggle.checked ? 'enabled' : 'paused'} · it will not run automatically.` });
    }
  });

  document.addEventListener('input', handleRangeInput);
  document.addEventListener('change', handleRangeChange);
  document.querySelector('#management-search').addEventListener('input', (event) => {
    search = event.target.value;
    renderPage();
  });
  document.querySelector('#add-device-dialog').addEventListener('click', (event) => {
    if (event.target === event.currentTarget) event.currentTarget.close();
  });
  document.querySelector('#schedule-dialog').addEventListener('click', (event) => {
    if (event.target === event.currentTarget) event.currentTarget.close();
  });
  document.querySelector('#rename-device-dialog').addEventListener('click', (event) => {
    if (event.target === event.currentTarget) event.currentTarget.close();
  });

  document.querySelector('#add-device-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const name = form.elements.name.value;
    const kind = form.elements.kind.value;
    const room = form.elements.room.value;
    try {
      const id = service.addDevice(kind, name, room);
      refreshState();
      form.reset();
      document.querySelector('#add-device-dialog').close();
      selectedRoom = room;
      renderPage();
      toast(`${escapeHtml(name.trim())} added to the simulated inventory · not hardware connected.`);
      setRoute('dash-device-' + id);
    } catch (error) {
      document.querySelector('#add-device-error').textContent = error instanceof Error ? error.message : 'The demo device could not be added.';
    }
  });

  document.querySelector('#schedule-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const schedule = {
      id: data.get('id') || undefined,
      deviceId: data.get('deviceId'),
      onTime: data.get('onTime'),
      offTime: data.get('offTime'),
      days: data.getAll('days').map(Number),
      enabled: data.get('enabled') === 'true',
      date: data.get('date') || undefined,
    };
    try {
      service.scheduleDevice(schedule);
      refreshState();
      document.querySelector('#schedule-dialog').close();
      if (activeRoute !== 'dash-devices') setRoute('dash-devices');
      else renderPage();
      toast('Demo schedule saved locally · it will not run automatically.');
    } catch (error) {
      document.querySelector('#schedule-error').textContent = error instanceof Error ? error.message : 'The demo schedule could not be saved.';
    }
  });

  document.querySelector('#rename-device-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      service.updateDeviceName(form.elements.deviceId.value, form.elements.name.value);
      refreshState();
      document.querySelector('#rename-device-dialog').close();
      if (activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
      toast('Device name saved in the local preview.');
    } catch (error) {
      document.querySelector('#rename-device-error').textContent = error instanceof Error ? error.message : 'The demo device name could not be saved.';
    }
  });

  window.addEventListener('smartnest-devices-changed', (event) => {
    if (event.target === window) {
      refreshState();
      if (document.activeElement?.matches('[data-mgmt-range]')) {
        renderSummary();
      } else if (activeRoute === 'dash-devices') renderPage();
      else if (activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
    }
  });
  window.addEventListener('smartnest-home-changed', () => {
    refreshState();
    selectedRoom = 'All Devices';
    if (activeRoute === 'dash-devices') renderPage();
    else if (activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
  });
  window.addEventListener('storage', (event) => {
    if (event.key !== 'smartnest.dashboard.devices.v1') return;
    try {
      devices = service.getDevices();
      if (activeRoute === 'dash-devices') renderPage();
      else if (activeRoute.startsWith('dash-device-')) renderDetails(activeRoute.slice('dash-device-'.length));
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Saved device changes could not be refreshed.', true);
    }
  });

  refreshState();
  window.SmartNestDeviceManagement = { handleRoute, renderPage };
})();
