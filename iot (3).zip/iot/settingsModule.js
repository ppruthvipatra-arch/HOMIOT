(() => {
  const service = window.SmartNestSettingsService;
  const devicesService = window.SmartNestDeviceService;
  const homesService = window.SmartNestHomeService;
  const root = document.querySelector('#settings-module');
  const routes = {
    'dash-settings': ['Settings', 'settings'],
    'dash-connectivity': ['Device Connectivity', 'connectivity'],
    'dash-wifi': ['Wi-Fi & Network', 'wifi'],
    'dash-rooms': ['Room Management', 'rooms'],
    'dash-home-settings': ['Home Settings', 'home-settings'],
    'dash-user-profile': ['User Profile', 'profile'],
    'dash-account-security': ['Account & Security', 'security'],
    'dash-remote': ['Remote Access', 'remote'],
    'dash-preferences': ['App Preferences', 'preferences'],
    'dash-privacy': ['Privacy & Permissions', 'privacy'],
    'dash-help': ['Help & Support', 'help'],
  };
  if (!service || !devicesService || !root) return;

  const categories = [
    ['dash-homes', '⌂', 'My Homes', 'Switch between and manage your home previews.'],
    ['dash-cameras', '◉', 'CCTV Cameras', 'Manage offline camera entries and unavailable stream previews.'],
    ['dash-home-settings', '⌂', 'Home Settings', 'Edit the selected home and its defaults.'],
    ['dash-wifi', '⌁', 'Wi-Fi & Network', 'Check the verified gateway connection state.'],
    ['dash-connectivity', '⌁', 'Device Integrations', 'Connect supported MQTT or Home Assistant gateways and manage verified devices.'],
    ['dash-rooms', '⌂', 'Room Management', 'Organize rooms and assign demo appliances.'],
    ['dash-user-profile', '◉', 'User Profile', 'Update your local profile preview.'],
    ['dash-account-security', '◇', 'Account & Security', 'Review account controls and demo security options.'],
    ['dash-remote', '⌁', 'Remote Access', 'Review cloud and gateway connection previews.'],
    ['dash-preferences', '☼', 'App Preferences', 'Choose language, units, and app behavior.'],
    ['dash-privacy', '◈', 'Privacy & Permissions', 'Manage browser permissions only when needed.'],
    ['dash-help', '?', 'Help & Support', 'Find answers and connection troubleshooting.'],
  ];
  const networks = [
    { ssid: 'HomeNet_5G', signal: 86, security: 'WPA2' },
    { ssid: 'HomeNet_Guest', signal: 64, security: 'WPA2' },
    { ssid: 'Studio-IoT', signal: 49, security: 'WPA2' },
    { ssid: 'Neighbor Network', signal: 28, security: 'Secured' },
  ];
  const discovery = [
    { id: 'SN-ESP32-2048', name: 'HOMIOT ESP32 Gateway', mac: 'A4:CF:12:8B:20:48', signal: 91, firmware: '1.4.2' },
    { id: 'SN-ESP32-7310', name: 'ESP32 Garden Bridge', mac: '84:F3:EB:7A:73:10', signal: 68, firmware: '1.3.8' },
  ];
  let activeRoute = '';
  let pairingStep = 0;
  let pairingMethod = 'Wi-Fi';
  let pairingDevice = null;
  let discoveryScanned = false;
  let expandedDevices = new Set();
  let wifiNetworks = [];
  let connectivityFilter = 'All Devices';
  let connectivityQuery = '';
  let permissionState = { camera: 'Not requested', bluetooth: 'Not requested', location: 'Not requested', notifications: 'Not requested' };
  let toastTimer;

  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
  const escAttr = (value) => escapeHtml(value).replace(/`/g, '&#96;');
  const snapshot = () => {
    const saved = service.getSnapshot();
    return homesService ? { ...saved, rooms: homesService.getRooms() } : saved;
  };
  const deviceList = () => devicesService.getDevices();
  const toast = (message, error = false) => {
    const node = document.querySelector('#dashboard-toast');
    if (!node) return;
    node.textContent = message;
    node.classList.toggle('is-error', error);
    node.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('is-visible'), 3600);
  };
  function run(action, success) {
    try {
      action();
      if (success) toast(success);
      render();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'This settings preview action could not be completed.', true);
    }
  }
  const routeButton = (route, label, cls = '') => `<button type="button" class="${cls}" data-settings-route="${route}">${label}</button>`;

  function pageHeader(route, title, description) {
    return `<header class="settings-page-heading"><div><p class="dashboard-kicker"><span class="dashboard-live-pip"></span> HOMIOT <i>·</i> SETTINGS</p><h1>${title}</h1><p>${description}</p></div><div class="settings-heading-actions"><span class="settings-demo-tag">LOCAL DEMO</span><button type="button" class="settings-back-button" data-settings-route="${route === 'dash-settings' ? 'dashboard' : 'dash-settings'}" aria-label="Back to ${route === 'dash-settings' ? 'home' : 'settings'}">${route === 'dash-settings' ? '← Home' : '← Settings'}</button></div></header>`;
  }

  function subnav(active) {
    return `<nav class="settings-subnav" aria-label="Settings sections">${categories.map(([route, , title]) => `<button type="button" data-settings-route="${route}" class="${route === active ? 'active' : ''}"${route === active ? ' aria-current="page"' : ''}>${title}</button>`).join('')}</nav>`;
  }

  function disclaimer(message = 'Settings and connectivity actions are local previews. This browser cannot provision or control physical network or IoT hardware.') {
    return `<div class="settings-disclaimer" role="note"><b>Demo mode.</b> ${message}</div>`;
  }

  function renderHome() {
    const profile = snapshot().profile;
    return `${pageHeader('dash-settings', 'Settings', 'Manage your smart home and account preferences.')}
      ${disclaimer()}
      <section class="settings-profile-banner"><span class="settings-avatar">${escapeHtml(profile.name.charAt(0).toUpperCase())}</span><div><span>YOUR HOMIOT PROFILE</span><h2>${escapeHtml(profile.name)}</h2><p>${escapeHtml(profile.home)} · ${escapeHtml(profile.email)}</p></div>${routeButton('dash-user-profile', 'Edit profile →', 'settings-inline-link')}</section>
      <section class="settings-category-grid" aria-label="Settings categories">${categories.map(([route, icon, title, description]) => `<button type="button" class="settings-category-card" data-settings-route="${route}"><span class="settings-category-icon">${icon}</span><span class="settings-category-copy"><b>${title}</b><small>${description}</small></span><span class="settings-category-arrow" aria-hidden="true">↗</span></button>`).join('')}</section>`;
  }

  function renderWifi() {
    return `${pageHeader('dash-wifi', 'Wi-Fi & Network', 'Review the verified connection state for your home gateway.')}
      ${subnav('dash-wifi')}${disclaimer('No home gateway is configured. HOMIOT cannot inspect or provision Wi-Fi from this browser. Use a gateway’s secure local setup flow; this page never asks for or stores Wi-Fi passwords.')}
      <div class="settings-two-column"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">HOME GATEWAY</span><h2>Connection details</h2></div><span class="settings-state is-warn">Not connected</span></div>
        <div class="settings-detail-grid"><div><small>Gateway status</small><b>No gateway configured</b></div><div><small>Wi-Fi status</small><b>Unavailable · not verified</b></div><div><small>Signal strength</small><b>Unavailable</b></div><div><small>Local address</small><b>Unavailable</b></div><div><small>Last communication</small><b>Not available</b></div></div>
        <div class="settings-button-row"><button type="button" class="settings-primary-button" data-wifi-action="scan">Show sample networks</button></div>
      </section><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">NETWORK EXAMPLES</span><h2>Sample entries</h2></div></div>
        ${wifiNetworks.length ? `<div class="settings-network-list">${wifiNetworks.map((network) => `<div class="settings-network-option"><span class="settings-wifi-glyph">⌁</span><span><b>${escapeHtml(network.ssid)}</b><small>Sample entry · ${escapeHtml(network.security)} · Signal ${network.signal}%</small></span></div>`).join('')}</div>` : `<div class="settings-empty-state">No network scan is available here. Show sample entries to preview the layout.</div>`}
        <p class="settings-form-message">These entries are not discovered networks and cannot connect to your home. Provision Wi-Fi only through your gateway’s secure local setup portal.</p></section></div>`;
  }

  function renderHomeSettings() {
    const home = homesService.getCurrentHome();
    return `${pageHeader('dash-home-settings', 'Home Settings', `Manage ${escapeHtml(home.name)} and its local preview details.`)}
      ${subnav('dash-home-settings')}${disclaimer('Home details are stored in this browser preview and are not linked to an account service.')}
      <section class="settings-panel settings-form-panel"><div class="settings-profile-large"><span class="settings-avatar">${escapeHtml(home.icon)}</span><span><b>${escapeHtml(home.name)}</b><small>${escapeHtml(home.type)} · ${home.isDefault ? 'Default home' : 'Additional home'}</small></span></div><form class="settings-form settings-profile-form" id="home-settings-form"><div class="settings-form-grid"><label>Home name<input name="name" maxlength="60" value="${escAttr(home.name)}" required></label><label>Home type<select name="type">${['House', 'Apartment', 'Villa', 'Office', 'Farmhouse', 'Other'].map((type) => `<option${type === home.type ? ' selected' : ''}>${type}</option>`).join('')}</select></label><label>Address<input name="address" maxlength="120" value="${escAttr(home.address)}"></label><label>City<input name="city" maxlength="60" value="${escAttr(home.city)}"></label><label>State / region<input name="state" maxlength="60" value="${escAttr(home.state)}"></label><label>Country<input name="country" maxlength="60" value="${escAttr(home.country)}"></label><label>Home icon<select name="icon">${['⌂', '▦', '♧', '☼', '⌖'].map((icon) => `<option${icon === home.icon ? ' selected' : ''}>${icon}</option>`).join('')}</select></label></div><p class="settings-form-message" id="home-settings-message" aria-live="polite"></p><div class="settings-button-row"><button class="settings-primary-button" type="submit">Save home details</button><button type="button" class="settings-secondary-button" data-home-default="${escAttr(home.id)}">${home.isDefault ? 'Default home' : 'Set as default'}</button><button type="button" class="settings-secondary-button" data-settings-route="dash-homes">Manage all homes</button></div></form></section>`;
  }

  function deviceStatePill(device) {
    return `<span class="settings-state ${device.online ? 'is-good' : 'is-warn'}">${device.online ? 'Online · demo' : 'Offline · demo'}</span>`;
  }

  function renderConnectivity() {
    const devices = deviceList();
    const paired = snapshot().pairedDevices;
    const connectivity = window.HomiotConnectivityClient?.getSnapshot() || {
      baseUrl: '', homeId: '', integrations: [], devices: [], message: '', connected: false,
    };
    const activeHomeId = connectivity.homeId || homesService?.getCurrentHome()?.id || '';
    const matches = devices.filter((device) => {
      const query = connectivityQuery.toLowerCase();
      return (connectivityFilter === 'All Devices' || (connectivityFilter === 'Online' && device.online)
        || (connectivityFilter === 'Offline' && !device.online) || (connectivityFilter === 'Needs Attention' && !device.online))
        && (!query || `${device.name} ${device.room} ${device.kind}`.toLowerCase().includes(query));
    });
    const realDeviceRows = connectivity.devices.map((device) => {
      const capabilities = device.capabilities || [];
      const state = device.state || {};
      const controlDisabled = device.availability !== 'online' ? ' disabled' : '';
      const controls = [];
      if (capabilities.includes('power')) controls.push(`<button type="button" data-real-command="power" data-device-id="${escAttr(device.id)}" data-value="${state.power ? 'false' : 'true'}"${controlDisabled}>${state.power ? 'Turn off' : 'Turn on'}</button>`);
      if (capabilities.includes('brightness')) controls.push(`<button type="button" data-real-command="brightness" data-device-id="${escAttr(device.id)}" data-value="${Math.max(0, (state.brightness || 0) - 10)}"${controlDisabled}>Brightness −</button><button type="button" data-real-command="brightness" data-device-id="${escAttr(device.id)}" data-value="${Math.min(100, (state.brightness || 0) + 10)}"${controlDisabled}>Brightness +</button>`);
      if (capabilities.includes('fan_speed')) controls.push(`<button type="button" data-real-command="fan_speed" data-device-id="${escAttr(device.id)}" data-value="${Math.max(0, (state.fan_speed || 0) - 10)}"${controlDisabled}>Fan speed −</button><button type="button" data-real-command="fan_speed" data-device-id="${escAttr(device.id)}" data-value="${Math.min(100, (state.fan_speed || 0) + 10)}"${controlDisabled}>Fan speed +</button>`);
      if (capabilities.includes('temperature') && Number.isFinite(state.temperature)) controls.push(`<button type="button" data-real-command="temperature" data-device-id="${escAttr(device.id)}" data-value="${state.temperature - 1}"${controlDisabled}>Temperature −</button><button type="button" data-real-command="temperature" data-device-id="${escAttr(device.id)}" data-value="${state.temperature + 1}"${controlDisabled}>Temperature +</button>`);
      if (capabilities.includes('lock')) controls.push(`<button type="button" data-real-command="lock" data-device-id="${escAttr(device.id)}" data-value="${state.locked ? 'unlock' : 'lock'}"${controlDisabled}>${state.locked ? 'Unlock' : 'Lock'}</button>`);
      const reading = capabilities.includes('sensor_reading') ? `<span class="integration-device-reading">${escapeHtml(state.value ?? 'No reading')}${state.unit ? ` ${escapeHtml(state.unit)}` : ''}</span>` : '';
      const rooms = homesService?.getRooms(connectivity.homeId) || snapshot().rooms;
      return `<article class="integration-device"><div><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.manufacturer || device.hardwareType)} · ${escapeHtml(device.protocol)} · ${escapeHtml(device.connectionType)}</small><small>Capabilities: ${escapeHtml(capabilities.join(', '))} · Last communication: ${escapeHtml(device.lastCommunication || 'Not reported')}</small></div><span class="integration-status ${device.availability === 'online' ? 'is-good' : 'is-warn'}">${escapeHtml(device.availability)}</span>${reading}<label class="integration-room-select">Room<select data-real-device-room="${escAttr(device.id)}"><option value="">Unassigned</option>${rooms.map((room) => `<option value="${escAttr(room.id)}"${room.id === device.roomId ? ' selected' : ''}>${escapeHtml(room.name)}</option>`).join('')}${device.roomId && !rooms.some((room) => room.id === device.roomId) ? `<option value="${escAttr(device.roomId)}" selected>${escapeHtml(device.roomId)}</option>` : ''}</select></label><div class="integration-device-controls">${controls.join('') || '<span>Read-only or no reported control state</span>'}</div></article>`;
    }).join('');
    return `${pageHeader('dash-connectivity', 'Device Connectivity', 'Configure supported gateways and manage verified, capability-based device connections.')}
      ${subnav('dash-connectivity')}${disclaimer('Legacy inventory rows below are simulated. Real integrations and imported devices are displayed separately and are never substituted for demo hardware. Restart and firmware operations are not implemented.')}
      <section class="settings-panel integration-backend-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">SUPPORTED REAL INTEGRATIONS · PHASE 1</span><h2>Connect to an integration backend</h2></div><span class="integration-status ${connectivity.connected ? 'is-good' : ''}">${connectivity.connected ? 'Authenticated' : 'Not connected'}</span></div>
        <p class="settings-description">MQTT discovery and Home Assistant REST/WebSocket are implemented in the separate local backend. Access tokens stay in page memory only. Integration passwords are sent directly to the backend for encrypted storage.</p>
        <form class="integration-form" id="integration-connect-form"><label>Backend URL<input name="backendUrl" type="url" required placeholder="http://127.0.0.1:8788" value="${escAttr(connectivity.baseUrl || (location.port === '8788' ? location.origin : ''))}"></label><label>Backend access token<input name="accessToken" type="password" autocomplete="off" required placeholder="Provisioned by the backend administrator"></label><label>Authorized home ID<input name="homeId" required maxlength="100" value="${escAttr(activeHomeId)}" placeholder="Must exactly match the backend allowlist"></label><div class="integration-form-actions"><button class="settings-primary-button" type="submit">Authenticate & load</button>${connectivity.connected ? '<button class="settings-secondary-button" type="button" data-integration-disconnect>Disconnect</button>' : ''}</div></form>
        <p class="integration-message" role="status" aria-live="polite">${escapeHtml(connectivity.message || 'No credentials are saved in this browser.')}</p>
      </section>
      ${connectivity.connected ? `<section class="settings-panel settings-panel-spaced"><div class="settings-panel-heading"><div><span class="settings-eyebrow">SERVER-STORED CONFIGURATION</span><h2>Add an integration</h2></div></div><form class="integration-form integration-form-grid" id="integration-add-form"><label>Protocol<select name="protocol"><option value="mqtt">MQTT broker</option><option value="home_assistant">Home Assistant</option></select></label><label>Display name<input name="name" required maxlength="80" placeholder="Home MQTT broker"></label><label>Server URL<input name="url" type="url" required maxlength="2048" placeholder="mqtts://broker.example or https://homeassistant.example"></label><label class="mqtt-only-field">MQTT username<input name="username" maxlength="160" autocomplete="off"></label><label class="mqtt-only-field">MQTT password<input name="password" type="password" maxlength="512" autocomplete="new-password"></label><label class="mqtt-only-field">Discovery topic prefix<input name="topicPrefix" value="homeassistant" maxlength="80"></label><label class="home-assistant-only-field" hidden>Home Assistant long-lived access token<input name="haToken" type="password" maxlength="512" autocomplete="new-password"></label><div class="integration-form-actions"><button class="settings-primary-button" type="submit">Save integration securely</button></div></form>
        <div class="integration-list">${connectivity.integrations.length ? connectivity.integrations.map((integration) => `<article class="integration-row"><div><b>${escapeHtml(integration.name)}</b><small>${escapeHtml(integration.protocol)} · ${escapeHtml(integration.status)}${integration.lastError ? ` · ${escapeHtml(integration.lastError)}` : ''}</small></div><div class="integration-actions"><button type="button" data-integration-action="test" data-integration-id="${escAttr(integration.id)}">Test</button><button type="button" data-integration-action="discover" data-integration-id="${escAttr(integration.id)}">Discover / import</button><button type="button" data-integration-action="remove" data-integration-id="${escAttr(integration.id)}">Remove</button></div></article>`).join('') : '<p class="settings-empty-state">No integrations configured for this home.</p>'}</div>
      </section><section class="settings-panel settings-panel-spaced"><div class="settings-panel-heading"><div><span class="settings-eyebrow">VERIFIED BACKEND DEVICES</span><h2>Real device inventory</h2></div><span>${connectivity.devices.length} imported</span></div><p class="settings-description">Only controls listed in a device’s reported capabilities are shown. A command is reported successful only after the adapter observes matching device state.</p><div class="integration-device-list">${realDeviceRows || '<p class="settings-empty-state">Discover and import a device from an authenticated integration.</p>'}</div></section>` : ''}
      <div class="settings-stat-grid"><article><small>Demo inventory appliances</small><strong>${devices.length}</strong></article><article><small>Online · demo</small><strong>${devices.filter((device) => device.online).length}</strong></article><article><small>Offline · demo</small><strong>${devices.filter((device) => !device.online).length}</strong></article><article><small>Paired gateway previews</small><strong>${paired.length}</strong></article></div>
      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">APPLIANCE CONNECTIONS</span><h2>Connected devices</h2></div>${routeButton('dash-pairing', '＋ Pair device', 'settings-primary-button')}</div>
        <div class="settings-toolbar"><label class="settings-search">⌕ <input id="settings-device-search" type="search" value="${escAttr(connectivityQuery)}" placeholder="Search devices" aria-label="Search connected devices"></label><div class="settings-filter-row">${['All Devices', 'Online', 'Offline', 'Needs Attention'].map((filter) => `<button type="button" class="${connectivityFilter === filter ? 'active' : ''}" data-connectivity-filter="${filter}">${filter}</button>`).join('')}</div></div>
        <div class="settings-device-list">${matches.length ? matches.map((device) => `<article class="settings-device-row"><span class="settings-device-icon">${device.kind === 'light' ? '☼' : device.kind === 'fan' || device.kind === 'exhaust' ? '◉' : device.kind === 'ac' ? '❄' : device.kind === 'pump' ? '⌁' : '▣'}</span><div class="settings-device-main"><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.kind.toUpperCase())} · ${escapeHtml(device.room)} · ${device.online ? 'Signal 82%' : 'Signal unavailable'} · Firmware preview</small></div>${deviceStatePill(device)}<div class="settings-device-actions"><button type="button" data-device-action="details" data-device-id="${escAttr(device.id)}">${expandedDevices.has(device.id) ? 'Hide details' : 'Details'}</button><button type="button" data-device-action="rename" data-device-id="${escAttr(device.id)}">Rename</button><label>Room<select data-device-room="${escAttr(device.id)}">${snapshot().rooms.map((room) => `<option value="${escAttr(room.name)}"${device.room === room.name ? ' selected' : ''}>${escapeHtml(room.name)}</option>`).join('')}${!snapshot().rooms.some((room) => room.name === device.room) ? `<option selected value="${escAttr(device.room)}">${escapeHtml(device.room)}</option>` : ''}</select></label><button type="button" data-device-action="${device.online ? 'offline' : 'reconnect'}" data-device-id="${escAttr(device.id)}">${device.online ? 'Mark offline' : 'Reconnect preview'}</button><button type="button" disabled title="Requires a connected backend">Restart</button><button type="button" disabled title="Firmware updates require a verified backend">Firmware</button><button type="button" data-device-action="remove" data-device-id="${escAttr(device.id)}">Remove</button></div>${expandedDevices.has(device.id) ? `<div class="settings-device-detail"><span>Device ID <b>${escapeHtml(device.id)}</b></span><span>Appliance type <b>${escapeHtml(device.kind)}</b></span><span>Current room <b>${escapeHtml(device.room)}</b></span><span>Last communication <b>${device.online ? 'Just now · demo' : 'Unavailable'}</b></span><span>Power rating <b>${device.watts} W · sample</b></span><p>Firmware and radio details are not verified; no live telemetry is connected.</p></div>` : ''}</article>`).join('') : '<div class="settings-empty-state">No devices match this filter.</div>'}</div>
      </section>
      <section class="settings-panel settings-panel-spaced"><div class="settings-panel-heading"><div><span class="settings-eyebrow">PAIRING PREVIEW INVENTORY</span><h2>ESP32 gateways</h2></div></div><div class="settings-device-list">${paired.length ? paired.map((device) => `<article class="settings-device-row"><span class="settings-device-icon">⌘</span><div class="settings-device-main"><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.deviceId)} · ${escapeHtml(device.mac)} · FW ${escapeHtml(device.firmware)} · ${device.signal}% signal · ${escapeHtml(device.lastSeen)}</small></div><span class="settings-state ${device.status === 'Online' ? 'is-good' : 'is-warn'}">${escapeHtml(device.status)} · demo</span><div class="settings-device-actions"><button type="button" data-paired-action="rename" data-paired-id="${escAttr(device.id)}">Rename</button><label>Room<select data-paired-room="${escAttr(device.id)}">${snapshot().rooms.map((room) => `<option value="${escAttr(room.name)}"${device.room === room.name ? ' selected' : ''}>${escapeHtml(room.name)}</option>`).join('')}</select></label><button type="button" data-paired-action="toggle" data-paired-id="${escAttr(device.id)}">${device.status === 'Online' ? 'Disconnect preview' : 'Reconnect preview'}</button><button type="button" data-paired-action="remove" data-paired-id="${escAttr(device.id)}">Remove</button></div></article>`).join('') : '<div class="settings-empty-state">No paired gateway previews yet.</div>'}</div></section>`;
  }

  function renderPairing() {
    const steps = ['Method', 'Discover', 'Secure', 'Assign room', 'Confirm', 'Complete'];
    const methodContent = pairingStep === 0 ? `<div class="settings-choice-grid">${['Wi-Fi', 'Bluetooth', 'Manual Device ID'].map((method) => `<button type="button" class="settings-choice ${pairingMethod === method ? 'active' : ''}" data-pair-method="${method}"><b>${method === 'Wi-Fi' ? '⌁' : method === 'Bluetooth' ? 'ᛒ' : '⌗'}</b><span>${method}</span><small>${method === 'Manual Device ID' ? 'Enter a provided ID' : `Prepare a ${method} provisioning flow`}</small></button>`).join('')}</div>`
      : pairingStep === 1 ? `<p class="settings-help-copy">${pairingMethod === 'Manual Device ID' ? 'Enter the device ID provided by your gateway. This browser does not discover nearby devices.' : `Nearby entries are illustrative. Browser ${pairingMethod} discovery requires supported native APIs and explicit permission.`}</p><label class="settings-field">Device ID<input id="pair-device-id" value="${escAttr(pairingDevice?.id || '')}" maxlength="48" placeholder="e.g. SN-ESP32-2048"></label>${pairingMethod !== 'Manual Device ID' ? discoveryScanned ? `<p class="settings-discovery-status" role="status">Sample discovery results · no radio scan was performed</p><div class="settings-discovery-list">${discovery.map((device) => `<button type="button" class="${pairingDevice?.id === device.id ? 'active' : ''}" data-select-discovery="${escAttr(device.id)}"><span class="settings-device-icon">⌘</span><span><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.id)} · ${escapeHtml(device.mac)} · ${device.signal}% signal · FW ${escapeHtml(device.firmware)}</small></span>›</button>`).join('')}</div>` : '<button type="button" class="settings-secondary-button" data-pair-scan>Search sample nearby devices</button>' : ''}`
        : pairingStep === 2 ? `<div class="settings-security-callout"><span>◇</span><div><b>Secure pairing boundary</b><p>The preview will not request a device password or broker credential. Real pairing must use authenticated gateway provisioning and verified encryption.</p></div></div><label class="settings-checkbox"><input type="checkbox" id="pair-confirm-secure"> I understand this is a local pairing preview, not a real authenticated device connection.</label>`
          : pairingStep === 3 ? `<label class="settings-field">Device display name<input id="pair-device-name" maxlength="40" value="${escAttr(pairingDevice?.name || 'HOMIOT ESP32 Device')}" required></label><label class="settings-field">Assign to room<select id="pair-device-room">${snapshot().rooms.map((room) => `<option value="${escAttr(room.name)}">${escapeHtml(room.name)}</option>`).join('')}</select></label>`
            : pairingStep === 4 ? `<div class="settings-review-list"><div><small>Method</small><b>${escapeHtml(pairingMethod)}</b></div><div><small>Device ID</small><b>${escapeHtml(pairingDevice?.id || '')}</b></div><div><small>Display name</small><b>${escapeHtml(pairingDevice?.name || '')}</b></div><div><small>Room</small><b>${escapeHtml(pairingDevice?.room || '')}</b></div><p>Confirm to save an offline-safe demo entry. No device discovery or hardware credentials are stored.</p></div>`
              : `<div class="settings-success-state"><span>✓</span><h2>Preview device added</h2><p>${escapeHtml(pairingDevice?.name || 'Your device')} appears in the local gateway inventory. No physical device was paired.</p>${routeButton('dash-connectivity', 'View connectivity →', 'settings-primary-button')}</div>`;
    return `${pageHeader('dash-pairing', 'Connect Your Smart Device', 'A guided setup preview for a future secure ESP32 provisioning flow.')}
      ${subnav('dash-pairing')}${disclaimer('A browser cannot discover arbitrary ESP32 devices or provision Wi-Fi credentials without supported APIs and an authenticated backend.')}
      <section class="settings-panel settings-pairing-panel"><div class="settings-stepper" aria-label="Pairing progress">${steps.map((step, index) => `<span class="${index === pairingStep ? 'active' : index < pairingStep ? 'complete' : ''}"><i>${index < pairingStep ? '✓' : index + 1}</i><small>${step}</small></span>`).join('')}</div><div class="settings-step-content"><span class="settings-eyebrow">STEP ${Math.min(pairingStep + 1, steps.length)} OF ${steps.length}</span>${methodContent}</div><div class="settings-button-row">${pairingStep > 0 && pairingStep < 5 ? '<button type="button" class="settings-secondary-button" data-pair-back>Back</button>' : ''}${pairingStep < 4 ? '<button type="button" class="settings-primary-button" data-pair-next>Continue</button>' : pairingStep === 4 ? '<button type="button" class="settings-primary-button" data-pair-confirm>Confirm preview pairing</button>' : '<button type="button" class="settings-secondary-button" data-pair-reset>Pair another</button>'}${pairingStep < 5 ? '<button type="button" class="settings-cancel-button" data-pair-cancel>Cancel pairing</button>' : ''}</div></section>`;
  }

  function renderRooms() {
    const state = snapshot();
    const devices = deviceList();
    return `${pageHeader('dash-rooms', 'Room Management', 'Create rooms and organize your local appliance inventory.')}
      ${subnav('dash-rooms')}${disclaimer('Room and appliance labels are local demo settings. Removing a room with assigned appliances is blocked until they are reassigned.')}
      <div class="settings-two-column settings-room-layout"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">YOUR SPACES</span><h2>Rooms · ${state.rooms.length}</h2></div></div><div class="settings-room-grid">${state.rooms.map((room) => `<article class="settings-room-card"><span class="settings-room-icon">${escapeHtml(room.icon)}</span><div><b>${escapeHtml(room.name)}</b><small>${devices.filter((device) => device.room === room.name).length} appliances</small></div><button type="button" data-room-edit="${escAttr(room.id)}" aria-label="Edit ${escAttr(room.name)}">Edit</button><button type="button" data-room-remove="${escAttr(room.id)}" aria-label="Remove ${escAttr(room.name)}">×</button></article>`).join('')}</div>
      <form class="settings-form settings-room-form" id="room-form"><h3>Add a room</h3><label>Room name<input name="name" maxlength="32" required placeholder="e.g. Study"></label><label>Room icon<select name="icon"><option value="⌂">Home</option><option value="◷">Bedroom</option><option value="♨">Kitchen</option><option value="◌">Bathroom</option><option value="☼">Balcony</option><option value="♧">Outdoor</option></select></label><button class="settings-primary-button" type="submit">Add room</button><p class="settings-form-message" id="room-message" aria-live="polite"></p></form></section>
      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">DEVICE ASSIGNMENTS</span><h2>Appliances by room</h2></div></div><div class="settings-assignment-list">${devices.map((device) => `<label><span><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.kind)} · simulated</small></span><select data-device-room="${escAttr(device.id)}" aria-label="Assign ${escAttr(device.name)} to room">${state.rooms.map((room) => `<option value="${escAttr(room.name)}"${device.room === room.name ? ' selected' : ''}>${escapeHtml(room.name)}</option>`).join('')}${!state.rooms.some((room) => room.name === device.room) ? `<option selected value="${escAttr(device.room)}">${escapeHtml(device.room)}</option>` : ''}</select></label>`).join('')}</div></section></div>`;
  }

  function renderProfile() {
    const profile = snapshot().profile;
    const displayName = profile.preferredName || profile.name.split(/\s+/)[0];
    const avatar = profile.avatar
      ? `<img src="${escAttr(profile.avatar)}" alt="${escAttr(displayName)} profile photo">`
      : escapeHtml(displayName.charAt(0).toUpperCase());
    return `${pageHeader('dash-user-profile', 'User Profile', 'Update the profile details shown in this browser preview.')}
      ${subnav('dash-user-profile')}${disclaimer('Profile details are stored in this browser only and are not linked to the authentication demo or a server.')}
      <section class="settings-panel settings-form-panel"><div class="settings-profile-large"><span class="settings-avatar" data-profile-avatar-preview>${avatar}</span><span><b>${escapeHtml(displayName)}</b><small>HOMIOT home owner · saved in this browser</small></span></div><form class="settings-form settings-profile-form" id="profile-form"><div class="settings-form-grid"><label>Full name<input name="name" autocomplete="name" maxlength="80" value="${escAttr(profile.name)}" required></label><label>Preferred name<input name="preferredName" autocomplete="nickname" maxlength="40" value="${escAttr(profile.preferredName || '')}" placeholder="How should HOMII address you?"></label><label>Preferred language<select name="preferredLanguage"><option value="en"${profile.preferredLanguage === 'en' ? ' selected' : ''}>English</option><option value="hi"${profile.preferredLanguage === 'hi' ? ' selected' : ''}>हिन्दी</option><option value="or"${profile.preferredLanguage === 'or' ? ' selected' : ''}>ଓଡ଼ିଆ</option></select><small>HOMII uses this when its language is set to automatic.</small></label><label>Email address<input name="email" type="email" autocomplete="email" maxlength="120" value="${escAttr(profile.email)}" required></label><label>Phone number<input name="phone" type="tel" autocomplete="tel" maxlength="24" value="${escAttr(profile.phone)}" required></label><label>Home name<input name="home" maxlength="80" value="${escAttr(profile.home)}" required></label><label>Location<input name="location" maxlength="80" value="${escAttr(profile.location)}" placeholder="Optional location"></label><label class="settings-span-two">Profile photo<input type="file" accept="image/png,image/jpeg,image/webp" data-profile-photo><small>Optional PNG, JPEG, or WebP image up to 512 KB. Stored only in this browser.</small><button type="button" class="settings-secondary-button" data-profile-photo-remove${profile.avatar ? '' : ' hidden'}>Remove photo</button></label></div><p class="settings-form-message" id="profile-message" aria-live="polite"></p><button class="settings-primary-button" type="submit">Save profile changes</button></form></section>`;
  }

  function renderHomiiSettings() {
    const { assistant } = snapshot();
    return `${pageHeader('dash-homii-settings', 'Meet HOMII', 'A personal companion for local smart-home previews and voice controls.')}
      ${subnav('dash-homii-settings')}${disclaimer('HOMII currently uses deterministic on-device command logic and browser speech APIs. Conversation text is not stored. No cloud AI, offline wake-word engine, or physical gateway is connected.')}
      <section class="settings-panel settings-form-panel homii-settings-panel">
        <div class="settings-panel-heading"><div><span class="settings-eyebrow">YOUR ASSISTANT</span><h2>Personalize how HOMII helps</h2></div><span class="settings-state ${assistant.enabled ? 'is-good' : 'is-warn'}">${assistant.enabled ? 'Enabled · local' : 'Disabled'}</span></div>
        <label class="settings-toggle-row"><span><b>Enable HOMII</b><small>Show the assistant entry point and accept typed or manually started commands.</small></span><input type="checkbox" data-homii-setting="enabled"${assistant.enabled ? ' checked' : ''}></label>
        <label class="settings-toggle-row"><span><b>Personalized welcome</b><small>Show one local-time greeting when you first open the dashboard in this page session.</small></span><input type="checkbox" data-homii-setting="greetingEnabled"${assistant.greetingEnabled ? ' checked' : ''}></label>
        <label class="settings-toggle-row"><span><b>Spoken replies</b><small>Uses a voice installed in your browser when available. Audio starts only after your interaction.</small></span><input type="checkbox" data-homii-setting="voiceEnabled"${assistant.voiceEnabled ? ' checked' : ''}></label>
        <label class="settings-toggle-row homii-wakeword-setting"><span><b>“Hey HOMII” wake word</b><small>Unavailable: no bundled offline wake-word model or native microphone service is configured.</small></span><input type="checkbox" disabled aria-label="Hey HOMII wake word unavailable"></label>
        <div class="settings-form-grid homii-voice-settings">
          <label>Assistant language<select data-homii-setting="language"><option value="auto"${assistant.language === 'auto' ? ' selected' : ''}>Automatic detection</option><option value="en"${assistant.language === 'en' ? ' selected' : ''}>English</option><option value="hi"${assistant.language === 'hi' ? ' selected' : ''}>हिन्दी</option><option value="or"${assistant.language === 'or' ? ' selected' : ''}>ଓଡ଼ିଆ</option></select><small>Recognition and speech availability depends on your browser. Odia provider support is not verified.</small></label>
          <label>System voice<select data-homii-voice aria-label="HOMII system voice"><option value="${escAttr(assistant.voiceName)}">System default</option></select></label>
          <label>Speaking speed <output data-homii-rate-output>${Number(assistant.speechRate).toFixed(2).replace(/0$/, '')}×</output><input type="range" min="0.75" max="1.25" step="0.05" value="${assistant.speechRate}" data-homii-setting="speechRate" aria-label="HOMII speaking speed"></label>
          <label>Assistant volume <output data-homii-volume-output>${Math.round(assistant.volume * 100)}%</output><input type="range" min="0" max="1" step="0.05" value="${assistant.volume}" data-homii-setting="volume" aria-label="HOMII speech volume"></label>
        </div>
        <div class="settings-button-row"><button type="button" class="settings-secondary-button" data-voice-open aria-controls="voice-assistant-panel"${assistant.enabled ? '' : ' disabled aria-disabled="true"'}>Open HOMII conversation</button><button type="button" class="settings-secondary-button" data-homii-clear-history>Clear conversation</button></div>
        <p class="settings-form-message" data-homii-settings-message role="status">No audio recordings are saved. Browser speech recognition may use a browser or vendor service; its data handling is outside this app.</p>
        <div class="voice-wakeword-note" role="note"><b>Wake-word support requires a future native Android app or dedicated hub.</b> Browser tabs may be suspended in the background. Do not leave a microphone active expecting continuous detection.</div>
      </section>`;
  }

  function renderSecurity() {
    return `${pageHeader('dash-account-security', 'Account & Security', 'Explore account safety controls without changing real credentials.')}
      ${subnav('dash-account-security')}${disclaimer('No authentication backend is connected. Passwords and tokens are never saved by this page.')}
      <div class="settings-two-column"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">PASSWORD</span><h2>Change password</h2></div></div><form class="settings-form" id="security-password-form"><label>Current password<span class="settings-password-field"><input name="current" type="password" autocomplete="current-password" required><button type="button" data-security-password-toggle="current" aria-label="Show current password">Show</button></span></label><label>New password<span class="settings-password-field"><input name="password" type="password" autocomplete="new-password" minlength="8" required><button type="button" data-security-password-toggle="password" aria-label="Show new password">Show</button></span></label><label>Confirm new password<span class="settings-password-field"><input name="confirm" type="password" autocomplete="new-password" minlength="8" required><button type="button" data-security-password-toggle="confirm" aria-label="Show confirmed password">Show</button></span></label><button type="button" class="settings-inline-link" data-security-action="forgot">Forgot password?</button><p class="settings-form-message" id="security-message" aria-live="polite"></p><button class="settings-primary-button" type="submit">Validate demo form</button></form></section>
      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">ACCOUNT PROTECTION</span><h2>Security options</h2></div></div><label class="settings-toggle-row"><span><b>Two-factor authentication</b><small>Demo preference only; no second factor is enrolled.</small></span><input type="checkbox" data-settings-toggle="twoFactor"${snapshot().twoFactor ? ' checked' : ''}></label><div class="settings-session-card"><b>Active sessions</b><small>This browser · Current session · Demo only</small><span class="settings-state is-good">Current</span></div><button type="button" class="settings-secondary-button" data-security-action="logout">Log out of all devices</button><hr class="settings-divider"><div class="settings-danger-zone"><b>Delete account</b><p>Account deletion is unavailable because this is not a real account.</p><button type="button" class="settings-danger-button" data-security-action="delete">Review account deletion</button></div></section></div>`;
  }

  function renderRemote() {
    const remote = snapshot().remote;
    const scenario = remote.cloud !== 'Connected' ? 'cloud' : remote.gateway !== 'Online' ? 'gateway' : remote.lastSync === 'Synchronization failed' ? 'sync' : 'normal';
    return `${pageHeader('dash-remote', 'Remote Access', 'Review the cloud and gateway connection preview.')}
      ${subnav('dash-remote')}${disclaimer('Remote access is a local preference preview. No cloud API, gateway, MQTT broker, or device credentials are connected.')}
      <div class="settings-two-column"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">ACCESS CONTROL</span><h2>Remote connection</h2></div><span class="settings-state ${remote.enabled ? 'is-good' : 'is-warn'}">${remote.enabled ? 'Enabled · preview' : 'Disabled · preview'}</span></div><label class="settings-toggle-row"><span><b>Remote access</b><small>Toggle the local preview setting only.</small></span><input type="checkbox" data-settings-toggle="remote"${remote.enabled ? ' checked' : ''}></label><div class="settings-remote-status"><div><span class="settings-status-icon">◇</span><span><b>Cloud connection</b><small>Authenticated cloud status not verified</small></span><strong>${escapeHtml(remote.cloud)} · demo</strong></div><div><span class="settings-status-icon">⌂</span><span><b>Home gateway</b><small>Heartbeat is simulated</small></span><strong>${escapeHtml(remote.gateway)} · demo</strong></div><div><span class="settings-status-icon">↻</span><span><b>Last synchronization</b><small>Sample time</small></span><strong>${escapeHtml(remote.lastSync)}</strong></div></div><label class="settings-field">Connection scenario<select data-remote-state><option value="normal"${scenario === 'normal' ? ' selected' : ''}>Connected · online · synced</option><option value="cloud"${scenario === 'cloud' ? ' selected' : ''}>Cloud disconnected</option><option value="gateway"${scenario === 'gateway' ? ' selected' : ''}>Gateway offline</option><option value="sync"${scenario === 'sync' ? ' selected' : ''}>Synchronization failed</option></select></label><div class="settings-secure-indicator">◇ Secure connection status cannot be verified without a backend.</div></section>
      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">REMOTE PERMISSIONS</span><h2>Access preferences</h2></div></div><label class="settings-toggle-row"><span><b>Family control access</b><small>Demo permission; no account authorization is applied.</small></span><input type="checkbox" data-remote-permission="familyControl"${remote.permissions.familyControl ? ' checked' : ''}></label><label class="settings-toggle-row"><span><b>Remote status viewing</b><small>Demo preference; no remote connection is enabled by this toggle.</small></span><input type="checkbox" data-remote-permission="remoteViewing"${remote.permissions.remoteViewing ? ' checked' : ''}></label><div class="settings-panel-heading settings-troubleshooting-heading"><div><span class="settings-eyebrow">TROUBLESHOOTING</span><h2>Connection help</h2></div></div><ol class="settings-checklist"><li>Confirm that your home gateway has power and a working local network.</li><li>Use the gateway’s secure provisioning flow to configure Wi-Fi.</li><li>Check its service status from the authenticated gateway interface.</li><li>Ask a qualified installer to inspect the hardware if it remains offline.</li></ol><button type="button" class="settings-secondary-button" data-remote-action="sync">Refresh demo status</button></section></div>`;
  }

  function renderPreferences() {
    const pref = snapshot().preferences;
    const toggle = (key, title, description) => `<label class="settings-toggle-row"><span><b>${title}</b><small>${description}</small></span><input type="checkbox" data-preference="${key}"${pref[key] ? ' checked' : ''}></label>`;
    return `${pageHeader('dash-preferences', 'App Preferences', 'Choose language, units, and behavior for this browser.')}
      ${subnav('dash-preferences')}${disclaimer('Preferences are saved locally. Push notifications are not sent by the demo.')}
      <div class="settings-two-column"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">LANGUAGE & UNITS</span><h2>Your experience</h2></div></div><label class="settings-field">Language<select data-preference-select="language"><option value="en"${pref.language === 'en' ? ' selected' : ''}>English</option><option value="hi"${pref.language === 'hi' ? ' selected' : ''}>हिन्दी</option><option value="or"${pref.language === 'or' ? ' selected' : ''}>ଓଡ଼ିଆ</option><option value="es"${pref.language === 'es' ? ' selected' : ''}>Español</option><option value="fr"${pref.language === 'fr' ? ' selected' : ''}>Français</option></select></label><label class="settings-field">Temperature unit<select data-preference-select="temperature"><option value="C"${pref.temperature === 'C' ? ' selected' : ''}>Celsius (°C)</option><option value="F"${pref.temperature === 'F' ? ' selected' : ''}>Fahrenheit (°F)</option></select></label><label class="settings-field">Energy unit<select data-preference-select="energy"><option value="kWh">Kilowatt-hours (kWh)</option></select></label></section><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">APP BEHAVIOR</span><h2>Notifications & data</h2></div></div>${toggle('notifications', 'Push notification preference', 'Preference only; no push is sent.')}${toggle('sounds', 'Sound effects', 'Local preference for future app feedback.')}${toggle('vibration', 'Vibration', 'Available only on supported native devices.')}${toggle('autoRefresh', 'Auto-refresh', 'Refresh the visible preview when state changes.')}${toggle('dataSaver', 'Reduce data usage', 'Future setting for a connected cloud app.')}</section></div>`;
  }

  function renderPrivacy() {
    const reasons = [
      ['camera', 'Camera', 'Optional QR-code scanning during a future device setup.'],
      ['bluetooth', 'Bluetooth', 'Optional nearby discovery on supported devices.'],
      ['location', 'Location', 'Some browser Bluetooth APIs may require a location permission.'],
      ['notifications', 'Notifications', 'Optional alerts when a real notification service is configured.'],
    ];
    return `${pageHeader('dash-privacy', 'Privacy & Permissions', 'Review browser permissions and your privacy choices.')}
      ${subnav('dash-privacy')}${disclaimer('Permissions are requested only after you select an action. This demo does not continuously access your camera, location, Bluetooth, or notifications.')}
      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">BROWSER PERMISSIONS</span><h2>Choose when to allow access</h2></div></div><div class="settings-permission-list">${reasons.map(([key, title, reason]) => `<article><span class="settings-permission-icon">${key === 'camera' ? '▣' : key === 'bluetooth' ? 'ᛒ' : key === 'location' ? '⌖' : '♧'}</span><span><b>${title}</b><small>${reason}</small></span><span class="settings-state ${permissionState[key] === 'Granted' ? 'is-good' : ''}">${permissionState[key]}</span><button type="button" data-permission="${key}">${permissionState[key] === 'Granted' ? 'Check status' : 'Request when needed'}</button></article>`).join('')}</div></section>
      <div class="settings-two-column settings-panel-spaced"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">DATA CHOICES</span><h2>Data sharing</h2></div></div><label class="settings-toggle-row"><span><b>Share optional usage analytics</b><small>No analytics are transmitted from this local demo.</small></span><input type="checkbox" data-settings-toggle="dataSharing"${snapshot().privacy.dataSharing ? ' checked' : ''}></label><p class="settings-help-copy">Local settings and demo device values stay in this browser’s storage. Wi-Fi passwords, account passwords, and access tokens are not collected by this module.</p></section><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">LEGAL</span><h2>Policies</h2></div></div><a class="settings-legal-link" href="#privacy" data-legal-link="Privacy Policy">Privacy policy <span>↗</span></a><a class="settings-legal-link" href="#terms" data-legal-link="Terms & Conditions">Terms & conditions <span>↗</span></a></section></div>`;
  }

  function renderHelp() {
    const faqs = [
      ['Why can’t this page change my Wi-Fi?', 'A normal browser page cannot scan or configure the phone or router Wi-Fi connection. Use the operating system network settings or a secure gateway provisioning portal.'],
      ['How do I pair an ESP32?', 'Use the pairing wizard to preview the steps. Real discovery and provisioning require an authenticated backend or supported native app APIs with explicit permissions.'],
      ['Why does a device say demo?', 'All device states, signal levels, and firmware information in this prototype are sample values. No physical commands are sent.'],
      ['What should I do if a device appears offline?', 'Check the local network and gateway status in the gateway interface. Do not rely on this browser preview for safety-critical monitoring.'],
      ['Are my Wi-Fi credentials stored?', 'HOMIOT never requests or stores Wi-Fi credentials. Provision Wi-Fi only through your gateway’s secure local setup flow.'],
    ];
    return `${pageHeader('dash-help', 'Help & Support', 'Guidance for the HOMIOT preview and future connectivity setup.')}
      ${subnav('dash-help')}${disclaimer('This app is a local prototype without a support backend. No support ticket or email is sent.')}
      <div class="settings-two-column"><section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">QUICK ANSWERS</span><h2>Frequently asked questions</h2></div></div><div class="settings-faq-list">${faqs.map(([question, answer]) => `<details><summary>${question}<span>＋</span></summary><p>${answer}</p></details>`).join('')}</div></section>      <section class="settings-panel"><div class="settings-panel-heading"><div><span class="settings-eyebrow">NEED A HAND?</span><h2>Troubleshooting</h2></div></div><div class="settings-support-card"><b>Network troubleshooting</b><p>Confirm router and gateway connectivity in their own trusted interfaces. Do not share network passwords in support requests.</p></div><div class="settings-support-card"><b>ESP32 pairing</b><p>Check power, local provisioning instructions, device identity, and secure gateway authentication.</p></div><div class="settings-support-card"><b>App version</b><p>HOMIOT browser preview · Module 06 · Local demo</p></div><button type="button" class="settings-secondary-button" data-help-action="contact">Contact support</button> <button type="button" class="settings-secondary-button" data-help-action="report">Report a problem</button></section></div>`;
  }

  function render() {
    if (!activeRoute || !routes[activeRoute]) return;
    const [title, view] = routes[activeRoute];
    try {
      root.dataset.route = activeRoute;
      root.innerHTML = `<div class="settings-module">${view === 'settings' ? renderHome()
        : view === 'wifi' ? renderWifi()
          : view === 'connectivity' ? renderConnectivity()
            : view === 'pairing' ? renderPairing()
              : view === 'rooms' ? renderRooms()
                : view === 'home-settings' ? renderHomeSettings()
                        : view === 'profile' ? renderProfile()
                          : view === 'homii' ? renderHomiiSettings()
                          : view === 'security' ? renderSecurity()
                    : view === 'remote' ? renderRemote()
                      : view === 'preferences' ? renderPreferences()
                        : view === 'privacy' ? renderPrivacy()
                          : renderHelp()}</div>`;
      root.setAttribute('aria-label', title);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Settings preview could not be loaded.';
      root.innerHTML = `<div class="settings-module"><section class="settings-panel settings-error-panel"><h1>Settings unavailable</h1><p>${escapeHtml(message)}</p><button type="button" class="settings-secondary-button" data-settings-route="dash-settings">Return to settings</button></section></div>`;
      toast(message, true);
    }
  }

  function handleRoute(route) {
    activeRoute = routes[route] ? route : '';
    root.hidden = !activeRoute;
    if (!activeRoute) return;
    document.querySelector('#dashboard-content').hidden = true;
    document.querySelector('#device-management').hidden = true;
    document.querySelector('#device-detail-page').hidden = true;
    document.querySelector('#advanced-features').hidden = true;
    document.querySelector('#dashboard-profile-panel').hidden = true;
    document.querySelectorAll('.dashboard-tab').forEach((tab) => {
      const active = tab.dataset.dashRoute === 'dash-profile';
      tab.classList.toggle('active', active);
      if (active) tab.setAttribute('aria-current', 'page');
      else tab.removeAttribute('aria-current');
    });
    render();
  }

  async function requestPermission(key) {
    try {
      if (key === 'notifications') {
        if (!('Notification' in window)) throw new Error('Notifications are not supported in this browser context.');
        const status = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission;
        permissionState.notifications = status === 'granted' ? 'Granted' : status === 'denied' ? 'Denied' : 'Not requested';
      } else if (key === 'location') {
        if (!navigator.geolocation) throw new Error('Location is not supported by this browser.');
        await new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 8000, maximumAge: 0 }));
        permissionState.location = 'Granted';
      } else if (key === 'camera') {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access is not supported in this browser context.');
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach((track) => track.stop());
        permissionState.camera = 'Granted';
      } else if (key === 'bluetooth') {
        if (!navigator.bluetooth?.requestDevice) throw new Error('Bluetooth discovery is unavailable here; use a supported native flow.');
        await navigator.bluetooth.requestDevice({ acceptAllDevices: true });
        permissionState.bluetooth = 'Granted';
      }
      toast(`${key[0].toUpperCase()}${key.slice(1)} permission: ${permissionState[key]}.`);
    } catch (error) {
      permissionState[key] = error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError' ? 'Denied' : 'Unavailable';
      toast(error.message || 'Permission could not be requested.', true);
    }
    render();
  }

  function handleClick(event) {
    if (event.target.closest('[data-profile-photo-remove]')) {
      const input = document.querySelector('[data-profile-photo]');
      const preview = document.querySelector('[data-profile-avatar-preview]');
      if (input) {
        input.value = '';
        input.dataset.avatarData = '';
      }
      if (preview) preview.textContent = (snapshot().profile.preferredName || snapshot().profile.name).charAt(0).toUpperCase();
      event.target.closest('[data-profile-photo-remove]').hidden = true;
      return;
    }
    if (event.target.closest('[data-homii-clear-history]')) {
      window.HomiotVoiceAssistant?.clearHistory();
      const message = document.querySelector('[data-homii-settings-message]');
      if (message) message.textContent = 'Conversation cleared. No conversation text is stored by HOMIOT.';
      return;
    }
    const nav = event.target.closest('[data-settings-route]');
    if (nav) { window.setRoute(nav.dataset.settingsRoute); return; }
    if (event.target.closest('[data-integration-disconnect]')) {
      window.HomiotConnectivityClient?.clearCredentials();
      render();
      toast('Integration backend disconnected; the access token was cleared from memory.');
      return;
    }
    const integrationAction = event.target.closest('[data-integration-action]');
    if (integrationAction) {
      const { integrationId, integrationAction: action } = integrationAction.dataset;
      if (action === 'remove' && !window.confirm('Remove this integration and its imported devices from the backend?')) return;
      void (async () => {
        try {
          if (action === 'remove') await window.HomiotConnectivityClient.removeIntegration(integrationId);
          else await window.HomiotConnectivityClient.integrationAction(integrationId, action);
          render();
          toast(window.HomiotConnectivityClient.getSnapshot().message);
        } catch (error) {
          let message = error instanceof Error ? error.message : 'Integration request failed.';
          try {
            await window.HomiotConnectivityClient.refresh();
            render();
          } catch (refreshError) {
            message += ` Status refresh failed: ${refreshError instanceof Error ? refreshError.message : 'unknown error'}`;
          }
          toast(message, true);
        }
      })();
      return;
    }
    const realCommand = event.target.closest('[data-real-command]');
    if (realCommand) {
      const value = realCommand.dataset.realCommand === 'power'
        ? realCommand.dataset.value === 'true'
        : realCommand.dataset.realCommand === 'lock'
          ? realCommand.dataset.value
          : Number(realCommand.dataset.value);
      void (async () => {
        try {
          await window.HomiotConnectivityClient.command(realCommand.dataset.deviceId, realCommand.dataset.realCommand, value);
          render();
          toast(window.HomiotConnectivityClient.getSnapshot().message);
        } catch (error) {
          let message = error instanceof Error ? error.message : 'The device command was not verified.';
          try {
            await window.HomiotConnectivityClient.refresh();
            render();
          } catch (refreshError) {
            message += ` Device state refresh failed: ${refreshError instanceof Error ? refreshError.message : 'unknown error'}`;
          }
          toast(message, true);
        }
      })();
      return;
    }
    const wifiAction = event.target.closest('[data-wifi-action]');
    if (wifiAction) {
      wifiNetworks = networks.map((network) => ({ ...network }));
      toast('Sample network examples shown. No radio scan was performed.');
      render();
      return;
    }
    const securityPasswordToggle = event.target.closest('[data-security-password-toggle]');
    if (securityPasswordToggle) {
      const input = document.querySelector(`#security-password-form [name="${securityPasswordToggle.dataset.securityPasswordToggle}"]`);
      input.type = input.type === 'password' ? 'text' : 'password';
      securityPasswordToggle.textContent = input.type === 'password' ? 'Show' : 'Hide';
      securityPasswordToggle.setAttribute('aria-label', `${input.type === 'password' ? 'Show' : 'Hide'} ${securityPasswordToggle.dataset.securityPasswordToggle} password`);
      return;
    }
    if (event.target.closest('[data-pair-scan]')) {
      discoveryScanned = true;
      toast(`Sample ${pairingMethod} entries shown. No physical discovery was performed.`);
      render();
      return;
    }
    const filter = event.target.closest('[data-connectivity-filter]');
    if (filter) { connectivityFilter = filter.dataset.connectivityFilter; render(); return; }
    const pairMethod = event.target.closest('[data-pair-method]');
    if (pairMethod) { pairingMethod = pairMethod.dataset.pairMethod; render(); return; }
    const discovered = event.target.closest('[data-select-discovery]');
    if (discovered) {
      const item = discovery.find((device) => device.id === discovered.dataset.selectDiscovery);
      pairingDevice = { id: item.id, name: item.name, room: snapshot().rooms[0]?.name || 'Living Room' };
      render();
      return;
    }
    if (event.target.closest('[data-pair-next]')) {
      if (pairingStep === 1) {
        const id = document.querySelector('#pair-device-id')?.value.trim();
        if (!id) { toast('Select a nearby demo entry or enter a device ID.', true); return; }
        const found = discovery.find((device) => device.id === id);
        pairingDevice = { ...(pairingDevice || {}), id, name: found?.name || 'HOMIOT ESP32 Device', room: pairingDevice?.room || snapshot().rooms[0]?.name || 'Living Room' };
      }
      if (pairingStep === 2 && !document.querySelector('#pair-confirm-secure')?.checked) { toast('Confirm the secure provisioning boundary to continue.', true); return; }
      if (pairingStep === 3) {
        pairingDevice.name = document.querySelector('#pair-device-name').value.trim();
        pairingDevice.room = document.querySelector('#pair-device-room').value;
        if (!pairingDevice.name) { toast('Enter a display name for this preview device.', true); return; }
      }
      pairingStep = Math.min(pairingStep + 1, 4);
      render();
      return;
    }
    if (event.target.closest('[data-pair-back]')) { pairingStep = Math.max(pairingStep - 1, 0); render(); return; }
    if (event.target.closest('[data-pair-confirm]')) {
      run(() => service.addPairedDevice({ name: pairingDevice.name, deviceId: pairingDevice.id, room: pairingDevice.room }), 'Demo pairing entry saved locally; no hardware was paired.');
      pairingStep = 5;
      render();
      return;
    }
    if (event.target.closest('[data-pair-reset]')) { pairingStep = 0; pairingDevice = null; render(); return; }
    if (event.target.closest('[data-pair-cancel]')) { pairingStep = 0; pairingDevice = null; discoveryScanned = false; window.setRoute('dash-settings'); return; }
    const deviceAction = event.target.closest('[data-device-action]');
    if (deviceAction) {
      const device = devicesService.getDeviceById(deviceAction.dataset.deviceId);
      if (deviceAction.dataset.deviceAction === 'details') {
        if (expandedDevices.has(device.id)) expandedDevices.delete(device.id);
        else expandedDevices.add(device.id);
        render();
      } else if (deviceAction.dataset.deviceAction === 'rename') {
        const name = window.prompt('New device name', device.name);
        if (name !== null) run(() => devicesService.updateDeviceName(device.id, name), 'Device renamed in the shared demo inventory.');
      } else if (deviceAction.dataset.deviceAction === 'remove') {
        if (window.confirm(`Remove ${device.name} from the local demo inventory?`)) run(() => devicesService.removeDevice(device.id), 'Device removed from the local demo inventory.');
      } else if (deviceAction.dataset.deviceAction === 'offline') run(() => devicesService.setDeviceOnline(device.id, false), 'Device marked offline in the local preview.');
      else run(() => devicesService.setDeviceOnline(device.id, true), 'Device reconnected in the local preview.');
      return;
    }
    const pairedAction = event.target.closest('[data-paired-action]');
    if (pairedAction) {
      const device = snapshot().pairedDevices.find((item) => item.id === pairedAction.dataset.pairedId);
      if (!device) return;
      if (pairedAction.dataset.pairedAction === 'rename') {
        const name = window.prompt('New gateway preview name', device.name);
        if (name !== null) run(() => service.updatePairedDevice(device.id, { name }), 'Gateway preview renamed.');
      } else if (pairedAction.dataset.pairedAction === 'remove') {
        if (window.confirm('Remove this paired gateway preview? No physical device will be changed.')) run(() => service.removePairedDevice(device.id), 'Gateway preview removed.');
      } else run(() => service.updatePairedDevice(device.id, { status: device.status === 'Online' ? 'Offline' : 'Online' }), 'Gateway status changed in the local preview.');
      return;
    }
    const roomEdit = event.target.closest('[data-room-edit]');
    if (roomEdit) {
      const room = snapshot().rooms.find((item) => item.id === roomEdit.dataset.roomEdit);
      if (!room) return;
      const name = window.prompt('Room name', room.name);
      if (name !== null) {
        const icon = window.prompt('Room icon (one character)', room.icon);
        run(() => homesService.saveRoom({ id: room.id, name, icon }), 'Room updated.');
      }
      return;
    }
    const roomRemove = event.target.closest('[data-room-remove]');
    if (roomRemove) {
      const room = snapshot().rooms.find((item) => item.id === roomRemove.dataset.roomRemove);
      if (room && window.confirm(`Remove ${room.name}? Reassign devices and cameras first.`)) run(() => homesService.removeRoom(room.id), 'Room removed.');
      return;
    }
    const setDefault = event.target.closest('[data-home-default]');
    if (setDefault) { run(() => homesService.setDefaultHome(setDefault.dataset.homeDefault), 'Default home updated.'); return; }
    const securityAction = event.target.closest('[data-security-action]');
    if (securityAction) {
      if (securityAction.dataset.securityAction === 'forgot') {
        window.setRoute('forgot');
      } else if (securityAction.dataset.securityAction === 'logout') {
        if (window.confirm('This is a demo-only action. No real sessions will be revoked. Continue?')) toast('No real sessions were changed; authentication is not connected.');
      } else if (window.confirm('Account deletion is unavailable in this demo. No account data will be deleted.')) toast('No account was deleted; this is a local preview.');
      return;
    }
    if (event.target.closest('[data-remote-action="sync"]')) {
      run(() => {
        service.getSnapshot();
      }, 'Demo status refreshed. Gateway heartbeat remains unverified.');
      return;
    }
    const permission = event.target.closest('[data-permission]');
    if (permission) { requestPermission(permission.dataset.permission); return; }
    if (event.target.closest('[data-help-action="contact"]')) toast('Support contact is not connected. No message was sent.');
    if (event.target.closest('[data-help-action="report"]')) toast('Support reporting is not connected. No report was sent.');
  }

  function handleChange(event) {
    if (event.target.matches('#integration-add-form [name="protocol"]')) {
      const isMqtt = event.target.value === 'mqtt';
      document.querySelectorAll('#integration-add-form .mqtt-only-field').forEach((field) => { field.hidden = !isMqtt; });
      document.querySelectorAll('#integration-add-form .home-assistant-only-field').forEach((field) => { field.hidden = isMqtt; });
      return;
    }
    if (event.target.matches('[data-real-device-room]')) {
      void (async () => {
        try {
          await window.HomiotConnectivityClient.assignRoom(event.target.dataset.realDeviceRoom, event.target.value || null);
          render();
          toast(window.HomiotConnectivityClient.getSnapshot().message);
        } catch (error) {
          toast(error instanceof Error ? error.message : 'Device room assignment failed.', true);
        }
      })();
      return;
    }
    const homiiPreference = event.target.closest('[data-homii-setting]');
    if (homiiPreference) {
      const key = homiiPreference.dataset.homiiSetting;
      const value = homiiPreference.type === 'checkbox'
        ? homiiPreference.checked
        : key === 'speechRate' || key === 'volume' ? Number(homiiPreference.value) : homiiPreference.value;
      run(() => service.saveAssistantPreferences({ [key]: value }), 'HOMII preference saved in this browser.');
      return;
    }
    if (event.target.matches('[data-homii-voice]')) {
      run(() => service.saveAssistantPreferences({ voiceName: event.target.value }), 'HOMII voice preference saved.');
      return;
    }
    if (event.target.matches('[data-profile-photo]')) {
      const file = event.target.files?.[0];
      if (!file) return;
      const message = document.querySelector('#profile-message');
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 512 * 1024) {
        event.target.value = '';
        if (message) message.textContent = 'Choose a PNG, JPEG, or WebP image under 512 KB.';
        return;
      }
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        if (typeof reader.result !== 'string') {
          if (message) message.textContent = 'The selected profile photo could not be read.';
          return;
        }
        event.target.dataset.avatarData = reader.result;
        const preview = document.querySelector('[data-profile-avatar-preview]');
        if (preview) preview.innerHTML = `<img src="${escAttr(reader.result)}" alt="Profile photo preview">`;
        const remove = document.querySelector('[data-profile-photo-remove]');
        if (remove) remove.hidden = false;
        if (message) message.textContent = 'Photo preview ready. Save your profile to keep it in this browser.';
      });
      reader.addEventListener('error', () => {
        if (message) message.textContent = 'The selected profile photo could not be read.';
      });
      reader.readAsDataURL(file);
      return;
    }
    const deviceRoom = event.target.closest('[data-device-room]');
    if (deviceRoom && activeRoute === 'dash-rooms') {
      run(() => devicesService.updateDeviceRoom(deviceRoom.dataset.deviceRoom, deviceRoom.value), 'Appliance room updated in the shared inventory.');
      return;
    }
    const deviceRoomConnectivity = event.target.closest('[data-device-room]');
    if (deviceRoomConnectivity && activeRoute === 'dash-connectivity') {
      run(() => devicesService.updateDeviceRoom(deviceRoomConnectivity.dataset.deviceRoom, deviceRoomConnectivity.value), 'Appliance room updated in the shared inventory.');
      return;
    }
    const pairedRoom = event.target.closest('[data-paired-room]');
    if (pairedRoom) { run(() => service.updatePairedDevice(pairedRoom.dataset.pairedRoom, { room: pairedRoom.value }), 'Gateway preview room updated.'); return; }
    const preference = event.target.closest('[data-preference]');
    if (preference) { run(() => service.savePreferences({ [preference.dataset.preference]: preference.checked }), 'Preference saved.'); return; }
    const preferenceSelect = event.target.closest('[data-preference-select]');
    if (preferenceSelect) {
      run(() => service.savePreferences({ [preferenceSelect.dataset.preferenceSelect]: preferenceSelect.value }), 'Preference saved.');
      return;
    }
    const remoteScenario = event.target.closest('[data-remote-state]');
    if (remoteScenario) {
      const scenarios = {
        normal: { cloud: 'Connected', gateway: 'Online', lastSync: 'A few seconds ago' },
        cloud: { cloud: 'Cloud disconnected', gateway: 'Online', lastSync: 'Synchronization failed' },
        gateway: { cloud: 'Connected', gateway: 'Gateway offline', lastSync: 'Synchronization failed' },
        sync: { cloud: 'Connected', gateway: 'Online', lastSync: 'Synchronization failed' },
      };
      run(() => service.saveRemotePreview(scenarios[remoteScenario.value]), 'Connection scenario updated in the local preview.');
      return;
    }
    const remotePermission = event.target.closest('[data-remote-permission]');
    if (remotePermission) {
      run(() => service.saveRemotePreview({ permissions: { [remotePermission.dataset.remotePermission]: remotePermission.checked } }), 'Remote permission preference saved locally.');
      return;
    }
    const toggle = event.target.closest('[data-settings-toggle]');
    if (toggle) {
      const key = toggle.dataset.settingsToggle;
      const values = key === 'twoFactor' ? { twoFactor: toggle.checked }
        : key === 'remote' ? { remoteEnabled: toggle.checked }
          : key === 'dataSharing' ? { dataSharing: toggle.checked } : null;
      if (values) run(() => service.saveSecurityPreferences(values), key === 'twoFactor'
        ? 'Two-factor preference saved locally; enrollment is not active.'
        : key === 'remote' ? 'Remote access preview preference saved.' : 'Privacy preference saved locally.');
    }
  }

  function handleInput(event) {
    if (event.target.matches('#settings-device-search')) {
      connectivityQuery = event.target.value;
      const selection = event.target.selectionStart;
      render();
      const input = document.querySelector('#settings-device-search');
      input?.focus();
      input?.setSelectionRange(selection, selection);
    }
    if (event.target.matches('[data-homii-setting="speechRate"]')) {
      const output = document.querySelector('[data-homii-rate-output]');
      if (output) output.value = `${Number(event.target.value).toFixed(2).replace(/0$/, '')}×`;
    }
    if (event.target.matches('[data-homii-setting="volume"]')) {
      const output = document.querySelector('[data-homii-volume-output]');
      if (output) output.value = `${Math.round(Number(event.target.value) * 100)}%`;
    }
  }

  function handleSubmit(event) {
    const form = event.target;
    const id = form.getAttribute('id');
    if (!['room-form', 'profile-form', 'home-settings-form', 'security-password-form', 'integration-connect-form', 'integration-add-form'].includes(id)) return;
    event.preventDefault();
    if (id === 'integration-connect-form') {
      const data = new FormData(form);
      const client = window.HomiotConnectivityClient;
      try {
        client.configure({
          baseUrl: data.get('backendUrl'),
          token: data.get('accessToken'),
          homeId: data.get('homeId'),
        });
      } catch (error) {
        toast(error instanceof Error ? error.message : 'Backend settings are invalid.', true);
        return;
      }
      void (async () => {
        try {
          await client.load();
          render();
          toast('Authenticated integration data loaded from the backend.');
        } catch (error) {
          client.clearCredentials();
          render();
          toast(error instanceof Error ? error.message : 'Backend authentication failed.', true);
        }
      })();
      return;
    }
    if (id === 'integration-add-form') {
      const data = new FormData(form);
      const protocol = data.get('protocol');
      const connection = protocol === 'mqtt'
        ? { url: data.get('url'), username: data.get('username'), password: data.get('password'), topicPrefix: data.get('topicPrefix') }
        : { url: data.get('url'), token: data.get('haToken') };
      void (async () => {
        try {
          await window.HomiotConnectivityClient.addIntegration(protocol, data.get('name'), connection);
          render();
          toast(window.HomiotConnectivityClient.getSnapshot().message);
        } catch (error) {
          toast(error instanceof Error ? error.message : 'Integration could not be saved.', true);
        }
      })();
      return;
    }
    if (id === 'room-form') {
      const data = new FormData(form);
      run(() => homesService.saveRoom({ name: data.get('name'), icon: data.get('icon') }), 'Room added.');
      return;
    }
    if (id === 'profile-form') {
      const data = Object.fromEntries(new FormData(form).entries());
      data.avatar = form.querySelector('[data-profile-photo]')?.dataset.avatarData
        ?? snapshot().profile.avatar;
      run(() => service.saveProfile(data), 'Profile updated in this browser.');
      return;
    }
    if (id === 'home-settings-form') {
      const data = Object.fromEntries(new FormData(form).entries());
      const home = homesService.getCurrentHome();
      run(() => homesService.updateHome(home.id, data), 'Home details saved.');
      return;
    }
    const message = document.querySelector('#security-message');
    const password = form.elements.password.value;
    const confirm = form.elements.confirm.value;
    if (password.length < 8 || password !== confirm) {
      message.textContent = password !== confirm ? 'The new passwords do not match.' : 'Use at least 8 characters.';
      return;
    }
    form.reset();
    message.textContent = 'Form validated locally. No password was stored or changed on an account.';
  }

  document.addEventListener('click', handleClick);
  document.addEventListener('change', handleChange);
  document.addEventListener('input', handleInput);
  document.addEventListener('submit', handleSubmit, true);
  window.addEventListener('smartnest-settings-changed', () => { if (activeRoute) render(); });
  window.addEventListener('smartnest-devices-changed', () => { if (activeRoute) render(); });
  window.addEventListener('smartnest-home-changed', () => { if (activeRoute) render(); });
  window.addEventListener('smartnest-homes-changed', () => { if (activeRoute) render(); });
  window.SmartNestSettingsModule = { handleRoute, render };
})();
