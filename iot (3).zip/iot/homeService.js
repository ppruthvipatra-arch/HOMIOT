(() => {
  const STORAGE_KEY = 'smartnest.homes.preview.v1';
  const deviceService = window.SmartNestDeviceService;
  const suggestedRooms = [
    { name: 'Living Room', icon: '⌂' },
    { name: 'Bedroom', icon: '◷' },
    { name: 'Kitchen', icon: '♨' },
    { name: 'Bathroom', icon: '◌' },
    { name: 'Dining Room', icon: '▤' },
    { name: 'Balcony', icon: '☼' },
    { name: 'Garage', icon: '▥' },
    { name: 'Outdoor', icon: '♧' },
  ];
  const roomCategories = [
    ['Living Room', '⌂'], ['Bedroom', '◷'], ['Kitchen', '♨'], ['Bathroom', '◌'], ['Outdoor', '♧'],
    ['Dining Room', '▤'], ['Study Room', '▣'], ['Guest Room', '◷'], ['Balcony', '☼'],
    ['Garage', '▥'], ['Hall', '⌂'], ['Office / Workplace', '▦'], ['Manager Cabin', '▦'],
    ['Meeting Room', '▤'], ['Conference Room', '▤'], ['Reception Area', '⌂'],
    ['Office Hall', '⌂'], ['Server Room', '▥'], ['Workstation Area', '▣'],
    ['Staff Room', '◷'], ['Waiting Room', '◷'], ['Board Room', '▤'],
    ['Training Room', '▣'], ['Storage Room', '▥'], ['Other', '⌁'],
  ].map(([name, icon]) => ({ name, icon }));
  function roomCategoryFor(name) {
    const category = roomCategories.find((item) => item.name === name);
    if (category) return category.name;
    if (/work|workspace/i.test(name)) return 'Workstation Area';
    if (/meeting|conference|board/i.test(name)) return 'Meeting Room';
    return 'Other';
  }
  function isValidWallpaper(value) {
    return value === undefined || value === null || value === ''
      || ['living', 'bedroom', 'kitchen', 'bathroom', 'dining', 'study', 'office', 'meeting', 'conference', 'hall', 'garden'].includes(value)
      || (typeof value === 'string' && value.length <= 700000
        && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value));
  }
  function validateWallpaper(value) {
    if (value === undefined || value === null || value === '') return '';
    const wallpaper = String(value);
    if (!isValidWallpaper(wallpaper)) throw new Error('Choose a supported local wallpaper.');
    return wallpaper;
  }
  const initialHomes = [
    { id: 'my-home', name: 'My Home', type: 'House', address: '24 Garden Lane', city: 'San Francisco', state: 'CA', country: 'United States', icon: '⌂', favorite: true, isDefault: true, rooms: ['Living Room', 'Bedroom', 'Kitchen', 'Bathroom', 'Outdoor'].map((name) => ({ id: `my-home-${name.toLowerCase().replace(/\W+/g, '-')}`, name, icon: suggestedRooms.find((room) => room.name === name).icon, category: roomCategoryFor(name) })), cameras: [], controllers: [], equipment: [] },
    { id: 'parents-home', name: "Parents' Home", type: 'House', address: '18 Maple Street', city: 'San Jose', state: 'CA', country: 'United States', icon: '⌂', favorite: false, isDefault: false, rooms: ['Living Room', 'Bedroom', 'Kitchen'].map((name) => ({ id: `parents-${name.toLowerCase().replace(/\W+/g, '-')}`, name, icon: suggestedRooms.find((room) => room.name === name).icon, category: roomCategoryFor(name) })), cameras: [], controllers: [], equipment: [] },
    { id: 'office', name: 'Office', type: 'Office', address: '500 Market Street', city: 'San Francisco', state: 'CA', country: 'United States', icon: '▦', favorite: false, isDefault: false, rooms: ['Workspace', 'Meeting Room'].map((name) => ({ id: `office-${name.toLowerCase().replace(/\W+/g, '-')}`, name, icon: '▦', category: roomCategoryFor(name) })), cameras: [], controllers: [], equipment: [] },
    { id: 'farm-house', name: 'Farm House', type: 'Farmhouse', address: 'County Road 12', city: 'Petaluma', state: 'CA', country: 'United States', icon: '♧', favorite: false, isDefault: false, rooms: ['Living Room', 'Kitchen', 'Pump Room', 'Outdoor'].map((name) => ({ id: `farm-${name.toLowerCase().replace(/\W+/g, '-')}`, name, icon: suggestedRooms.find((room) => room.name === name)?.icon || '♧', category: roomCategoryFor(name) })), cameras: [], controllers: [], equipment: [] },
    { id: 'vacation-home', name: 'Vacation Home', type: 'Villa', address: 'Coastal Road', city: 'Monterey', state: 'CA', country: 'United States', icon: '⌂', favorite: false, isDefault: false, rooms: ['Living Room', 'Bedroom', 'Outdoor'].map((name) => ({ id: `vacation-${name.toLowerCase().replace(/\W+/g, '-')}`, name, icon: suggestedRooms.find((room) => room.name === name).icon, category: roomCategoryFor(name) })), cameras: [], controllers: [], equipment: [] },
  ];
  let state;
  let selectedHomeId = 'my-home';
  const clone = (value) => JSON.parse(JSON.stringify(value));

  function isValidHome(home) {
    if (!home || typeof home.id !== 'string' || !home.id.trim()
      || typeof home.name !== 'string' || !home.name.trim() || home.name.length > 60
      || typeof home.type !== 'string' || typeof home.favorite !== 'boolean'
      || typeof home.isDefault !== 'boolean' || !Array.isArray(home.rooms) || home.rooms.length > 8
      || !Array.isArray(home.cameras) || !Array.isArray(home.controllers) || !Array.isArray(home.equipment)) return false;
    if (home.wallpaper !== undefined && !isValidWallpaper(home.wallpaper)) return false;
    const roomNames = home.rooms.map((room) => room && typeof room.name === 'string' ? room.name.trim().toLowerCase() : '');
    if (home.rooms.some((room) => !room || typeof room.id !== 'string' || typeof room.icon !== 'string'
      || (room.category !== undefined && !roomCategories.some((category) => category.name === room.category))
      || (room.wallpaper !== undefined && !isValidWallpaper(room.wallpaper)))
      || roomNames.some((name) => !name || name.length > 32) || new Set(roomNames).size !== roomNames.length
      || new Set(home.rooms.map((room) => room.id)).size !== home.rooms.length) return false;
    const cameraIds = home.cameras.map((camera) => camera && camera.id);
    if (home.cameras.some((camera) => !camera || typeof camera.id !== 'string' || !camera.id
      || typeof camera.name !== 'string' || !camera.name.trim() || typeof camera.cameraType !== 'string'
      || typeof camera.identifier !== 'string' || typeof camera.room !== 'string')
      || new Set(cameraIds).size !== cameraIds.length) return false;
    return home.equipment.every((item) => item && typeof item.id === 'string'
      && typeof item.name === 'string' && typeof item.category === 'string'
      && typeof item.deviceId === 'string' && typeof item.room === 'string');
  }

  function persist(next) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, ...next }));
    } catch (error) {
      throw new Error(`Could not save your home preview: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
  }

  function load() {
    if (state) return;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) {
        state = { homes: clone(initialHomes), recentHomeIds: ['my-home'] };
        persist(state);
      } else {
        const parsed = JSON.parse(saved);
        if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.homes) || !parsed.homes.length
          || parsed.homes.some((home) => !isValidHome(home))
          || new Set(parsed.homes.map((home) => home.id)).size !== parsed.homes.length
          || new Set(parsed.homes.map((home) => home.name.toLowerCase())).size !== parsed.homes.length
          || parsed.homes.filter((home) => home.isDefault).length !== 1
          || !Array.isArray(parsed.recentHomeIds)) {
          throw new Error('Saved home preview has an unsupported format or room count.');
        }
        state = { homes: parsed.homes, recentHomeIds: Array.isArray(parsed.recentHomeIds) ? parsed.recentHomeIds : [] };
      }
      const defaultHome = state.homes.find((home) => home.isDefault) || state.homes[0];
      selectedHomeId = localStorage.getItem(`${STORAGE_KEY}.selected`) || defaultHome.id;
      if (!state.homes.some((home) => home.id === selectedHomeId)) selectedHomeId = defaultHome.id;
      if (deviceService) deviceService.setHomeContext(selectedHomeId);
    } catch (error) {
      state = null;
      throw error instanceof Error ? error : new Error('Home preview could not be loaded.');
    }
  }

  function commit(change) {
    load();
    const next = clone(state);
    change(next);
    persist(next);
    state = next;
    window.dispatchEvent(new CustomEvent('smartnest-homes-changed'));
    return getSnapshot();
  }

  function selectedHome() {
    load();
    const home = state.homes.find((item) => item.id === selectedHomeId);
    if (!home) throw new Error('The selected demo home no longer exists.');
    return home;
  }

  function getCurrentHome() {
    return clone(selectedHome());
  }

  function getCurrentHomeId() {
    load();
    return selectedHomeId;
  }

  function getRooms(homeId = selectedHomeId) {
    load();
    const home = state.homes.find((item) => item.id === homeId);
    return home ? clone(home.rooms) : [];
  }

  function getSnapshot() {
    load();
    const homes = state.homes.map((home) => {
      const devices = deviceService.getDevicesForHome(home.id);
      const online = devices.filter((device) => device.online).length;
      const energyKwh = devices.reduce((total, device) => total + device.watts * (device.on ? 1 : 0.18) * 5 / 1000, 0);
      return {
        ...clone(home),
        deviceCount: devices.length + home.equipment.length,
        onlineDevices: online,
        offlineDevices: devices.length - online,
        cameraCount: home.cameras.length,
        energyKwh: Number(energyKwh.toFixed(2)),
        connection: devices.length === 0 && home.controllers.length === 0 ? 'Not connected' : online === devices.length ? 'Online · demo' : 'Needs attention · demo',
        lastSync: 'Not synchronized · local demo',
      };
    });
    return clone({
      homes,
      selectedHomeId,
      recentHomeIds: state.recentHomeIds,
      suggestedRooms,
      selectedHome: homes.find((home) => home.id === selectedHomeId),
    });
  }

  function selectHome(id) {
    load();
    if (!state.homes.some((home) => home.id === id)) throw new Error('Choose a home in your account.');
    if (id === selectedHomeId) return getSnapshot();
    const previousId = selectedHomeId;
    try {
      localStorage.setItem(`${STORAGE_KEY}.selected`, id);
    } catch (error) {
      throw new Error(`Could not remember the selected home: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
    selectedHomeId = id;
    try {
      deviceService.setHomeContext(id);
    } catch (error) {
      selectedHomeId = previousId;
      try {
        localStorage.setItem(`${STORAGE_KEY}.selected`, previousId);
      } catch (rollbackError) {
        throw new Error(`Home selection failed and the previous selection could not be restored: ${rollbackError instanceof Error ? rollbackError.message : 'browser storage is unavailable'}`);
      }
      throw error;
    }
    commit((next) => {
      next.recentHomeIds = [id, ...next.recentHomeIds.filter((homeId) => homeId !== id)].slice(0, 8);
    });
    window.dispatchEvent(new CustomEvent('smartnest-home-changed', { detail: { homeId: id } }));
    return getSnapshot();
  }

  function createHome(homeData, rooms = []) {
    const name = String(homeData.name || '').trim();
    if (!name || name.length > 60) throw new Error('Home names must be between 1 and 60 characters.');
    if (!Array.isArray(rooms) || rooms.length > 8) throw new Error('Each home can have at most 8 rooms.');
    const normalizedRooms = rooms.map((room) => ({
      id: `room-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: String(room.name || '').trim(),
      icon: String(room.icon || '⌂').slice(0, 3),
      category: String(room.category || room.name || '').slice(0, 40),
      wallpaper: validateWallpaper(room.wallpaper),
    }));
    if (normalizedRooms.some((room) => !room.name || room.name.length > 32)) throw new Error('Room names must be between 1 and 32 characters.');
    if (new Set(normalizedRooms.map((room) => room.name.toLowerCase())).size !== normalizedRooms.length) throw new Error('Room names must be unique within a home.');
    const home = {
      id: `home-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name, type: homeData.type || 'House', address: String(homeData.address || '').trim(),
      city: String(homeData.city || '').trim(), state: String(homeData.state || '').trim(),
      country: String(homeData.country || '').trim(), icon: String(homeData.icon || '⌂').slice(0, 3),
      favorite: false, isDefault: false, rooms: normalizedRooms, cameras: [], controllers: [], equipment: [],
    };
    commit((next) => {
      if (next.homes.some((item) => item.name.toLowerCase() === name.toLowerCase())) throw new Error('A home with this name already exists.');
      next.homes.push(home);
      next.recentHomeIds.unshift(home.id);
    });
    const previousId = selectedHomeId;
    try {
      localStorage.setItem(`${STORAGE_KEY}.selected`, home.id);
    } catch (error) {
      throw new Error(`Could not remember the selected home: ${error instanceof Error ? error.message : 'browser storage is unavailable'}`);
    }
    selectedHomeId = home.id;
    try {
      deviceService.setHomeContext(home.id);
    } catch (error) {
      selectedHomeId = previousId;
      try {
        localStorage.setItem(`${STORAGE_KEY}.selected`, previousId);
      } catch (rollbackError) {
        throw new Error(`The new home was saved but could not be selected, and the previous selection could not be restored: ${rollbackError instanceof Error ? rollbackError.message : 'browser storage is unavailable'}`);
      }
      throw new Error(`Home ${name} was saved, but could not be selected: ${error instanceof Error ? error.message : 'device storage is unavailable'}`);
    }
    window.dispatchEvent(new CustomEvent('smartnest-home-changed', { detail: { homeId: home.id } }));
    return clone(home);
  }

  function updateHome(id, changes) {
    return commit((next) => {
      const home = next.homes.find((item) => item.id === id);
      if (!home) throw new Error('Home not found.');
      for (const key of ['name', 'type', 'address', 'city', 'state', 'country']) {
        if (key in changes) home[key] = String(changes[key]).trim();
      }
      if ('icon' in changes) home.icon = String(changes.icon).slice(0, 3);
      if ('wallpaper' in changes) home.wallpaper = validateWallpaper(changes.wallpaper);
      if (!home.name || home.name.length > 60) throw new Error('Home names must be between 1 and 60 characters.');
      if (next.homes.some((item) => item.id !== id && item.name.toLowerCase() === home.name.toLowerCase())) throw new Error('A home with this name already exists.');
    });
  }

  function setDefaultHome(id) {
    return commit((next) => {
      if (!next.homes.some((home) => home.id === id)) throw new Error('Home not found.');
      next.homes.forEach((home) => { home.isDefault = home.id === id; });
    });
  }

  function toggleFavorite(id) {
    return commit((next) => {
      const home = next.homes.find((item) => item.id === id);
      if (!home) throw new Error('Home not found.');
      home.favorite = !home.favorite;
    });
  }

  function removeHome(id) {
    load();
    if (state.homes.length <= 1) throw new Error('At least one home must remain in this account.');
    const home = state.homes.find((item) => item.id === id);
    if (!home) throw new Error('Home not found.');
    if (id === selectedHomeId) throw new Error('Switch to another home before removing this one.');
    if (home.isDefault) throw new Error('Choose a different default home before removing this one.');
    deviceService.removeHomeContext(id);
    window.SmartNestAdvancedService?.removeHomeContext(id);
    window.SmartNestSettingsService?.removeHomeContext(id);
    return commit((next) => {
      next.homes = next.homes.filter((item) => item.id !== id);
      next.recentHomeIds = next.recentHomeIds.filter((homeId) => homeId !== id);
      if (home.isDefault) next.homes[0].isDefault = true;
    });
  }

  function saveRoom(room) {
    const current = selectedHome();
    const currentRoom = room.id ? current.rooms.find((item) => item.id === room.id) : null;
    if (room.id && !currentRoom) throw new Error('Room not found.');
    const name = room.name === undefined && currentRoom ? currentRoom.name : String(room.name || '').trim();
    if (!name || name.length > 32) throw new Error('Room names must be between 1 and 32 characters.');
    if (room.category !== undefined && !roomCategories.some((category) => category.name === room.category)) {
      throw new Error('Choose a supported room category.');
    }
    return commit((next) => {
      const home = next.homes.find((item) => item.id === selectedHomeId);
      if (room.id) {
        const existing = home.rooms.find((item) => item.id === room.id);
        if (!existing) throw new Error('Room not found.');
        if (home.rooms.some((item) => item.id !== room.id && item.name.toLowerCase() === name.toLowerCase())) throw new Error('A room with this name already exists in this home.');
        deviceService.renameRoomDevices(existing.name, name);
        home.cameras.forEach((camera) => { if (camera.room === existing.name) camera.room = name; });
        existing.name = name;
        if (room.icon) existing.icon = room.icon;
        if (room.category) existing.category = String(room.category).slice(0, 40);
        if ('wallpaper' in room) existing.wallpaper = validateWallpaper(room.wallpaper);
      } else {
        if (home.rooms.length >= 8) throw new Error('Each home can contain no more than 8 rooms.');
        if (home.rooms.some((item) => item.name.toLowerCase() === name.toLowerCase())) throw new Error('A room with this name already exists in this home.');
        home.rooms.push({
          id: `room-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          name, icon: room.icon || '⌂',
          category: String(room.category || roomCategoryFor(name)).slice(0, 40),
          wallpaper: validateWallpaper(room.wallpaper),
        });
      }

      return current;
    });
  }

  function removeRoom(id, moves = {}) {
    const current = selectedHome();
    const room = current.rooms.find((item) => item.id === id);
    if (!room) throw new Error('Room not found.');
    if (current.rooms.length <= 1) throw new Error('Keep at least one room in your home.');
    const devicesToMove = deviceService.getDevices().filter((device) => device.room === room.name);
    const camerasToMove = current.cameras.filter((camera) => camera.room === room.name);
    const equipmentToMove = current.equipment.filter((item) => item.room === room.name);
    const destinationFor = (group, item) => {
      const destination = moves[group]?.[item.id];
      if (!current.rooms.some((candidate) => candidate.id !== id && candidate.name === destination)) {
        throw new Error(`Choose another existing room for ${item.name}.`);
      }
      return destination;
    };
    const assignments = devicesToMove.map((device) => [device, destinationFor('devices', device)]);
    const cameraAssignments = camerasToMove.map((camera) => [camera, destinationFor('cameras', camera)]);
    const equipmentAssignments = equipmentToMove.map((item) => [item, destinationFor('equipment', item)]);
    assignments.forEach(([device, destination]) => deviceService.updateDeviceRoom(device.id, destination));
    return commit((next) => {
      const home = next.homes.find((item) => item.id === selectedHomeId);
      cameraAssignments.forEach(([camera, destination]) => {
        const entry = home.cameras.find((item) => item.id === camera.id);
        if (entry) entry.room = destination;
      });
      equipmentAssignments.forEach(([item, destination]) => {
        const entry = home.equipment.find((candidate) => candidate.id === item.id);
        if (entry) entry.room = destination;
      });
      home.rooms = home.rooms.filter((item) => item.id !== id);
    });
  }

  function addEquipment(equipment) {
    const name = String(equipment.name || '').trim();
    if (!name || name.length > 48 || !equipment.category || !equipment.deviceId) throw new Error('Enter a device name, category, and device ID.');
    return commit((next) => {
      const home = next.homes.find((item) => item.id === selectedHomeId);
      if (home.equipment.some((item) => item.deviceId === equipment.deviceId)
        || deviceService.getDevices().some((item) => item.id === equipment.deviceId)) throw new Error('This device ID already exists in the selected home.');
      home.equipment.push({ id: `equipment-${Date.now()}`, ...equipment, name });
    });
  }

  function addCamera(camera) {
    const name = String(camera.name || '').trim();
    if (!name || name.length > 48 || !camera.cameraType) throw new Error('Enter a camera name and supported camera type.');
    return commit((next) => {
      const home = next.homes.find((item) => item.id === selectedHomeId);
      const cameraId = `camera-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      home.cameras.push({
        id: cameraId, name, cameraType: camera.cameraType, identifier: String(camera.identifier || '').trim(),
        room: String(camera.room || '').trim(), status: 'Offline · not connected', recording: 'Not Recording',
        lastActivity: 'No stream connection', quality: 'Unavailable',
      });
    });
  }

  function updateCamera(id, changes) {
    return commit((next) => {
      const camera = next.homes.find((home) => home.id === selectedHomeId)?.cameras.find((item) => item.id === id);
      if (!camera) throw new Error('Camera preview not found in the selected home.');
      if ('name' in changes) camera.name = String(changes.name).trim();
      if ('room' in changes) camera.room = String(changes.room).trim();
      if (!camera.name) throw new Error('Camera name is required.');
    });
  }

  function removeCamera(id) {
    return commit((next) => {
      const home = next.homes.find((item) => item.id === selectedHomeId);
      home.cameras = home.cameras.filter((camera) => camera.id !== id);
    });
  }

  function reset() {
    state = { homes: clone(initialHomes), recentHomeIds: ['my-home'] };
    selectedHomeId = 'my-home';
    persist(state);
    localStorage.setItem(`${STORAGE_KEY}.selected`, selectedHomeId);
    deviceService.setHomeContext(selectedHomeId);
    window.dispatchEvent(new CustomEvent('smartnest-homes-changed'));
    window.dispatchEvent(new CustomEvent('smartnest-home-changed', { detail: { homeId: selectedHomeId } }));
    return getSnapshot();
  }

  window.SmartNestHomeService = {
    getSnapshot, getCurrentHome, getCurrentHomeId, getRooms, selectHome, createHome, updateHome,
    setDefaultHome, toggleFavorite, removeHome, saveRoom, removeRoom, addEquipment,
    addCamera, updateCamera, removeCamera, reset, suggestedRooms: clone(suggestedRooms), roomCategories: clone(roomCategories),
  };
})();
