# HOMIOT integration backend

Phase one provides an authenticated API with MQTT Home Assistant discovery and Home Assistant REST/WebSocket adapters. The browser UI does not configure integrations or send commands. Use this API only against a broker or Home Assistant server you own or are authorized to administer. A successful response represents a response verified by the configured adapter, not a guarantee of electrical or physical safety.

Matter is intentionally a separate future phase. The registry reports it as planned and rejects attempts to create a Matter integration. Generic HTTP/WebSocket devices, direct Zigbee/Bluetooth adapters, and Modbus are not implemented.

## Requirements and start-up

- Node.js 22.5 or later (uses the built-in `node:sqlite` module).
- Install the MQTT client once from the project root:

  ```powershell
  npm.cmd --prefix backend install
  ```

- Configure these environment variables before starting the process:

| Variable | Required | Default / format |
|---|---:|---|
| `HOMIOT_HOST` | No | `127.0.0.1`; keep loopback unless deployment networking is deliberately secured. |
| `HOMIOT_PORT` | No | `8788` |
| `HOMIOT_DATABASE_PATH` | No | `~/.homiot/homiot.sqlite`; a relative override is resolved from `backend/`. |
| `HOMIOT_SERVE_UI` | No | UI serving is enabled unless set to `false`. The UI has no integration controls. |
| `HOMIOT_API_USERS_JSON` | Yes | JSON array of unique `{ "id", "token", "homes" }` entries. Each token must have at least 32 characters and each user must have an explicit, non-empty home allowlist. |
| `HOMIOT_TELEMETRY_PRODUCERS_JSON` | No | JSON array of unique `{ "id", "token", "ownerId", "homeId", "sourceId" }` gateway credentials. A producer token is restricted to one configured owner's authorized home and one exact source ID. |
| `HOMIOT_CREDENTIAL_KEY` | Yes | Base64-encoded 32-byte key used for AES-256-GCM credential encryption. Keep it stable and secret; changing it makes saved integration credentials unreadable. |
| `HOMIOT_ALLOWED_INTEGRATION_HOSTS` | For remote hosts | Comma-separated exact broker/Home Assistant hostnames. |
| `HOMIOT_ALLOW_INSECURE_LOCAL` | No | Set to `true` only for trusted private-network development; permits private-host `mqtt://` and `http://`. Defaults to disabled. |
| `HOMIOT_ALLOWED_ORIGINS` | No | Comma-separated browser origins allowed by CORS. Same-origin requests are also accepted. |
| `HOMIOT_MQTT_STATE_TIMEOUT_MS` | No | MQTT command state-confirmation timeout; defaults to `8000`. |

Generate a local API token and credential key in PowerShell, then start the server in that same shell:

```powershell
$env:HOMIOT_CREDENTIAL_KEY = node -p "require('node:crypto').randomBytes(32).toString('base64')"
$token = node -p "require('node:crypto').randomBytes(32).toString('hex')"
$env:HOMIOT_API_USERS_JSON = ConvertTo-Json -Compress @(@{ id = 'local-user'; token = $token; homes = @('my-home') })
$env:HOMIOT_ALLOWED_INTEGRATION_HOSTS = 'localhost,127.0.0.1'
$env:HOMIOT_ALLOW_INSECURE_LOCAL = 'true'
npm.cmd --prefix backend start
```

The insecure-local option is only for a trusted private network and must not be used to expose the service publicly. Use TLS for remote endpoints and put the API behind a properly configured HTTPS reverse proxy. Do not commit generated tokens or keys. The backend does not load a `.env` file.

## Authentication and response format

Except for `GET /api/v1/health`, API routes require:

```http
Authorization: Bearer <administrator-provisioned-token>
Content-Type: application/json
```

The API token is not a HOMIOT account credential. The authenticated user can access only the `homeId` values in that user's configured `homes` list. Responses use JSON. Errors have the shape `{ "error": "message" }`; common status codes are `400` invalid input, `401` missing/invalid token, `403` origin or home not allowed, `404` resource missing, `409` conflict, `422` unsupported capability, `429` rate limit, and `502` adapter failure.

## Endpoints

| Method and path | Description |
|---|---|
| `GET /api/v1/health` | Unauthenticated service and adapter phase status. |
| `GET /api/v1/session` | Authenticated user ID and allowed home IDs. |
| `GET /api/v1/integrations?homeId=<id>` | List integrations for one authorized home. Credentials are never returned. |
| `POST /api/v1/integrations` | Add an MQTT or Home Assistant integration. Credentials are encrypted before storage; creation does not claim that a connection succeeded. |
| `POST /api/v1/integrations/<uuid>/test?homeId=<id>` | Test the configured real adapter; returns an error on connection/authentication failure. |
| `POST /api/v1/integrations/<uuid>/discover?homeId=<id>` | Discover/import entities. Provide `{ "homeId": "<id>" }` as the JSON body. |
| `DELETE /api/v1/integrations/<uuid>?homeId=<id>` | Remove an integration and its imported devices. |
| `GET /api/v1/devices?homeId=<id>` | List imported devices for an authorized home. |
| `PATCH /api/v1/devices/<uuid>?homeId=<id>` | Change only the device's `roomId` (string or `null`). |
| `POST /api/v1/devices/<uuid>/commands?homeId=<id>` | Execute an advertised, validated device capability through the adapter and require the adapter to verify reported state. |
| `GET /api/v1/billing/settings?homeId=<id>` | Read the saved tariff assumptions for an authorized home. |
| `PUT /api/v1/billing/settings` | Save explicit tariff assumptions for an authorized home. |
| `POST /api/v1/telemetry` | Store an authenticated, timestamped measurement from a trusted gateway or integration bridge. |
| `GET /api/v1/telemetry?homeId=<id>` | Read authorized home telemetry, optionally filtered by channel, source, time range, and limit. |

### Telemetry ingestion and history

Telemetry writes require a dedicated `HOMIOT_TELEMETRY_PRODUCERS_JSON` bearer token; normal browser/API user tokens cannot submit readings, and producer tokens cannot access user API routes. Each producer credential is bound to an existing API user, one of that user's homes, and one exact `sourceId`. Keep producer tokens only on the trusted gateway or integration bridge; do not put them in the browser or expose ESP devices directly to the internet. This endpoint stores submitted readings; it does not connect to a meter or verify the physical sensor. The dashboard must continue to show unavailable data until a real, trusted producer is configured. Measurements are not converted into bill estimates by this API.

Submit an explicitly measured reading with a UTC timestamp:

```json
{
  "homeId": "my-home",
  "sourceId": "meter.main",
  "channel": "energy_meter",
  "measuredAt": "2026-11-08T07:28:00.000Z",
  "values": {
    "powerW": 428.5,
    "voltageV": 230,
    "energyTodayWh": 1640
  }
}
```

Send it to `POST /api/v1/telemetry` with the producer-specific bearer authorization and JSON content type. Example configuration (replace all values with private high-entropy credentials and exact identifiers):

```json
[
  {
    "id": "main-meter-gateway",
    "token": "<unique high-entropy producer token>",
    "ownerId": "local-user",
    "homeId": "my-home",
    "sourceId": "meter.main"
  }
]
```

Set that JSON as `HOMIOT_TELEMETRY_PRODUCERS_JSON` in the backend environment, separately from `HOMIOT_API_USERS_JSON`. Producer tokens must be unique from user tokens. The browser's normal authorized user token can read history; the producer token can only ingest its bound source.

Each channel accepts only these typed fields:

| Channel | Numeric fields | Other fields |
|---|---|---|
| `energy_meter` | `powerW`, `voltageV`, `currentA`, `powerFactor`, `energyTodayWh`, `energyTotalWh` | — |
| `solar` | `powerW`, `voltageV`, `currentA`, `energyTodayWh`, `energyMonthWh`, `energyYearWh` | — |
| `battery` | `voltageV`, `currentA`, `stateOfChargePercent`, `temperatureC`, `chargePowerW`, `dischargePowerW` | `charging`, `discharging` booleans; `status` string |
| `grid` | `voltageV`, `currentA`, `powerW`, `importTodayWh`, `exportTodayWh`, `importMonthWh`, `exportMonthWh` | `available` boolean |
| `inverter` | `pvInputW`, `batteryInputW`, `batteryOutputW`, `gridInputW`, `gridOutputW`, `acOutputW`, `loadPowerW` | `status` and `operatingMode` strings; `faults` string array |
| `home_load` | `powerW`, `energyTodayWh` | — |

Units are encoded in metric names. UTC timestamps are normalized to millisecond precision. Unknown metrics, invalid types, non-finite numbers, invalid timestamps, and timestamps more than five minutes in the future are rejected. Duplicate source/channel/timestamp submissions with identical values are idempotent; different values for the same key return `409`. Metric names define serialization units only; they are not device safety thresholds or inverter register mappings.

`GET /api/v1/telemetry?homeId=my-home&channel=solar&sourceId=inverter-1&since=2026-11-01T00:00:00.000Z&until=2026-11-08T00:00:00.000Z&limit=100` returns the newest matching rows first, with both `measuredAt` (sensor time) and `receivedAt` (server time). The default limit is 100; the maximum is 500. Empty history returns `{ "available": false, "count": 0, "readings": [] }`. This API currently provides storage and retrieval only: MQTT telemetry subscriptions, device-specific authentication, WebSocket streaming, retention policies, and inverter register maps are not implemented.

The Solar dashboard reads up to 500 records per channel for `solar`, `home_load`, `energy_meter`, `grid`, `battery`, and `inverter`. Daily charts use `energyTodayWh`; monthly and yearly solar counters use `energyMonthWh` and `energyYearWh` when reported. If only daily totals are available, graphs sum those available readings and show coverage limitations; missing days are not interpolated or treated as zero. The energy-flow details include reported inverter PV/AC power, operating mode, status, and faults, plus battery charge/discharge and grid import/export values. The potential bill-offset figure is solar generation multiplied by the saved import rate. It is an upper-bound illustration that assumes all production replaces grid purchases, not measured self-consumption or realized bill savings.

### Tariff settings

The authenticated home user can save a flat-rate estimate configuration without entering it into the browser's local demo settings:

```json
{
  "homeId": "my-home",
  "gridSourceId": "meter.main",
  "tariffPerKWh": 8.5,
  "exportTariffPerKWh": 0,
  "fixedCharges": 120,
  "additionalCharges": 0
}
```

Use `GET /api/v1/billing/settings?homeId=my-home` to read it and `PUT /api/v1/billing/settings` to save it. `gridSourceId` must match the source ID of the home's grid-channel telemetry. All four amounts are required and non-negative; zero must be explicitly supplied where applicable. These are owner-provided tariff assumptions, not utility-verified rates. The browser reports a monthly bill estimate only when the selected source has reported `grid.importMonthWh` in the current UTC calendar month and the settings exist. If the export rate is non-zero, it also requires `grid.exportMonthWh`; then the estimate is `(import kWh × import rate) + fixed charges + additional charges − (export kWh × export rate)`. The Billing screen keeps this backend estimate separate from its editable local demo projection. The backend estimate is not a utility bill, and does not model tiered tariffs, taxes, or billing periods that differ from the calendar month. Missing readings are not treated as zero.

### Create an integration

Home Assistant:

```json
{
  "protocol": "home_assistant",
  "name": "Home Assistant",
  "homeId": "my-home",
  "connection": {
    "url": "https://ha.example.net",
    "token": "<Home Assistant long-lived access token>"
  }
}
```

For trusted private-network development, the URL may be `http://<private-host>:8123` only when `HOMIOT_ALLOW_INSECURE_LOCAL=true` and the exact host passes the local-host check.

MQTT with Home Assistant discovery:

```json
{
  "protocol": "mqtt",
  "name": "Home MQTT broker",
  "homeId": "my-home",
  "connection": {
    "url": "mqtts://broker.example.net:8883",
    "username": "<broker username>",
    "password": "<broker password>",
    "topicPrefix": "homeassistant"
  }
}
```

MQTT supports `mqtts://` and `wss://`. Unencrypted `mqtt://` is restricted to explicitly enabled private-network development. Discovery listens for Home Assistant MQTT discovery topics. Only entities with supported state and control topics/capabilities are imported. A command is not reported successful unless the adapter receives and verifies matching state.

### Test, discover, and control

Example PowerShell requests (keep `$token` in the same shell in which it was generated):

```powershell
$headers = @{ Authorization = "Bearer $token" }
$base = 'http://127.0.0.1:8788/api/v1'
Invoke-RestMethod "$base/session" -Headers $headers

$body = @{
  protocol = 'home_assistant'
  name = 'Home Assistant'
  homeId = 'my-home'
  connection = @{ url = 'http://127.0.0.1:8123'; token = '<HA-token>' }
} | ConvertTo-Json -Depth 5
$created = Invoke-RestMethod "$base/integrations" -Method Post -Headers $headers -ContentType 'application/json' -Body $body
$id = $created.integration.id

Invoke-RestMethod "$base/integrations/$id/test?homeId=my-home" -Method Post -Headers $headers
$discoverBody = @{ homeId = 'my-home' } | ConvertTo-Json
$devices = Invoke-RestMethod "$base/integrations/$id/discover?homeId=my-home" -Method Post -Headers $headers -ContentType 'application/json' -Body $discoverBody
Invoke-RestMethod "$base/devices?homeId=my-home" -Headers $headers
```

A control request must match an imported device's `capabilities`, for example:

```json
{ "action": "power", "value": true }
```

Supported action/value pairs are `power` with a boolean, `brightness` and `fan_speed` with integers from 0 to 100, `temperature` with a finite number from -50 to 100, and `lock` with `lock` or `unlock`. These are API validation bounds, not protective settings or installation guidance. Unsupported/unreported capabilities are rejected. An adapter failure or unverified state returns an error instead of success.

## SQLite models

The database is created automatically at `HOMIOT_DATABASE_PATH` (or `~/.homiot/homiot.sqlite`) with foreign keys enabled and WAL journaling.

- `integrations`: UUID `id`, `owner_id`, `home_id`, checked `protocol` (`mqtt` or `home_assistant`), display `name`, encrypted `credentials`, connection `status`, safe `last_error`, and `created_at`.
- `devices`: UUID `id`, cascading `integration_id`, `owner_id`, `home_id`, optional `room_id`, external `source_id`, `name`, optional `manufacturer`/`model`, `hardware_type`, `protocol`, `connection_type`, JSON-text `capabilities`/`state`, `availability`, and `last_communication`. `(integration_id, source_id)` is unique. Home-scoped indexes support integration/device queries.
- `telemetry_readings`: UUID `id`, `owner_id`, `home_id`, trusted producer `source_id`, checked telemetry `channel`, sensor `measured_at`, server `received_at`, and validated JSON `values_json`. `(owner_id, home_id, source_id, channel, measured_at)` is unique for idempotent ingestion; an indexed home/channel/time key supports history queries.
- `billing_settings`: one row per `owner_id` and `home_id` with explicit import/export rates, fixed/additional charges, and server `updated_at`.

Credentials are encrypted with AES-256-GCM. Database and API device records never expose integration credentials. This database does not contain browser profiles, authentication accounts, homes, or automation definitions.

## Testing

Run the backend tests with Node.js 22.5 or later:

```powershell
npm.cmd --prefix backend test
```

The tests use temporary SQLite files and injected adapter/network fixtures to check validation, home scoping, encryption, discovery, capability checks, and failed/unverified commands. They do not connect to a real broker or Home Assistant instance and do not establish that physical devices work. Before using a real installation, configure a dedicated test home, TLS and host allowlists, verify adapter status/discovery, and independently confirm each device's reported state and safe installation.

## Security boundaries

The server limits request bodies to 64 KiB and rate-limits API requests to 120 per source IP per minute. Host allowlisting, origin checks, home-scoped bearer authorization, capability validation, and no-store API responses are enforced server-side. Do not expose the development server directly to the internet. Install correctly rated enclosed equipment using a qualified electrician; this software does not provide protective thresholds or replace electrical safeguards.
