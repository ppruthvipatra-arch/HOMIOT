import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { createAuthenticator, requireHome } from '../src/auth.js';
import { HomeAssistantAdapter } from '../src/adapters/homeAssistant.js';
import { MqttAdapter } from '../src/adapters/mqtt.js';
import { createVault } from '../src/cryptoVault.js';
import { createDatabase } from '../src/database.js';
import { createApplication } from '../src/server.js';

const temporaryDirectory = mkdtempSync(join(tmpdir(), 'homiot-connectivity-'));
const database = createDatabase(join(temporaryDirectory, 'homiot.sqlite'));
const tokenA = 'a'.repeat(64);
const tokenB = 'b'.repeat(64);
const telemetryToken = 'c'.repeat(64);
const authenticate = createAuthenticator([
  { id: 'alice', token: tokenA, homes: ['my-home'] },
  { id: 'bob', token: tokenB, homes: ['other-home'] },
]);
const authenticateTelemetry = createAuthenticator([
  { id: 'meter-gateway', ownerId: 'alice', token: telemetryToken, homes: ['my-home'], sourceIds: ['meter.main'] },
]);
const vault = createVault(Buffer.alloc(32, 7).toString('base64'));

function deviceFor(integration) {
  return {
    ownerId: integration.owner_id,
    homeId: integration.home_id,
    integrationId: integration.id,
    sourceId: 'light.living_room',
    name: 'Living room light',
    manufacturer: 'Example',
    model: 'Lamp',
    hardwareType: 'light',
    protocol: 'home_assistant',
    connectionType: 'Home Assistant REST/WebSocket',
    capabilities: ['power'],
    state: { power: false },
    availability: 'online',
    lastCommunication: new Date().toISOString(),
  };
}

const homeAssistantAdapter = {
  async test() {
    return { connected: true, message: 'Test adapter responded.' };
  },
  async discover(integration) {
    return [deviceFor(integration)];
  },
  async execute(integration, device, command, credentials) {
    assert.equal(credentials.token, 'home-assistant-secret');
    assert.equal(device.sourceId, 'light.living_room');
    return { ...device, state: { power: command.value } };
  },
};

const mqttAdapter = { close() {} };
const application = createApplication({
  configuration: {
    host: '127.0.0.1',
    port: 0,
    databasePath: join(temporaryDirectory, 'homiot.sqlite'),
    serveUi: true,
    allowInsecureLocal: true,
    allowedHosts: new Set(['127.0.0.1']),
    allowedOrigins: new Set(),
  },
  database,
  vault,
  authenticate,
  authenticateTelemetry,
  adapters: new Map([
    ['mqtt', mqttAdapter],
    ['home_assistant', homeAssistantAdapter],
  ]),
});
await new Promise((resolve) => application.server.listen(0, '127.0.0.1', resolve));
const api = `http://127.0.0.1:${application.server.address().port}/api/v1`;

test('authenticated API scopes data, encrypts credentials, imports devices, and verifies commands', async (t) => {
  t.after(() => {
    application.close();
    rmSync(temporaryDirectory, { recursive: true, force: true });
  });

  const unauthenticated = await fetch(`${api}/session`);
  assert.equal(unauthenticated.status, 401);
  const shell = await fetch(api.replace('/api/v1', '/'));
  assert.equal(shell.status, 200);
  assert.match(await shell.text(), /HOMIOT/);
  const backendFile = await fetch(api.replace('/api/v1', '/backend/package.json'));
  assert.equal(backendFile.status, 404);

  const session = await fetch(`${api}/session`, { headers: { Authorization: `Bearer ${tokenA}` } });
  assert.deepEqual((await session.json()).homes, ['my-home']);
  const sameOriginSession = await fetch(`${api}/session`, {
    headers: { Authorization: `Bearer ${tokenA}`, Origin: new URL(api).origin },
  });
  assert.equal(sameOriginSession.status, 200);
  assert.equal(sameOriginSession.headers.get('access-control-allow-origin'), new URL(api).origin);
  const billingPreflight = await fetch(`${api}/billing/settings`, {
    method: 'OPTIONS',
    headers: {
      Origin: new URL(api).origin,
      'Access-Control-Request-Method': 'PUT',
      'Access-Control-Request-Headers': 'authorization,content-type',
    },
  });
  assert.equal(billingPreflight.status, 204);
  assert.match(billingPreflight.headers.get('access-control-allow-methods'), /\bPUT\b/);
  const crossOriginSession = await fetch(`${api}/session`, {
    headers: { Authorization: `Bearer ${tokenA}`, Origin: 'https://untrusted.example' },
  });
  assert.equal(crossOriginSession.status, 403);

  const emptyTelemetry = await fetch(`${api}/telemetry?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.deepEqual(await emptyTelemetry.json(), { available: false, count: 0, readings: [] });
  const measuredAt = new Date().toISOString().replace(/Z$/, '123456Z');
  const telemetryBody = {
    homeId: 'my-home',
    sourceId: 'meter.main',
    channel: 'energy_meter',
    measuredAt,
    values: { powerW: 428.5, voltageV: 230, energyTodayWh: 1640 },
  };
  const telemetryHeaders = { Authorization: `Bearer ${telemetryToken}`, 'Content-Type': 'application/json' };
  const browserCannotIngest = await fetch(`${api}/telemetry?homeId=my-home`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(telemetryBody),
  });
  assert.equal(browserCannotIngest.status, 401);
  const savedTelemetry = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify(telemetryBody),
  });
  assert.equal(savedTelemetry.status, 201);
  const savedReading = await savedTelemetry.json();
  assert.equal(savedReading.duplicate, false);
  assert.equal(savedReading.reading.channel, 'energy_meter');
  assert.equal(savedReading.reading.measuredAt, new Date(measuredAt).toISOString());
  assert.deepEqual(savedReading.reading.values, telemetryBody.values);

  const duplicateTelemetry = await fetch(`${api}/telemetry?homeId=my-home`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify(telemetryBody),
  });
  assert.equal(duplicateTelemetry.status, 200);
  assert.equal((await duplicateTelemetry.json()).duplicate, true);

  const conflictingTelemetry = await fetch(`${api}/telemetry?homeId=my-home`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({ ...telemetryBody, values: { ...telemetryBody.values, powerW: 429 } }),
  });
  assert.equal(conflictingTelemetry.status, 409);

  const invalidTelemetry = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({ ...telemetryBody, values: { ...telemetryBody.values, voltage: 230 } }),
  });
  assert.equal(invalidTelemetry.status, 400);
  const futureTelemetry = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({
      ...telemetryBody,
      measuredAt: new Date(Date.now() + 6 * 60 * 1000).toISOString(),
    }),
  });
  assert.equal(futureTelemetry.status, 400);
  const invalidDateTelemetry = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({ ...telemetryBody, measuredAt: '2026-02-30T12:00:00.000Z' }),
  });
  assert.equal(invalidDateTelemetry.status, 400);
  const unauthorizedSource = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({ ...telemetryBody, sourceId: 'meter.other' }),
  });
  assert.equal(unauthorizedSource.status, 403);
  const telemetryHistory = await fetch(`${api}/telemetry?homeId=my-home&channel=energy_meter&sourceId=meter.main&limit=10`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  const history = await telemetryHistory.json();
  assert.equal(telemetryHistory.status, 200);
  assert.equal(history.available, true);
  assert.equal(history.count, 1);
  assert.equal(history.readings[0].sourceId, 'meter.main');
  const billingHeaders = { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' };
  const initialBillingSettings = await fetch(`${api}/billing/settings?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal((await initialBillingSettings.json()).settings, null);
  const unconfiguredEstimate = await fetch(`${api}/billing/estimate?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.deepEqual(await unconfiguredEstimate.json(), {
    available: false, reason: 'tariff_not_configured', settings: null, estimate: null,
  });
  const crossHomeBilling = await fetch(`${api}/billing/settings?homeId=other-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal(crossHomeBilling.status, 403);
  const invalidBillingSettings = await fetch(`${api}/billing/settings`, {
    method: 'PUT',
    headers: billingHeaders,
    body: JSON.stringify({
      homeId: 'my-home', gridSourceId: 'meter.main',
      tariffPerKWh: -1, exportTariffPerKWh: 2, fixedCharges: 120, additionalCharges: 15,
    }),
  });
  assert.equal(invalidBillingSettings.status, 400);
  const savedBillingSettings = await fetch(`${api}/billing/settings`, {
    method: 'PUT',
    headers: billingHeaders,
    body: JSON.stringify({
      homeId: 'my-home', gridSourceId: 'meter.main',
      tariffPerKWh: 8.5, exportTariffPerKWh: 2, fixedCharges: 120, additionalCharges: 15,
    }),
  });
  assert.equal(savedBillingSettings.status, 200);
  const savedBilling = (await savedBillingSettings.json()).settings;
  assert.equal(savedBilling.homeId, 'my-home');
  assert.equal(savedBilling.gridSourceId, 'meter.main');
  assert.equal(savedBilling.tariffPerKWh, 8.5);
  assert.equal(savedBilling.exportTariffPerKWh, 2);
  assert.equal(savedBilling.fixedCharges, 120);
  assert.equal(savedBilling.additionalCharges, 15);
  assert.equal(typeof savedBilling.updatedAt, 'string');
  const nowForBilling = new Date();
  const previousMonthReading = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({
      homeId: 'my-home', sourceId: 'meter.main', channel: 'grid',
      measuredAt: new Date(Date.UTC(nowForBilling.getUTCFullYear(), nowForBilling.getUTCMonth(), 0, 23, 59, 59, 999)).toISOString(),
      values: { importMonthWh: 99999, exportMonthWh: 9999 },
    }),
  });
  assert.equal(previousMonthReading.status, 201);
  const waitingForGrid = await fetch(`${api}/billing/estimate?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal((await waitingForGrid.json()).reason, 'monthly_grid_import_unavailable');
  const gridMeasuredAt = new Date().toISOString();
  const importOnlyGrid = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({
      homeId: 'my-home', sourceId: 'meter.main', channel: 'grid', measuredAt: gridMeasuredAt,
      values: { importMonthWh: 25000 },
    }),
  });
  assert.equal(importOnlyGrid.status, 201);
  const waitingForExport = await fetch(`${api}/billing/estimate?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal((await waitingForExport.json()).reason, 'monthly_grid_export_unavailable');
  const measuredGrid = await fetch(`${api}/telemetry`, {
    method: 'POST',
    headers: telemetryHeaders,
    body: JSON.stringify({
      homeId: 'my-home', sourceId: 'meter.main', channel: 'grid', measuredAt: new Date(Date.now() + 1).toISOString(),
      values: { importMonthWh: 25000, exportMonthWh: 3000 },
    }),
  });
  assert.equal(measuredGrid.status, 201);
  const calculatedEstimateResponse = await fetch(`${api}/billing/estimate?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  const calculatedEstimate = await calculatedEstimateResponse.json();
  assert.equal(calculatedEstimateResponse.status, 200);
  assert.equal(calculatedEstimate.available, true);
  assert.equal(calculatedEstimate.estimate.importKWh, 25);
  assert.equal(calculatedEstimate.estimate.exportKWh, 3);
  assert.equal(calculatedEstimate.estimate.importCost, 212.5);
  assert.equal(calculatedEstimate.estimate.exportCredit, 6);
  assert.equal(calculatedEstimate.estimate.total, 341.5);
  const browserCannotSetBilling = await fetch(`${api}/billing/settings`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${tokenB}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      homeId: 'my-home', gridSourceId: 'meter.main',
      tariffPerKWh: 8.5, exportTariffPerKWh: 0, fixedCharges: 0, additionalCharges: 0,
    }),
  });
  assert.equal(browserCannotSetBilling.status, 403);
  const privateTelemetry = await fetch(`${api}/telemetry?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenB}` },
  });
  assert.equal(privateTelemetry.status, 403);

  const denied = await fetch(`${api}/integrations?homeId=other-home`, {
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal(denied.status, 403);

  const badHost = await fetch(`${api}/integrations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'home_assistant', name: 'Remote', homeId: 'my-home',
      connection: { url: 'https://not-allowlisted.example', token: 'home-assistant-secret' },
    }),
  });
  assert.equal(badHost.status, 400);
  const unsupportedProtocol = await fetch(`${api}/integrations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'matter', name: 'Matter', homeId: 'my-home',
      connection: { url: 'https://not-allowlisted.example' },
    }),
  });
  assert.equal(unsupportedProtocol.status, 400);

  const create = await fetch(`${api}/integrations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'home_assistant', name: 'My Home Assistant', homeId: 'my-home',
      connection: { url: 'http://127.0.0.1:8123', token: 'home-assistant-secret' },
    }),
  });
  assert.equal(create.status, 201);
  const { integration } = await create.json();
  assert.equal(integration.status, 'not_tested');
  assert.equal(JSON.stringify(integration).includes('home-assistant-secret'), false);
  assert.equal(database.getIntegration(integration.id, 'alice', 'my-home').credentials.includes('home-assistant-secret'), false);

  const tested = await fetch(`${api}/integrations/${integration.id}/test?homeId=my-home`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal(tested.status, 200);
  assert.equal((await tested.json()).integration.status, 'connected');

  const discovered = await fetch(`${api}/integrations/${integration.id}/discover?homeId=my-home`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ homeId: 'my-home' }),
  });
  assert.equal(discovered.status, 200);
  const { discovered: devices, count } = await discovered.json();
  assert.equal(count, 1);
  assert.deepEqual(devices[0].capabilities, ['power']);

  const unsupported = await fetch(`${api}/devices/${devices[0].id}/commands?homeId=my-home`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'brightness', value: 80 }),
  });
  assert.equal(unsupported.status, 422);

  const command = await fetch(`${api}/devices/${devices[0].id}/commands?homeId=my-home`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'power', value: true }),
  });
  assert.equal(command.status, 200);
  assert.equal((await command.json()).device.state.power, true);
  const roomChange = await fetch(`${api}/devices/${devices[0].id}?homeId=my-home`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${tokenA}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ roomId: 'my-home-living-room' }),
  });
  assert.equal(roomChange.status, 200);
  assert.equal((await roomChange.json()).device.roomId, 'my-home-living-room');

  const crossUser = await fetch(`${api}/devices?homeId=my-home`, {
    headers: { Authorization: `Bearer ${tokenB}` },
  });
  assert.equal(crossUser.status, 403);

  const removed = await fetch(`${api}/integrations/${integration.id}?homeId=my-home`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${tokenA}` },
  });
  assert.equal(removed.status, 200);
  assert.deepEqual(database.listDevices('alice', 'my-home'), []);
});

test('authentication rejects duplicate bearer tokens and enforces exact home scope', () => {
  assert.throws(() => createAuthenticator([
    { id: 'one', token: tokenA, homes: ['my-home'] },
    { id: 'two', token: tokenA, homes: ['other-home'] },
  ]), /unique access token/);
  assert.throws(() => requireHome({ homes: new Set(['my-home']) }, 'My-Home'), { status: 403 });
});

test('credential vault authenticates encrypted records and detects tampering', () => {
  const encrypted = vault.seal({ password: 'private-broker-password' });
  assert.equal(encrypted.includes('private-broker-password'), false);
  assert.deepEqual(vault.open(encrypted), { password: 'private-broker-password' });
  const envelope = JSON.parse(encrypted);
  envelope.ciphertext = Buffer.alloc(Buffer.from(envelope.ciphertext, 'base64').length, 1).toString('base64');
  assert.throws(() => vault.open(JSON.stringify(envelope)));
  assert.throws(() => createVault('invalid-key'), /32 random bytes/);
});

class FakeWebSocket {
  constructor(url) {
    this.url = url;
    this.listeners = new Map();
    this.power = false;
    setTimeout(() => this.emit('message', { data: JSON.stringify({ type: 'auth_required' }) }), 0);
  }

  addEventListener(type, listener) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(listener);
  }

  emit(type, event) {
    for (const listener of this.listeners.get(type) || []) listener(event);
  }

  send(serialized) {
    const request = JSON.parse(serialized);
    if (request.type === 'auth') {
      setTimeout(() => this.emit('message', { data: JSON.stringify({ type: 'auth_ok' }) }), 0);
      return;
    }
    if (request.type === 'call_service') this.power = request.service === 'turn_on';
    const result = request.type === 'get_config' ? { location_name: 'Test Home' }
      : request.type === 'get_states' ? [{
        entity_id: 'light.living_room',
        state: this.power ? 'on' : 'off',
        attributes: { friendly_name: 'Living room light' },
        last_updated: new Date().toISOString(),
      }]
        : null;
    setTimeout(() => this.emit('message', {
      data: JSON.stringify({ id: request.id, type: 'result', success: true, result }),
    }), 0);
  }

  close() {
    this.emit('close', {});
  }
}

test('Home Assistant adapter authenticates REST and WebSocket and verifies entity state', async () => {
  let power = false;
  const fetchCalls = [];
  const fetchImpl = async (url, options) => {
    fetchCalls.push({ url: String(url), authorization: options.headers.Authorization });
    if (String(url).endsWith('/api/')) return Response.json({ message: 'API running.' });
    return Response.json({
      entity_id: 'light.living_room',
      state: power ? 'on' : 'off',
      attributes: { friendly_name: 'Living room light' },
      last_updated: new Date().toISOString(),
    });
  };
  class HomeAssistantSocket extends FakeWebSocket {
    send(serialized) {
      const request = JSON.parse(serialized);
      if (request.type === 'call_service') power = request.service === 'turn_on';
      super.send(serialized);
    }
  }
  const adapter = new HomeAssistantAdapter(fetchImpl, HomeAssistantSocket);
  const integration = { id: 'integration-id', owner_id: 'alice', home_id: 'my-home' };
  const credentials = { baseUrl: 'https://homeassistant.example', token: 'confidential-token' };
  const status = await adapter.test(integration, credentials);
  assert.match(status.message, /REST and WebSocket/);
  const discovered = await adapter.discover(integration, credentials);
  assert.equal(discovered[0].sourceId, 'light.living_room');
  assert.deepEqual(discovered[0].capabilities, ['power']);
  const verified = await adapter.execute(integration, {
    id: 'device-id', sourceId: 'light.living_room', capabilities: ['power'],
  }, { action: 'power', value: true }, credentials);
  assert.equal(verified.state.power, true);
  assert.ok(fetchCalls.every((call) => call.authorization === 'Bearer confidential-token'));
});

class FakeMqttClient extends EventEmitter {
  constructor() {
    super();
    this.config = {
      unique_id: 'test.light',
      name: 'Test MQTT light',
      command_topic: 'test/light/set',
      state_topic: 'test/light/state',
      payload_on: 'ON',
      payload_off: 'OFF',
      state_on: 'ON',
      state_off: 'OFF',
      device: { manufacturer: 'Test', model: 'Relay' },
    };
    setTimeout(() => this.emit('connect'), 0);
  }

  subscribe(topic, options, callback) {
    if (callback) callback(null);
    if (topic.endsWith('/config')) {
      setTimeout(() => this.emit('message', 'homeassistant/light/test/config', Buffer.from(JSON.stringify(this.config))), 0);
    } else if (topic === 'test/light/state') {
      setTimeout(() => this.emit('message', topic, Buffer.from('OFF')), 0);
    }
  }

  publish(topic, payload, options, callback) {
    callback(null);
    setTimeout(() => this.emit('message', 'test/light/state', Buffer.from(payload)), 0);
  }

  end() {
    this.emit('close');
  }
}

test('MQTT import and commands require matching reported state', async (t) => {
  const mqttDatabase = createDatabase(join(temporaryDirectory, 'mqtt.sqlite'));
  const record = mqttDatabase.saveIntegration({
    ownerId: 'alice', homeId: 'my-home', protocol: 'mqtt',
    name: 'Broker', credentials: 'encrypted',
  });
  const integration = mqttDatabase.getIntegration(record.id, 'alice', 'my-home');
  const adapter = new MqttAdapter({
    mqtt: { connect: () => new FakeMqttClient() },
    database: mqttDatabase,
    stateTimeoutMs: 500,
  });
  t.after(() => {
    adapter.close(integration.id);
    mqttDatabase.close();
    rmSync(temporaryDirectory, { recursive: true, force: true });
  });

  const credentials = { url: 'mqtts://broker.example', topicPrefix: 'homeassistant' };
  const devices = await adapter.discover(integration, credentials);
  assert.equal(devices.length, 1);
  assert.deepEqual(devices[0].capabilities, ['power']);
  const verified = await adapter.execute(integration, devices[0], { action: 'power', value: true }, credentials);
  assert.equal(verified.state.power, true);
});
