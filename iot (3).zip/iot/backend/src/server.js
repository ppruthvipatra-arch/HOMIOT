import { createServer } from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { resolve, relative, isAbsolute, extname, sep } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { isIP } from 'node:net';
import mqtt from 'mqtt';
import { createAuthenticator, requireHome } from './auth.js';
import { createVault } from './cryptoVault.js';
import { createDatabase } from './database.js';
import { createAdapterRegistry } from './adapters/registry.js';
import { HttpError, publicError } from './errors.js';

const backendDirectory = resolve(fileURLToPath(new URL('..', import.meta.url)));
const projectDirectory = resolve(backendDirectory, '..');
const allowedStaticExtensions = new Set([
  '.html', '.css', '.js', '.json', '.webmanifest', '.svg', '.png', '.jpg', '.jpeg',
  '.webp', '.ico', '.woff', '.woff2', '.ttf', '.map',
]);
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json; charset=utf-8',
};

function parseUsers(value) {
  let users;
  try {
    users = JSON.parse(value || '[]');
  } catch {
    throw new Error('HOMIOT_API_USERS_JSON must be a JSON array.');
  }
  if (!Array.isArray(users) || users.length === 0) {
    throw new Error('Configure at least one HOMIOT API user with an explicit home allowlist.');
  }
  const ids = new Set();
  for (const user of users) {
    if (!user || typeof user.id !== 'string' || !/^[A-Za-z0-9._-]{1,80}$/.test(user.id)
      || typeof user.token !== 'string' || user.token.length < 32 || user.token.length > 512
      || !Array.isArray(user.homes) || user.homes.length === 0
      || user.homes.some((home) => typeof home !== 'string' || !home.trim() || home.length > 100)
      || ids.has(user.id)) {
      throw new Error('Each API user needs a unique ID, a high-entropy token, and an explicit home allowlist.');
    }
    ids.add(user.id);
  }
  return users;
}

function parseTelemetryProducers(value, apiUsers) {
  let producers;
  try {
    producers = JSON.parse(value || '[]');
  } catch {
    throw new Error('HOMIOT_TELEMETRY_PRODUCERS_JSON must be a JSON array.');
  }
  if (!Array.isArray(producers)) throw new Error('HOMIOT_TELEMETRY_PRODUCERS_JSON must be a JSON array.');
  const ids = new Set();
  return producers.map((producer) => {
    if (!producer || typeof producer.id !== 'string' || !/^[A-Za-z0-9._-]{1,80}$/.test(producer.id)
      || typeof producer.token !== 'string' || producer.token.length < 32 || producer.token.length > 512
      || typeof producer.ownerId !== 'string' || !/^[A-Za-z0-9._-]{1,80}$/.test(producer.ownerId)
      || typeof producer.homeId !== 'string' || !producer.homeId.trim() || producer.homeId.length > 100
      || typeof producer.sourceId !== 'string' || !producer.sourceId.trim() || producer.sourceId.length > 160
      || /[\u0000-\u001f\u007f]/.test(producer.sourceId) || ids.has(producer.id)) {
      throw new Error('Each telemetry producer needs a unique ID, high-entropy token, authorized home, and exact source ID.');
    }
    const owner = apiUsers.find((user) => user.id === producer.ownerId);
    if (!owner || !owner.homes.includes(producer.homeId)) {
      throw new Error('Each telemetry producer must map to a configured API user and one of that user’s authorized homes.');
    }
    ids.add(producer.id);
    return {
      id: producer.id,
      ownerId: producer.ownerId,
      token: producer.token,
      homes: [producer.homeId],
      sourceIds: [producer.sourceId],
    };
  });
}

function parseList(value) {
  return new Set(String(value || '').split(',').map((item) => item.trim().toLowerCase()).filter(Boolean));
}

function isSameOriginRequest(request, origin) {
  if (!origin || !request.headers.host) return false;
  try {
    const parsedOrigin = new URL(origin);
    const scheme = request.socket.encrypted ? 'https:' : 'http:';
    const requestOrigin = new URL(`${scheme}//${request.headers.host}`);
    return parsedOrigin.origin === requestOrigin.origin;
  } catch {
    return false;
  }
}

function isPrivateHost(hostname) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost')) return true;
  const family = isIP(host);
  if (family === 4) {
    const [a, b] = host.split('.').map(Number);
    return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 168) || (a === 169 && b === 254);
  }
  if (family === 6) return host === '::1' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80:');
  return host.endsWith('.local');
}

function validateIntegrationUrl(value, protocol, configuration) {
  if (typeof value !== 'string' || value.length > 2048) throw new HttpError(400, 'Enter a valid integration server URL.');
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new HttpError(400, 'Enter a valid integration server URL.');
  }
  if (url.username || url.password || url.search || url.hash) throw new HttpError(400, 'Do not put credentials, query parameters, or fragments in the integration URL.');
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const explicitlyAllowed = configuration.allowedHosts.has(host);
  const localAllowed = configuration.allowInsecureLocal && isPrivateHost(host);
  if (!explicitlyAllowed && !localAllowed) throw new HttpError(400, 'This integration host is not allowlisted. Add its exact hostname to HOMIOT_ALLOWED_INTEGRATION_HOSTS.');

  if (protocol === 'mqtt') {
    if (!['mqtts:', 'mqtt:', 'wss:'].includes(url.protocol)) throw new HttpError(400, 'MQTT requires mqtts:// or wss://. mqtt:// is allowed only for a trusted private network.');
    if (url.protocol === 'mqtt:' && (!configuration.allowInsecureLocal || !isPrivateHost(host))) {
      throw new HttpError(400, 'Unencrypted MQTT is restricted to explicitly enabled private-network hosts.');
    }
  } else {
    if (!['https:', 'http:'].includes(url.protocol)) throw new HttpError(400, 'Home Assistant requires HTTPS; HTTP is allowed only for an explicitly enabled private-network host.');
    if (url.protocol === 'http:' && (!configuration.allowInsecureLocal || !isPrivateHost(host))) {
      throw new HttpError(400, 'Unencrypted Home Assistant HTTP is restricted to explicitly enabled private-network hosts.');
    }
  }
  return url;
}

function validateIntegrationBody(body, user, configuration) {
  const protocol = body.protocol;
  if (!['mqtt', 'home_assistant'].includes(protocol)) throw new HttpError(400, 'Phase one supports MQTT and Home Assistant integrations.');
  const homeId = requireHome(user, body.homeId);
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name || name.length > 80) throw new HttpError(400, 'Integration names must be 1–80 characters.');
  const connection = body.connection;
  if (!connection || typeof connection !== 'object' || Array.isArray(connection)) throw new HttpError(400, 'Integration connection settings are required.');

  if (protocol === 'mqtt') {
    const url = validateIntegrationUrl(connection.url, protocol, configuration);
    if (connection.username !== undefined && (typeof connection.username !== 'string' || connection.username.length > 160)) {
      throw new HttpError(400, 'MQTT username is invalid.');
    }
    if (connection.password !== undefined && (typeof connection.password !== 'string' || connection.password.length > 512)) {
      throw new HttpError(400, 'MQTT password is invalid.');
    }
    const topicPrefix = connection.topicPrefix === undefined ? 'homeassistant' : connection.topicPrefix;
    if (typeof topicPrefix !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(topicPrefix)) {
      throw new HttpError(400, 'MQTT discovery prefix must contain 1–80 letters, digits, underscores, or hyphens.');
    }
    return {
      protocol, homeId, name,
      credentials: {
        url: url.toString(),
        username: connection.username || '',
        password: connection.password || '',
        topicPrefix,
      },
    };
  }

  const url = validateIntegrationUrl(connection.url, protocol, configuration);
  const token = connection.token;
  if (typeof token !== 'string' || token.length < 20 || token.length > 512) {
    throw new HttpError(400, 'Enter a valid Home Assistant long-lived access token.');
  }
  return { protocol, homeId, name, credentials: { baseUrl: url.toString().replace(/\/+$/, ''), token } };
}

const telemetryMetrics = {
  energy_meter: { numeric: ['powerW', 'voltageV', 'currentA', 'powerFactor', 'energyTodayWh', 'energyTotalWh'] },
  solar: { numeric: ['powerW', 'voltageV', 'currentA', 'energyTodayWh', 'energyMonthWh', 'energyYearWh'] },
  battery: {
    numeric: ['voltageV', 'currentA', 'stateOfChargePercent', 'temperatureC', 'chargePowerW', 'dischargePowerW'],
    boolean: ['charging', 'discharging'],
    string: ['status'],
  },
  grid: {
    numeric: ['voltageV', 'currentA', 'powerW', 'importTodayWh', 'exportTodayWh', 'importMonthWh', 'exportMonthWh'],
    boolean: ['available'],
  },
  inverter: {
    numeric: ['pvInputW', 'batteryInputW', 'batteryOutputW', 'gridInputW', 'gridOutputW', 'acOutputW', 'loadPowerW'],
    string: ['status', 'operatingMode'],
    stringArray: ['faults'],
  },
  home_load: { numeric: ['powerW', 'energyTodayWh'] },
};

function telemetryTimestamp(value, field) {
  const match = typeof value === 'string'
    ? value.match(/^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,9}))?Z$/)
    : null;
  if (!match || value.length > 30) {
    throw new HttpError(400, `${field} must be an ISO 8601 UTC timestamp.`);
  }
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) throw new HttpError(400, `${field} is not a valid timestamp.`);
  const expected = new Date(timestamp).toISOString();
  const normalized = `${match[1]}.${(match[2] || '').slice(0, 3).padEnd(3, '0')}Z`;
  if (expected !== normalized) throw new HttpError(400, `${field} is not a valid calendar timestamp.`);
  if (timestamp > Date.now() + 5 * 60 * 1000) throw new HttpError(400, `${field} cannot be more than five minutes in the future.`);
  return new Date(timestamp).toISOString();
}

function validateTelemetryBody(body, user, homeId) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new HttpError(400, 'Telemetry request body must be an object.');
  }
  const allowedFields = new Set(['homeId', 'channel', 'sourceId', 'measuredAt', 'values']);
  if (Object.keys(body).some((key) => !allowedFields.has(key))) {
    throw new HttpError(400, 'Telemetry contains unsupported fields.');
  }
  const channel = body.channel;
  const metricSet = telemetryMetrics[channel];
  if (!metricSet) throw new HttpError(400, 'Choose a supported telemetry channel.');
  const sourceId = typeof body.sourceId === 'string' ? body.sourceId.trim() : '';
  if (!sourceId || sourceId.length > 160 || /[\u0000-\u001f\u007f]/.test(sourceId)) {
    throw new HttpError(400, 'Telemetry sourceId must contain 1–160 printable characters.');
  }
  const measuredAt = telemetryTimestamp(body.measuredAt, 'measuredAt');
  const values = body.values;
  if (!values || typeof values !== 'object' || Array.isArray(values)) {
    throw new HttpError(400, 'Telemetry values must be a non-empty object.');
  }
  const numeric = new Set(metricSet.numeric || []);
  const boolean = new Set(metricSet.boolean || []);
  const strings = new Set(metricSet.string || []);
  const stringArrays = new Set(metricSet.stringArray || []);
  const entries = Object.entries(values);
  if (!entries.length || entries.length > 32) throw new HttpError(400, 'Provide between 1 and 32 telemetry values.');
  for (const [key, value] of entries) {
    if (numeric.has(key)) {
      if (typeof value !== 'number' || !Number.isFinite(value)) throw new HttpError(400, `${key} must be a finite numeric reading.`);
    } else if (boolean.has(key)) {
      if (typeof value !== 'boolean') throw new HttpError(400, `${key} must be a boolean reading.`);
    } else if (strings.has(key)) {
      if (typeof value !== 'string' || !value.trim() || value.length > 120 || /[\u0000-\u001f\u007f]/.test(value)) {
        throw new HttpError(400, `${key} must be a non-empty string of at most 120 characters.`);
      }
    } else if (stringArrays.has(key)) {
      if (!Array.isArray(value) || value.length > 20 || value.some((item) => typeof item !== 'string'
        || !item.trim() || item.length > 80 || /[\u0000-\u001f\u007f]/.test(item))) {
        throw new HttpError(400, `${key} must be an array of at most 20 short strings.`);
      }
    } else {
      throw new HttpError(400, `${key} is not a supported measurement for the ${channel} channel.`);
    }
  }
  return { ownerId: user.id, homeId, sourceId, channel, measuredAt, values };
}

function validateTelemetryQuery(url) {
  const channel = url.searchParams.get('channel') || '';
  if (channel && !Object.hasOwn(telemetryMetrics, channel)) throw new HttpError(400, 'Choose a supported telemetry channel.');
  const sourceId = url.searchParams.get('sourceId') || '';
  if (sourceId && (sourceId.length > 160 || /[\u0000-\u001f\u007f]/.test(sourceId))) {
    throw new HttpError(400, 'Telemetry sourceId must contain at most 160 printable characters.');
  }
  const since = url.searchParams.has('since') ? telemetryTimestamp(url.searchParams.get('since'), 'since') : '';
  const until = url.searchParams.has('until') ? telemetryTimestamp(url.searchParams.get('until'), 'until') : '';
  if (since && until && since > until) throw new HttpError(400, 'since must be earlier than or equal to until.');
  const rawLimit = url.searchParams.get('limit');
  const limit = rawLimit === null ? 100 : Number(rawLimit);
  if (!Number.isInteger(limit) || limit < 1 || limit > 500) throw new HttpError(400, 'limit must be an integer from 1 to 500.');
  return { channel, sourceId, since, until, limit };
}

function validateBillingSettings(body, ownerId, homeId) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new HttpError(400, 'Billing settings must be an object.');
  }
  const allowedFields = new Set([
    'homeId', 'gridSourceId', 'tariffPerKWh', 'exportTariffPerKWh', 'fixedCharges', 'additionalCharges',
  ]);
  if (Object.keys(body).some((key) => !allowedFields.has(key))) {
    throw new HttpError(400, 'Billing settings contain unsupported fields.');
  }
  const ranges = {
    tariffPerKWh: 100000,
    exportTariffPerKWh: 100000,
    fixedCharges: 1000000,
    additionalCharges: 1000000,
  };
  const gridSourceId = typeof body.gridSourceId === 'string' ? body.gridSourceId.trim() : '';
  if (!gridSourceId || gridSourceId.length > 160 || /[\u0000-\u001f\u007f]/.test(gridSourceId)) {
    throw new HttpError(400, 'gridSourceId must contain 1–160 printable characters.');
  }
  const settings = { ownerId, homeId, gridSourceId };
  for (const [field, maximum] of Object.entries(ranges)) {
    const value = body[field];
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > maximum) {
      throw new HttpError(400, `${field} must be a finite number from 0 to ${maximum}.`);
    }
    settings[field] = value;
  }
  return settings;
}

function cleanText(value, maxLength = 100) {
  return String(value || '').trim().slice(0, maxLength);
}

function safeIntegration(integration) {
  return {
    id: integration.id,
    homeId: integration.home_id || integration.homeId,
    protocol: integration.protocol,
    name: integration.name,
    status: integration.status,
    lastError: integration.last_error || integration.lastError || null,
    createdAt: integration.created_at || integration.createdAt,
  };
}

function readBody(request) {
  return new Promise((resolveBody, reject) => {
    let size = 0;
    const chunks = [];
    request.on('data', (chunk) => {
      size += chunk.length;
      if (size > 65536) {
        reject(new HttpError(413, 'Request body exceeds 64 KB.'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (!chunks.length) return resolveBody({});
      try {
        resolveBody(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Request body must be valid JSON.'));
      }
    });
    request.on('error', () => reject(new HttpError(400, 'Request body could not be read.')));
  });
}

function validateDeviceCommand(device, body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)
    || Object.keys(body).some((key) => !['action', 'value'].includes(key))) {
    throw new HttpError(400, 'Provide only an action and its value.');
  }
  const command = { action: body.action, value: body.value };
  const capability = {
    power: 'power',
    brightness: 'brightness',
    fan_speed: 'fan_speed',
    temperature: 'temperature',
    lock: 'lock',
  }[command.action];
  if (!capability || !device.capabilities.includes(capability)) {
    throw new HttpError(422, 'The selected device does not advertise that control capability.');
  }
  if (command.action === 'power' && typeof command.value !== 'boolean') throw new HttpError(400, 'Power value must be true or false.');
  if (command.action === 'brightness' && (!Number.isInteger(command.value) || command.value < 0 || command.value > 100)) {
    throw new HttpError(400, 'Brightness must be an integer from 0 to 100.');
  }
  if (command.action === 'fan_speed' && (!Number.isInteger(command.value) || command.value < 0 || command.value > 100)) {
    throw new HttpError(400, 'Fan speed must be an integer from 0 to 100 percent.');
  }
  if (command.action === 'temperature' && (!Number.isFinite(command.value) || command.value < -50 || command.value > 100)) {
    throw new HttpError(400, 'Temperature must be a finite value within the supported safety range.');
  }
  if (command.action === 'lock' && !['lock', 'unlock'].includes(command.value)) throw new HttpError(400, 'Lock action must be lock or unlock.');
  return command;
}

function createRateLimiter() {
  const requests = new Map();
  return function allow(ip) {
    const now = Date.now();
    const window = requests.get(ip) || { start: now, count: 0 };
    if (now - window.start > 60_000) {
      window.start = now;
      window.count = 0;
    }
    window.count += 1;
    requests.set(ip, window);
    if (requests.size > 2000) {
      for (const [key, value] of requests) if (now - value.start > 60_000) requests.delete(key);
    }
    return window.count <= 120;
  };
}

function createHttpApplication({ configuration, database, vault, authenticate, authenticateTelemetry, adapters }) {
  const rateLimit = createRateLimiter();
  const mqttAdapter = adapters.get('mqtt');

  function sendJson(response, status, value, corsOrigin = null) {
    response.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      ...(corsOrigin ? { 'Access-Control-Allow-Origin': corsOrigin, Vary: 'Origin' } : {}),
    });
    response.end(JSON.stringify(value));
  }

  function integrationFor(id, user, homeId) {
    const integration = database.getIntegration(id, user.id, homeId);
    if (!integration) throw new HttpError(404, 'Integration was not found in this authorized home.');
    return integration;
  }

  async function handleApi(request, response, url, corsOrigin) {
    if (!rateLimit(request.socket.remoteAddress || 'unknown')) {
      sendJson(response, 429, { error: 'Rate limit exceeded; retry shortly.' }, corsOrigin);
      return;
    }
    const pathname = url.pathname.slice('/api/v1'.length) || '/';
    const telemetryWrite = request.method === 'POST' && pathname === '/telemetry';
    const user = (telemetryWrite ? authenticateTelemetry : authenticate)(request);
    if (telemetryWrite && !user.sourceIds) throw new HttpError(403, 'A telemetry producer credential is required to submit measurements.');
    if (!telemetryWrite && user.sourceIds) throw new HttpError(403, 'Telemetry producer credentials cannot access user API routes.');
    const queryHome = url.searchParams.get('homeId');
    const body = ['POST', 'PATCH', 'PUT'].includes(request.method) ? await readBody(request) : {};

    if (request.method === 'GET' && pathname === '/session') {
      sendJson(response, 200, { user: { id: user.id }, homes: [...user.homes] }, corsOrigin);
      return;
    }
    if (request.method === 'GET' && pathname === '/billing/settings') {
      const homeId = requireHome(user, queryHome);
      sendJson(response, 200, { settings: database.getBillingSettings(user.ownerId, homeId) }, corsOrigin);
      return;
    }
    if (request.method === 'GET' && pathname === '/billing/estimate') {
      const homeId = requireHome(user, queryHome);
      const settings = database.getBillingSettings(user.ownerId, homeId);
      if (!settings) {
        sendJson(response, 200, { available: false, reason: 'tariff_not_configured', settings: null, estimate: null }, corsOrigin);
        return;
      }
      const currentDate = new Date();
      const monthStart = new Date(Date.UTC(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), 1)).toISOString();
      const [gridReading] = database.listTelemetryReadings({
        ownerId: user.ownerId,
        homeId,
        channel: 'grid',
        sourceId: settings.gridSourceId,
        since: monthStart,
        until: '',
        limit: 1,
      });
      if (typeof gridReading?.values.importMonthWh !== 'number') {
        sendJson(response, 200, {
          available: false, reason: 'monthly_grid_import_unavailable', settings, estimate: null,
        }, corsOrigin);
        return;
      }
      const exportWh = gridReading.values.exportMonthWh;
      if (settings.exportTariffPerKWh > 0 && typeof exportWh !== 'number') {
        sendJson(response, 200, {
          available: false, reason: 'monthly_grid_export_unavailable', settings, estimate: null,
        }, corsOrigin);
        return;
      }
      const importKWh = gridReading.values.importMonthWh / 1000;
      const exportKWh = typeof exportWh === 'number' ? exportWh / 1000 : null;
      const importCost = importKWh * settings.tariffPerKWh;
      const exportCredit = exportKWh === null ? 0 : exportKWh * settings.exportTariffPerKWh;
      const estimate = {
        sourceId: gridReading.sourceId,
        measuredAt: gridReading.measuredAt,
        importKWh,
        exportKWh,
        importCost,
        exportCredit,
        fixedCharges: settings.fixedCharges,
        additionalCharges: settings.additionalCharges,
        total: importCost + settings.fixedCharges + settings.additionalCharges - exportCredit,
      };
      sendJson(response, 200, { available: true, settings, estimate }, corsOrigin);
      return;
    }
    if (request.method === 'PUT' && pathname === '/billing/settings') {
      if (queryHome && body?.homeId && queryHome !== body.homeId) {
        throw new HttpError(400, 'The homeId query and request body must match.');
      }
      const homeId = requireHome(user, queryHome || body?.homeId);
      const input = validateBillingSettings(body, user.ownerId, homeId);
      const settings = database.saveBillingSettings(input);
      sendJson(response, 200, { settings }, corsOrigin);
      return;
    }
    if (request.method === 'GET' && pathname === '/telemetry') {
      const homeId = requireHome(user, queryHome);
      const filters = validateTelemetryQuery(url);
      const readings = database.listTelemetryReadings({ ownerId: user.id, homeId, ...filters });
      sendJson(response, 200, { available: readings.length > 0, count: readings.length, readings }, corsOrigin);
      return;
    }
    if (request.method === 'POST' && pathname === '/telemetry') {
      if (queryHome && body?.homeId && queryHome !== body.homeId) {
        throw new HttpError(400, 'The homeId query and request body must match.');
      }
      const homeId = requireHome(user, queryHome || body?.homeId);
      const input = { ...validateTelemetryBody(body, user, homeId), ownerId: user.ownerId };
      if (!user.sourceIds.has(input.sourceId)) {
        throw new HttpError(403, 'This telemetry credential is not authorized for the submitted sourceId.');
      }
      const result = database.saveTelemetryReading(input);
      if (result.conflict) {
        throw new HttpError(409, 'A reading already exists for this source, channel, and timestamp with different values.');
      }
      sendJson(response, result.created ? 201 : 200, {
        reading: result.reading,
        duplicate: !result.created,
      }, corsOrigin);
      return;
    }
    if (request.method === 'GET' && pathname === '/integrations') {
      const homeId = requireHome(user, queryHome);
      sendJson(response, 200, { integrations: database.listIntegrations(user.id, homeId) }, corsOrigin);
      return;
    }
    if (request.method === 'POST' && pathname === '/integrations') {
      const input = validateIntegrationBody(body, user, configuration);
      const integration = database.saveIntegration({
        ownerId: user.id, homeId: input.homeId, protocol: input.protocol,
        name: input.name, credentials: vault.seal(input.credentials),
      });
      sendJson(response, 201, { integration: safeIntegration(integration), connection: 'not_tested' }, corsOrigin);
      return;
    }

    const integrationMatch = pathname.match(/^\/integrations\/([0-9a-f-]{36})(?:\/(test|discover))?$/i);
    if (integrationMatch) {
      const [, id, action] = integrationMatch;
      const homeId = queryHome || body.homeId;
      requireHome(user, homeId);
      const integration = integrationFor(id, user, homeId);
      if (request.method === 'DELETE' && !action) {
        mqttAdapter.close(integration.id);
        database.deleteIntegration(id, user.id, homeId);
        sendJson(response, 200, { removed: true }, corsOrigin);
        return;
      }
      if (request.method !== 'POST' || !['test', 'discover'].includes(action)) {
        throw new HttpError(405, 'Method is not allowed for this integration.');
      }
      const adapter = adapters.get(integration.protocol);
      const credentials = vault.open(integration.credentials);
      try {
        if (action === 'test') {
          const result = await adapter.test(integration, credentials);
          database.setIntegrationStatus(integration.id, 'connected');
          const updatedIntegration = database.getIntegration(integration.id, user.id, homeId);
          sendJson(response, 200, { integration: safeIntegration(updatedIntegration), result }, corsOrigin);
          return;
        }
        const discovered = await adapter.discover(integration, credentials);
        let imported = [];
        if (integration.protocol === 'home_assistant') imported = discovered.map((device) => database.upsertDevice(device));
        else imported = database.listIntegrationDevices(integration.id, user.id, homeId);
        database.setIntegrationStatus(integration.id, 'connected');
        sendJson(response, 200, { discovered: imported, count: imported.length }, corsOrigin);
        return;
      } catch (error) {
        database.setIntegrationStatus(integration.id, 'error', 'Connection or discovery failed; see server logs for the safe error summary.');
        console.error(`${integration.protocol} ${action} failed for integration ${integration.id}:`, error instanceof Error ? error.message : 'unknown error');
        if (error instanceof HttpError) throw error;
        throw new HttpError(502, `${integration.protocol} ${action} failed. Check server logs for details.`);
      }
    }

    if (request.method === 'GET' && pathname === '/devices') {
      const homeId = requireHome(user, queryHome);
      sendJson(response, 200, { devices: database.listDevices(user.id, homeId) }, corsOrigin);
      return;
    }
    const deviceMatch = pathname.match(/^\/devices\/([0-9a-f-]{36})(?:\/(commands))?$/i);
    if (deviceMatch) {
      const [, id, action] = deviceMatch;
      const homeId = requireHome(user, queryHome || body.homeId);
      const device = database.getDevice(id, user.id, homeId);
      if (!device) throw new HttpError(404, 'Device was not found in this authorized home.');
      if (request.method === 'PATCH' && !action) {
        if (Object.keys(body).some((key) => !['roomId'].includes(key))
          || (body.roomId !== null && body.roomId !== undefined
            && (typeof body.roomId !== 'string' || body.roomId.length > 100))) {
          throw new HttpError(400, 'Only a valid roomId may be changed.');
        }
        database.updateRoom(id, user.id, homeId, body.roomId || null);
        sendJson(response, 200, { device: database.getDevice(id, user.id, homeId) }, corsOrigin);
        return;
      }
      if (request.method === 'POST' && action === 'commands') {
        const command = validateDeviceCommand(device, body);
        const integration = integrationFor(device.integrationId, user, homeId);
        const credentials = vault.open(integration.credentials);
        try {
          const adapter = adapters.get(integration.protocol);
          const verified = await adapter.execute(integration, device, command, credentials);
          const saved = database.upsertDevice({ ...verified, ownerId: user.id, homeId, integrationId: integration.id });
          sendJson(response, 200, { verified: true, device: saved }, corsOrigin);
        } catch (error) {
          if (error instanceof HttpError) throw error;
          console.error(`${integration.protocol} command failed for device ${device.id}:`, error instanceof Error ? error.message : 'unknown error');
          throw new HttpError(502, 'The command was not verified by the device adapter.');
        }
        return;
      }
    }

    throw new HttpError(404, 'Integration API route was not found.');
  }

  async function serveStatic(request, response, pathname) {
    if (!configuration.serveUi || !['GET', 'HEAD'].includes(request.method)) {
      response.writeHead(404);
      response.end();
      return;
    }
    let requested;
    try {
      requested = decodeURIComponent(pathname);
    } catch {
      response.writeHead(400);
      response.end();
      return;
    }
    if (requested === '/') requested = '/index.html';
    const filename = resolve(projectDirectory, `.${requested}`);
    const relativePath = relative(projectDirectory, filename);
    const pathParts = relativePath.split(sep);
    if (!relativePath || relativePath === '..' || relativePath.startsWith(`..${sep}`)
      || isAbsolute(relativePath) || pathParts.some((part) => part.toLowerCase() === 'backend')
      || requested.split('/').some((part) => part.startsWith('.'))) {
      response.writeHead(404);
      response.end();
      return;
    }
    const extension = extname(filename).toLowerCase();
    if (!allowedStaticExtensions.has(extension) || !existsSync(filename)) {
      response.writeHead(404);
      response.end();
      return;
    }
    response.writeHead(200, {
      'Content-Type': mimeTypes[extension] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      ...(extension === '.html' ? { 'Cache-Control': 'no-cache' } : { 'Cache-Control': 'public, max-age=3600' }),
    });
    if (request.method === 'HEAD') response.end();
    else createReadStream(filename).pipe(response);
  }

  return createServer(async (request, response) => {
    const origin = request.headers.origin;
    const corsOrigin = origin && (configuration.allowedOrigins.has(origin.toLowerCase())
      || isSameOriginRequest(request, origin)) ? origin : null;
    if (request.method === 'OPTIONS' && request.url?.startsWith('/api/')) {
      if (origin && !corsOrigin) {
        sendJson(response, 403, { error: 'This browser origin is not allowed.' });
        return;
      }
      response.writeHead(204, {
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        'Access-Control-Max-Age': '600',
        ...(corsOrigin ? { 'Access-Control-Allow-Origin': corsOrigin, Vary: 'Origin' } : {}),
      });
      response.end();
      return;
    }
    try {
      const url = new URL(request.url || '/', 'http://homiot.local');
      if (url.pathname === '/api/v1/health' && request.method === 'GET') {
        sendJson(response, 200, {
          service: 'HOMIOT integrations',
          phase: 1,
          adapters: [
            { protocol: 'mqtt', status: 'available' },
            { protocol: 'home_assistant', status: 'available' },
            { protocol: 'matter', status: 'planned_separate_phase' },
            { protocol: 'http_rest', status: 'not_implemented' },
            { protocol: 'websocket', status: 'not_implemented' },
            { protocol: 'zigbee_gateway', status: 'not_implemented' },
            { protocol: 'bluetooth_gateway', status: 'not_implemented' },
            { protocol: 'modbus', status: 'not_implemented' },
          ],
        });
        return;
      }
      if (url.pathname.startsWith('/api/v1/')) {
        if (origin && !corsOrigin) throw new HttpError(403, 'This browser origin is not allowed.');
        await handleApi(request, response, url, corsOrigin);
        return;
      }
      await serveStatic(request, response, url.pathname);
    } catch (error) {
      const result = publicError(error);
      if (result.status >= 500) console.error('HOMIOT API request failed:', error instanceof Error ? error.message : 'unknown error');
      sendJson(response, result.status, { error: result.message }, corsOrigin);
    }
  });
}

export function createApplication(options = {}) {
  const configuration = options.configuration || {
    host: process.env.HOMIOT_HOST || '127.0.0.1',
    port: Number(process.env.HOMIOT_PORT || 8788),
    databasePath: process.env.HOMIOT_DATABASE_PATH
      ? resolve(backendDirectory, process.env.HOMIOT_DATABASE_PATH)
      : resolve(homedir(), '.homiot', 'homiot.sqlite'),
    serveUi: process.env.HOMIOT_SERVE_UI !== 'false',
    allowInsecureLocal: process.env.HOMIOT_ALLOW_INSECURE_LOCAL === 'true',
    allowedHosts: parseList(process.env.HOMIOT_ALLOWED_INTEGRATION_HOSTS),
    allowedOrigins: parseList(process.env.HOMIOT_ALLOWED_ORIGINS),
  };
  const database = options.database || createDatabase(configuration.databasePath);
  const vault = options.vault || createVault(process.env.HOMIOT_CREDENTIAL_KEY);
  const apiUsers = options.apiUsers || (options.authenticate ? [] : parseUsers(process.env.HOMIOT_API_USERS_JSON));
  const telemetryProducers = options.telemetryProducers
    || parseTelemetryProducers(process.env.HOMIOT_TELEMETRY_PRODUCERS_JSON, apiUsers);
  const authenticate = options.authenticate || createAuthenticator([...apiUsers, ...telemetryProducers]);
  const authenticateTelemetry = options.authenticateTelemetry || authenticate;
  const adapters = options.adapters || createAdapterRegistry({
    mqtt: options.mqtt || mqtt,
    database,
    stateTimeoutMs: Number(process.env.HOMIOT_MQTT_STATE_TIMEOUT_MS || 8000),
    onStatus: (id, status, error) => database.setIntegrationStatus(id, status, error),
  });
  const mqttAdapter = adapters.get('mqtt');
  if (typeof mqttAdapter?.connect === 'function') {
    for (const integration of database.listAllIntegrations()) {
      if (integration.protocol !== 'mqtt') continue;
      try {
        const credentials = vault.open(integration.credentials);
        mqttAdapter.connect(integration, credentials).ready.catch((error) => {
          console.error(`MQTT integration ${integration.id} could not reconnect:`, error instanceof Error ? error.message : 'connection error');
        });
      } catch (error) {
        database.setIntegrationStatus(integration.id, 'error', 'Saved MQTT credentials could not be decrypted.');
        console.error(`MQTT integration ${integration.id} could not be restored:`, error instanceof Error ? error.message : 'invalid credentials');
      }
    }
  }
  const server = createHttpApplication({ configuration, database, vault, authenticate, authenticateTelemetry, adapters });
  return {
    server,
    database,
    adapters,
    configuration,
    close() {
      for (const integration of database.listAllIntegrations()) adapters.get('mqtt')?.close(integration.id);
      server.close();
      database.close();
    },
  };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const application = createApplication();
    application.server.listen(application.configuration.port, application.configuration.host, () => {
      console.log(`HOMIOT integration server listening on http://${application.configuration.host}:${application.configuration.port}`);
      console.log('Provision authenticated users and allowlisted integration hosts before exposing this server beyond localhost.');
    });
    const shutdown = () => application.close();
    process.once('SIGINT', shutdown);
    process.once('SIGTERM', shutdown);
  } catch (error) {
    console.error('HOMIOT integration server configuration error:', error instanceof Error ? error.message : 'invalid configuration');
    process.exitCode = 1;
  }
}
