import { createHash, timingSafeEqual } from 'node:crypto';
import { HttpError } from './errors.js';

function tokenDigest(token) {
  return createHash('sha256').update(token, 'utf8').digest();
}

export function createAuthenticator(users) {
  const seenTokens = new Set();
  const configured = users.map((user) => {
    const digest = tokenDigest(user.token);
    const fingerprint = digest.toString('hex');
    if (seenTokens.has(fingerprint)) throw new Error('Each HOMIOT API user must have a unique access token.');
    seenTokens.add(fingerprint);
    return {
      id: user.id,
      ownerId: user.ownerId || user.id,
      digest,
      homes: new Set(user.homes),
      sourceIds: Array.isArray(user.sourceIds) ? new Set(user.sourceIds) : null,
    };
  });

  return function authenticate(request) {
    const header = request.headers.authorization || '';
    const match = header.match(/^Bearer ([A-Za-z0-9._~-]{32,512})$/);
    const supplied = tokenDigest(match?.[1] || 'invalid-token');
    let authenticated = null;
    for (const user of configured) {
      if (timingSafeEqual(supplied, user.digest)) authenticated = user;
    }
    if (!match || !authenticated) throw new HttpError(401, 'Provide a valid HOMIOT integration access token.');
    return authenticated;
  };
}

export function requireHome(user, homeId) {
  if (typeof homeId !== 'string' || !homeId.trim() || homeId.length > 100) {
    throw new HttpError(400, 'A valid homeId is required.');
  }
  if (!user.homes.has(homeId)) throw new HttpError(403, 'You are not authorized to access this home.');
  return homeId;
}
