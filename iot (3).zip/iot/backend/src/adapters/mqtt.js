import { IntegrationAdapter } from './base.js';
import { HttpError } from '../errors.js';

const DISCOVERY_PREFIX = 'homeassistant';

function validTopic(topic, required = false) {
  if (topic === undefined || topic === null || topic === '') {
    if (required) throw new Error('The MQTT discovery payload is missing a required topic.');
    return '';
  }
  if (typeof topic !== 'string' || (required && !topic.trim()) || topic.length > 512
    || topic.includes('#') || topic.includes('+') || topic.includes('\u0000')) {
    throw new Error('The MQTT discovery payload contains an unsupported topic.');
  }
  return topic;
}

function parseDiscovery(topic, payload, integration, prefix = DISCOVERY_PREFIX) {
  let config;
  try {
    config = JSON.parse(payload.toString('utf8'));
  } catch {
    return null;
  }
  const [topicPrefix, component, objectId, suffix] = topic.split('/');
  if (topicPrefix !== prefix || suffix !== 'config' || !component || !objectId
    || !config || typeof config !== 'object' || Array.isArray(config)) return null;
  if (config.value_template || config.state_value_template || config.json_attributes_topic) return null;
  const deviceInfo = config.device && typeof config.device === 'object' ? config.device : {};
  const sourceId = String(config.unique_id || `${component}.${objectId}`).slice(0, 160);
  const name = String(config.name || deviceInfo.name || objectId).trim().slice(0, 100);
  if (!name || !sourceId) return null;

  const powerCommandTopic = validTopic(config.command_topic, false);
  const stateTopic = validTopic(config.state_topic, false);
  const brightnessStateTopic = validTopic(config.brightness_state_topic, false);
  const percentageStateTopic = validTopic(config.percentage_state_topic, false);
  const capabilities = [];
  const topics = {};
  if (powerCommandTopic && stateTopic) {
    capabilities.push('power');
    topics.powerCommand = powerCommandTopic;
    topics.payloadOn = String(config.payload_on || 'ON').slice(0, 32);
    topics.payloadOff = String(config.payload_off || 'OFF').slice(0, 32);
    topics.stateOn = String(config.state_on || config.payload_on || 'ON').slice(0, 32);
    topics.stateOff = String(config.state_off || config.payload_off || 'OFF').slice(0, 32);
  }
  if (component === 'light' && config.brightness_command_topic && (stateTopic || brightnessStateTopic)) {
    capabilities.push('brightness');
    topics.brightnessCommand = validTopic(config.brightness_command_topic, true);
    topics.brightnessScale = Number.isFinite(config.brightness_scale) ? config.brightness_scale : 255;
    if (topics.brightnessScale < 1 || topics.brightnessScale > 255) return null;
  }
  if (component === 'fan' && config.percentage_command_topic && (stateTopic || percentageStateTopic)) {
    capabilities.push('fan_speed');
    topics.fanSpeedCommand = validTopic(config.percentage_command_topic, true);
  }
  if (component === 'sensor' && stateTopic) capabilities.push('sensor_reading');
  if (!capabilities.length) return null;

  const availability = Array.isArray(config.availability) ? config.availability[0] : config.availability;
  const availabilityTopic = validTopic(availability?.topic, false);
  return {
    record: {
      ownerId: integration.owner_id,
      homeId: integration.home_id,
      integrationId: integration.id,
      sourceId,
      name,
      manufacturer: typeof deviceInfo.manufacturer === 'string' ? deviceInfo.manufacturer.slice(0, 100) : null,
      model: typeof deviceInfo.model === 'string' ? deviceInfo.model.slice(0, 100) : null,
      hardwareType: String(deviceInfo.model || deviceInfo.name || component).slice(0, 100),
      protocol: 'mqtt',
      connectionType: 'MQTT',
      capabilities,
      state: {},
      availability: 'unknown',
      lastCommunication: null,
    },
    topics: {
      discovery: topic,
      state: stateTopic,
      availability: availabilityTopic,
      attributes: brightnessStateTopic || percentageStateTopic,
      availabilityOnline: String(availability?.payload_available || 'online').slice(0, 32),
      availabilityOffline: String(availability?.payload_not_available || 'offline').slice(0, 32),
      ...topics,
    },
  };
}

function decodeState(payload, discovered) {
  const text = payload.toString('utf8').trim();
  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = null;
  }
  const state = {};
  if (discovered.record.capabilities.includes('power')) {
    const value = typeof parsed === 'object' && parsed !== null ? parsed.state ?? parsed.power : text;
    if (value === discovered.topics.stateOn || value === true || value === 'ON' || value === 'on') state.power = true;
    if (value === discovered.topics.stateOff || value === false || value === 'OFF' || value === 'off') state.power = false;
  }
  if (discovered.record.capabilities.includes('brightness')) {
    const value = typeof parsed === 'object' && parsed !== null ? parsed.brightness : Number(text);
    if (Number.isFinite(value)) state.brightness = Math.round(Math.max(0, Math.min(255, value)) / discovered.topics.brightnessScale * 100);
  }
  if (discovered.record.capabilities.includes('fan_speed')) {
    const value = typeof parsed === 'object' && parsed !== null ? parsed.percentage : Number(text);
    if (Number.isFinite(value) && value >= 0 && value <= 100) state.fan_speed = value;
  }
  if (discovered.record.capabilities.includes('sensor_reading')) {
    const value = typeof parsed === 'object' && parsed !== null ? parsed.value : Number.isFinite(Number(text)) ? Number(text) : text.slice(0, 128);
    state.value = value;
    if (typeof parsed === 'object' && parsed && typeof parsed.unit === 'string') state.unit = parsed.unit.slice(0, 32);
  }
  return state;
}

function sameValue(actual, action, desired) {
  if (action === 'power') return actual.power === desired;
  if (action === 'brightness') return actual.brightness === desired;
  if (action === 'fan_speed') return actual.fan_speed === desired;
  return false;
}

export class MqttAdapter extends IntegrationAdapter {
  constructor({ mqtt, database, stateTimeoutMs = 8000, onStatus = () => {} }) {
    super('mqtt');
    this.mqtt = mqtt;
    this.database = database;
    this.stateTimeoutMs = stateTimeoutMs;
    this.onStatus = onStatus;
    this.clients = new Map();
    this.discovered = new Map();
    this.pendingCommands = new Map();
  }

  connect(integration, credentials) {
    if (this.clients.has(integration.id)) return this.clients.get(integration.id);
    const client = this.mqtt.connect(credentials.url, {
      username: credentials.username || undefined,
      password: credentials.password || undefined,
      clientId: `homiot_${integration.id.replace(/-/g, '').slice(0, 18)}`,
      clean: true,
      reconnectPeriod: 3000,
      connectTimeout: 8000,
      resubscribe: true,
    });
    const session = { client, ready: null, onMessage: null };
    session.ready = new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new HttpError(504, 'MQTT broker did not respond before the connection timeout.')), 8000);
      client.once('connect', () => {
        const prefix = credentials.topicPrefix || DISCOVERY_PREFIX;
        try {
          client.subscribe(`${prefix}/+/+/config`, { qos: 1 }, (error) => {
            clearTimeout(timer);
            if (error) {
              this.database.setIntegrationStatus(integration.id, 'error', 'MQTT discovery subscription failed.');
              this.onStatus(integration.id, 'error', 'MQTT discovery subscription failed.');
              reject(new HttpError(502, 'MQTT broker connected, but discovery subscription failed.'));
              return;
            }
            this.database.setIntegrationStatus(integration.id, 'connected');
            this.onStatus(integration.id, 'connected', null);
            resolve();
          });
        } catch {
          clearTimeout(timer);
          this.database.setIntegrationStatus(integration.id, 'error', 'MQTT discovery subscription failed.');
          this.onStatus(integration.id, 'error', 'MQTT discovery subscription failed.');
          reject(new HttpError(502, 'MQTT broker connected, but discovery subscription failed.'));
        }
      });
      client.once('error', (error) => {
        clearTimeout(timer);
        this.database.setIntegrationStatus(integration.id, 'error', 'MQTT broker connection failed.');
        this.onStatus(integration.id, 'error', 'MQTT broker connection failed.');
        reject(new HttpError(502, `MQTT broker connection failed: ${String(error.message || 'connection error').slice(0, 120)}`));
      });
    });
    client.on('message', (topic, payload) => {
      try {
        this.handleMessage(integration, credentials, topic, payload);
      } catch (error) {
        console.error(`MQTT message rejected for integration ${integration.id}:`, error instanceof Error ? error.message : 'invalid message');
      }
    });
    client.on('error', () => {
      this.database.setIntegrationStatus(integration.id, 'error', 'MQTT broker connection failed.');
      this.onStatus(integration.id, 'error', 'MQTT broker connection failed.');
    });
    client.on('close', () => {
      this.database.setIntegrationStatus(integration.id, 'disconnected');
      this.onStatus(integration.id, 'disconnected', null);
      for (const [deviceId, pending] of this.pendingCommands) {
        if (pending.integrationId === integration.id) this.rejectWaiter(deviceId, 'MQTT connection closed before the device state was verified.');
      }
    });
    this.clients.set(integration.id, session);
    session.ready.catch(() => {
      if (this.clients.get(integration.id) === session) this.clients.delete(integration.id);
      client.end(true);
    });
    return session;
  }

  handleMessage(integration, credentials, topic, payload) {
    const prefix = credentials.topicPrefix || DISCOVERY_PREFIX;
    if (topic.startsWith(`${prefix}/`) && topic.endsWith('/config')) {
      const discovered = parseDiscovery(topic, payload, integration, credentials.topicPrefix || DISCOVERY_PREFIX);
      if (!discovered) return;
      const key = `${integration.id}:${discovered.record.sourceId}`;
      this.discovered.set(key, discovered);
      const saved = this.database.upsertDevice(discovered.record);
      discovered.record.id = saved.id;
      if (discovered.topics.state) {
        this.clients.get(integration.id)?.client.subscribe(discovered.topics.state, { qos: 1 }, (error) => {
          if (error) this.onStatus(integration.id, 'error', 'MQTT device state subscription failed.');
        });
      }
      if (discovered.topics.availability) {
        this.clients.get(integration.id)?.client.subscribe(discovered.topics.availability, { qos: 1 }, (error) => {
          if (error) this.onStatus(integration.id, 'error', 'MQTT device availability subscription failed.');
        });
      }
      return;
    }

    for (const [key, discovered] of this.discovered) {
      if (!key.startsWith(`${integration.id}:`)) continue;
      const id = discovered.record.id;
      if (topic === discovered.topics.availability) {
        const value = payload.toString('utf8').trim();
        const onlineValue = discovered.topics.availabilityOnline || 'online';
        const offlineValue = discovered.topics.availabilityOffline || 'offline';
        discovered.record.availability = value === onlineValue ? 'online' : value === offlineValue ? 'offline' : 'unknown';
        discovered.record.lastCommunication = new Date().toISOString();
        this.database.updateDevice({
          id, ownerId: integration.owner_id, homeId: integration.home_id,
          state: discovered.record.state, availability: discovered.record.availability,
          lastCommunication: discovered.record.lastCommunication,
        });
      } else if (topic === discovered.topics.state || topic === discovered.topics.attributes) {
        discovered.record.state = { ...discovered.record.state, ...decodeState(payload, discovered) };
        discovered.record.availability = 'online';
        discovered.record.lastCommunication = new Date().toISOString();
        const saved = this.database.updateDevice({
          id, ownerId: integration.owner_id, homeId: integration.home_id,
          state: discovered.record.state, availability: 'online',
          lastCommunication: discovered.record.lastCommunication,
        });
        this.resolvePending(id, saved);
      }
    }
  }

  async test(integration, credentials) {
    const session = this.connect(integration, credentials);
    await session.ready;
    return { connected: true, message: 'MQTT broker connection and discovery subscription are active.' };
  }

  async discover(integration, credentials) {
    const session = this.connect(integration, credentials);
    await session.ready;
    const prefix = credentials.topicPrefix || DISCOVERY_PREFIX;
    await new Promise((resolve, reject) => {
      session.client.subscribe(`${prefix}/+/+/config`, { qos: 1 }, (error) => error ? reject(new HttpError(502, 'MQTT discovery subscription failed.')) : resolve());
    });
    await new Promise((resolve) => setTimeout(resolve, 1200));
    const devices = [...this.discovered.values()]
      .filter((item) => item.record.integrationId === integration.id)
      .map((item) => this.database.getDevice(item.record.id, integration.owner_id, integration.home_id))
      .filter(Boolean);
    return devices;
  }

  async execute(integration, device, command, credentials) {
    const session = this.connect(integration, credentials);
    await session.ready;
    const key = `${integration.id}:${device.sourceId}`;
    const discovered = this.discovered.get(key);
    if (!discovered) throw new HttpError(409, 'The MQTT device has not advertised a supported discovery configuration.');
    if (device.availability === 'offline') throw new HttpError(409, 'The MQTT device reported itself offline; no command was sent.');
    const actionTopic = command.action === 'power' ? discovered.topics.powerCommand
      : command.action === 'brightness' ? discovered.topics.brightnessCommand
        : command.action === 'fan_speed' ? discovered.topics.fanSpeedCommand : null;
    if (!actionTopic) throw new HttpError(422, 'This MQTT device does not advertise that command capability.');
    const desired = command.value;
    const payload = command.action === 'power'
      ? (desired ? discovered.topics.payloadOn : discovered.topics.payloadOff)
      : String(command.action === 'brightness'
        ? Math.round(desired / 100 * discovered.topics.brightnessScale)
        : desired);
    const priorMessage = this.createWaiter(device.id, command.action, desired, integration.id);
    priorMessage.catch(() => {});
    try {
      await new Promise((resolve, reject) => {
        session.client.publish(actionTopic, payload, { qos: 1 }, (error) => error ? reject(new HttpError(502, 'MQTT command publish failed.')) : resolve());
      });
    } catch (error) {
      this.clearWaiter(device.id);
      throw error;
    }
    return priorMessage;
  }

  createWaiter(deviceId, action, desired, integrationId) {
    if (this.pendingCommands.has(deviceId)) throw new HttpError(409, 'A command for this device is already waiting for a reported state.');
    return new Promise((resolve, reject) => {
      const pending = {
        action, desired, integrationId,
        timer: null,
        resolve: (device) => { clearTimeout(timer); resolve(device); },
        reject: (error) => { clearTimeout(timer); reject(error); },
      };
      const timer = setTimeout(() => {
        if (this.pendingCommands.get(deviceId) === pending) this.pendingCommands.delete(deviceId);
        reject(new HttpError(504, 'MQTT command was published, but no matching device state report arrived before timeout.'));
      }, this.stateTimeoutMs);
      pending.timer = timer;
      this.pendingCommands.set(deviceId, pending);
    });
  }

  resolvePending(deviceId, device) {
    const pending = this.pendingCommands.get(deviceId);
    if (pending && sameValue(device.state, pending.action, pending.desired)) {
      this.pendingCommands.delete(deviceId);
      pending.resolve(device);
    }
  }

  clearWaiter(deviceId) {
    const pending = this.pendingCommands.get(deviceId);
    if (pending) {
      clearTimeout(pending.timer);
      pending.resolve(null);
    }
    this.pendingCommands.delete(deviceId);
  }

  rejectWaiter(deviceId, message) {
    const pending = this.pendingCommands.get(deviceId);
    if (!pending) return;
    this.pendingCommands.delete(deviceId);
    pending.reject(new HttpError(502, message));
  }

  close(integrationId) {
    const session = this.clients.get(integrationId);
    if (!session) return;
    session.client.end(true);
    this.clients.delete(integrationId);
    for (const key of this.discovered.keys()) if (key.startsWith(`${integrationId}:`)) this.discovered.delete(key);
    for (const [deviceId, pending] of this.pendingCommands) {
      if (pending.integrationId === integrationId) this.rejectWaiter(deviceId, 'MQTT integration was closed before the device state was verified.');
    }
  }
}
