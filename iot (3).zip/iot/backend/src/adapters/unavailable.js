import { IntegrationAdapter } from './base.js';

export class UnavailableAdapter extends IntegrationAdapter {
  constructor(protocol, phase) {
    super(protocol);
    this.phase = phase;
    this.configured = false;
  }

  async test() {
    throw new Error(`${this.protocol} is not implemented in this phase. ${this.phase}`);
  }

  async discover() {
    throw new Error(`${this.protocol} discovery is not implemented in this phase. ${this.phase}`);
  }

  async execute() {
    throw new Error(`${this.protocol} control is not implemented in this phase. ${this.phase}`);
  }
}
