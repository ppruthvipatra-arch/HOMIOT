import { HomeAssistantAdapter } from './homeAssistant.js';
import { MqttAdapter } from './mqtt.js';
import { UnavailableAdapter } from './unavailable.js';

export function createAdapterRegistry(dependencies) {
  return new Map([
    ['mqtt', new MqttAdapter(dependencies)],
    ['home_assistant', new HomeAssistantAdapter()],
    ['matter', new UnavailableAdapter('Matter', 'Commissioning and control require the separate Matter gateway phase.')],
    ['http_rest', new UnavailableAdapter('HTTP/REST', 'Generic per-device HTTP adapters are not configured in phase one.')],
    ['websocket', new UnavailableAdapter('WebSocket', 'Generic device WebSocket adapters are not configured in phase one.')],
    ['zigbee_gateway', new UnavailableAdapter('Zigbee', 'Use a supported gateway integration; a native Zigbee adapter is not configured.')],
    ['bluetooth_gateway', new UnavailableAdapter('Bluetooth LE', 'Use a supported gateway integration; direct browser Bluetooth is not used.')],
    ['modbus', new UnavailableAdapter('Modbus', 'A secured Modbus TCP/RTU gateway adapter is not configured in phase one.')],
  ]);
}
