export class IntegrationAdapter {
  constructor(protocol) {
    this.protocol = protocol;
  }

  async test() {
    throw new Error(`${this.protocol} connection testing is not implemented.`);
  }

  async discover() {
    throw new Error(`${this.protocol} device discovery is not implemented.`);
  }

  async execute() {
    throw new Error(`${this.protocol} device control is not implemented.`);
  }
}
