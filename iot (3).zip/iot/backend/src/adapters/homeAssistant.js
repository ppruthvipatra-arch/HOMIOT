import { IntegrationAdapter } from './base.js';
import { HttpError } from '../errors.js';

const DOMAIN_CAPABILITIES = {
  light: ['power', 'brightness'],
  switch: ['power'],
  fan: ['power', 'fan_speed'],
  climate: ['temperature'],
  lock: ['lock'],
  sensor: ['sensor_reading'],
  binary_sensor: ['sensor_reading'],
};

function entitySupported(entity) {
  if (!entity || entity.entity_id?.length > 160) return false;
  const domain = entity.entity_id?.split('.')[0];
  if (!DOMAIN_CAPABILITIES[domain]) return false;
  const attributes = entity.attributes || {};
  if (domain === 'light') {
    const colorModes = Array.isArray(attributes.supported_color_modes) ? attributes.supported_color_modes : [];
    if (!Number.isFinite(attributes.brightness) && !colorModes.some((mode) => mode !== 'onoff')) return ['power'];
  }
  if (domain === 'fan' && !Number.isFinite(attributes.percentage)) return ['power'];
  if (domain === 'climate' && (!Number.isFinite(attributes.min_temp) || !Number.isFinite(attributes.max_temp))) {
    return [];
  }
  return DOMAIN_CAPABILITIES[domain];
}

function mapEntity(entity, integration) {
  const domain = entity.entity_id.split('.')[0];
  const attributes = entity.attributes || {};
  const capabilities = entitySupported(entity);
  if (!capabilities.length) return null;
  const state = {};
  if (domain === 'light' || domain === 'switch' || domain === 'fan') state.power = entity.state === 'on';
  if (domain === 'light' && Number.isFinite(attributes.brightness)) state.brightness = Math.round(attributes.brightness / 255 * 100);
  if (domain === 'fan' && Number.isFinite(attributes.percentage)) state.fan_speed = attributes.percentage;
  if (domain === 'climate' && Number.isFinite(attributes.temperature)) state.temperature = attributes.temperature;
  if (domain === 'sensor' || domain === 'binary_sensor') {
    state.value = entity.state;
    state.unit = typeof attributes.unit_of_measurement === 'string' ? attributes.unit_of_measurement : '';
  }
  if (domain === 'lock') state.locked = entity.state === 'locked';
  return {
    ownerId: integration.owner_id,
    homeId: integration.home_id,
    integrationId: integration.id,
    sourceId: entity.entity_id,
    name: String(attributes.friendly_name || entity.entity_id).slice(0, 100),
    manufacturer: typeof attributes.manufacturer === 'string' ? attributes.manufacturer.slice(0, 100) : null,
    model: typeof attributes.model === 'string' ? attributes.model.slice(0, 100) : null,
    hardwareType: domain,
    protocol: 'home_assistant',
    connectionType: 'Home Assistant REST/WebSocket',
    capabilities,
    state,
    availability: entity.state === 'unavailable' ? 'offline' : entity.state === 'unknown' ? 'unknown' : 'online',
    lastCommunication: entity.last_updated || new Date().toISOString(),
  };
}

export class HomeAssistantAdapter extends IntegrationAdapter {
  constructor(fetchImpl = fetch, WebSocketConstructor = WebSocket) {
    super('home_assistant');
    this.fetch = fetchImpl;
    this.WebSocketConstructor = WebSocketConstructor;
  }

  async request(integration, credentials, path, options = {}) {
    const base = credentials.baseUrl.replace(/\/+$/, '');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await this.fetch(`${base}${path}`, {
        ...options,
        signal: controller.signal,
        redirect: 'error',
        headers: {
          Authorization: `Bearer ${credentials.token}`,
          Accept: 'application/json',
          ...(options.body ? { 'Content-Type': 'application/json' } : {}),
          ...options.headers,
        },
      });
      if (response.status === 401 || response.status === 403) throw new HttpError(502, 'Home Assistant rejected its configured access token.');
      if (!response.ok) throw new HttpError(502, `Home Assistant request failed with status ${response.status}.`);
      return response.status === 204 ? null : response.json();
    } finally {
      clearTimeout(timeout);
    }
  }

  async test(integration, credentials) {
    const result = await this.request(integration, credentials, '/api/');
    await this.websocket(integration, credentials, 'get_config');
    return { connected: true, message: 'Home Assistant authenticated REST and WebSocket APIs responded.', server: String(result?.message || 'Home Assistant').slice(0, 80) };
  }

  async discover(integration, credentials) {
    const entities = await this.websocket(integration, credentials, 'get_states');
    if (!Array.isArray(entities)) throw new HttpError(502, 'Home Assistant returned an invalid state list.');
    return entities.map((entity) => mapEntity(entity, integration)).filter(Boolean);
  }

  async websocket(integration, credentials, type, payload = {}) {
    if (typeof this.WebSocketConstructor !== 'function') throw new HttpError(503, 'This Node.js runtime does not provide the WebSocket client required by Home Assistant.');
    const url = new URL(credentials.baseUrl);
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    url.pathname = `${url.pathname.replace(/\/+$/, '')}/api/websocket`.replace(/^\/\//, '/');
    url.search = '';
    url.hash = '';
    return new Promise((resolve, reject) => {
      const socket = new this.WebSocketConstructor(url);
      let authenticated = false;
      let settled = false;
      const messageId = 1;
      let requestSent = false;
      const timeout = setTimeout(() => finish(new HttpError(504, 'Home Assistant WebSocket did not respond before timeout.')), 8000);
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        try { socket.close(); } catch {}
        if (error) reject(error);
        else resolve(value);
      };
      socket.addEventListener('message', (event) => {
        let message;
        try {
          message = JSON.parse(String(event.data));
        } catch {
          finish(new HttpError(502, 'Home Assistant sent an invalid WebSocket response.'));
          return;
        }
        if (message.type === 'auth_required') {
          try {
            socket.send(JSON.stringify({ type: 'auth', access_token: credentials.token }));
          } catch {
            finish(new HttpError(502, 'Home Assistant WebSocket authentication could not be sent.'));
          }
          return;
        }
        if (message.type === 'auth_invalid') {
          finish(new HttpError(502, 'Home Assistant rejected its configured WebSocket access token.'));
          return;
        }
        if (message.type === 'auth_ok') {
          if (requestSent) return;
          authenticated = true;
          requestSent = true;
          try {
            socket.send(JSON.stringify({ id: messageId, type, ...payload }));
          } catch {
            finish(new HttpError(502, 'Home Assistant WebSocket request could not be sent.'));
          }
          return;
        }
        if (!authenticated || message.id !== messageId) return;
        if (message.type !== 'result' || message.success !== true) {
          finish(new HttpError(502, 'Home Assistant WebSocket command failed.'));
          return;
        }
        finish(null, message.result);
      });
      socket.addEventListener('error', () => finish(new HttpError(502, 'Home Assistant WebSocket connection failed.')));
      socket.addEventListener('close', () => {
        if (!settled) finish(new HttpError(502, 'Home Assistant WebSocket closed before returning a result.'));
      });
    });
  }

  async execute(integration, device, command, credentials) {
    const domain = device.sourceId.split('.')[0];
    if (!DOMAIN_CAPABILITIES[domain]) throw new HttpError(422, 'This Home Assistant entity domain is not supported for control.');
    const serviceFor = {
      'power:on': { service: domain === 'climate' ? 'turn_on' : 'turn_on', data: {} },
      'power:off': { service: 'turn_off', data: {} },
      'brightness:set': { service: 'turn_on', data: { brightness_pct: command.value } },
      'fan_speed:set': { service: 'set_percentage', data: { percentage: command.value } },
      'temperature:set': { service: 'set_temperature', data: { temperature: command.value } },
      'lock:lock': { service: 'lock', data: {} },
      'lock:unlock': { service: 'unlock', data: {} },
    }[`${command.action}:${command.action === 'lock' ? command.value : 'set'}`]
      || (command.action === 'power' ? {
        service: command.value ? (domain === 'climate' ? 'turn_on' : 'turn_on') : 'turn_off',
          data: {},
      } : null);
    if (!serviceFor) throw new HttpError(422, 'That action is not supported by this Home Assistant entity.');

    const capability = command.action === 'power' ? 'power'
      : command.action === 'brightness' ? 'brightness'
        : command.action === 'fan_speed' ? 'fan_speed'
          : command.action === 'temperature' ? 'temperature'
            : 'lock';
    const currentState = await this.request(integration, credentials, `/api/states/${encodeURIComponent(device.sourceId)}`);
    const currentDevice = mapEntity(currentState, integration);
    if (!currentDevice || currentDevice.availability !== 'online') {
      throw new HttpError(409, 'Home Assistant currently reports this entity as unavailable.');
    }
    if (!device.capabilities.includes(capability) || !currentDevice.capabilities.includes(capability)) {
      throw new HttpError(422, 'This entity does not currently expose that capability.');
    }
    if (command.action === 'temperature') {
      const { min_temp: min, max_temp: max } = currentState.attributes || {};
      if (!Number.isFinite(min) || !Number.isFinite(max)
        || !Number.isFinite(command.value) || command.value < min || command.value > max) {
        throw new HttpError(422, `Temperature must be within the device-reported range (${min}–${max}).`);
      }
    }
    const body = {
      entity_id: device.sourceId,
      ...serviceFor.data,
    };
    await this.websocket(integration, credentials, 'call_service', {
      domain,
      service: serviceFor.service,
      service_data: body,
    });
    const deadline = Date.now() + 5000;
    let record = null;
    while (Date.now() < deadline) {
      const updated = await this.request(integration, credentials, `/api/states/${encodeURIComponent(device.sourceId)}`);
      record = mapEntity(updated, integration);
      if (!record) throw new HttpError(502, 'Home Assistant returned an unsupported device state after the command.');
      const verified = command.action === 'power'
        ? record.state.power === command.value
        : command.action === 'brightness' ? record.state.brightness === command.value
          : command.action === 'fan_speed' ? record.state.fan_speed === command.value
            : command.action === 'temperature' ? record.state.temperature === command.value
              : record.state.locked === (command.value === 'lock');
      if (verified) return record;
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    throw new HttpError(502, 'Home Assistant accepted the request, but the reported device state did not confirm it.');
  }
}
