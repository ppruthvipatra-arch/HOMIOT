import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

export function createDatabase(pathname) {
  const filename = resolve(pathname);
  mkdirSync(dirname(filename), { recursive: true, mode: 0o700 });
  const database = new DatabaseSync(filename);
  database.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS integrations (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      home_id TEXT NOT NULL,
      protocol TEXT NOT NULL CHECK(protocol IN ('mqtt', 'home_assistant')),
      name TEXT NOT NULL,
      credentials TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'not_tested',
      last_error TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY,
      integration_id TEXT NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
      owner_id TEXT NOT NULL,
      home_id TEXT NOT NULL,
      room_id TEXT,
      source_id TEXT NOT NULL,
      name TEXT NOT NULL,
      manufacturer TEXT,
      model TEXT,
      hardware_type TEXT NOT NULL,
      protocol TEXT NOT NULL,
      connection_type TEXT NOT NULL,
      capabilities TEXT NOT NULL,
      state TEXT NOT NULL,
      availability TEXT NOT NULL DEFAULT 'unknown',
      last_communication TEXT,
      UNIQUE(integration_id, source_id)
    );
    CREATE INDEX IF NOT EXISTS devices_home_idx ON devices(owner_id, home_id);
    CREATE INDEX IF NOT EXISTS integrations_home_idx ON integrations(owner_id, home_id);
    CREATE TABLE IF NOT EXISTS telemetry_readings (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      home_id TEXT NOT NULL,
      source_id TEXT NOT NULL,
      channel TEXT NOT NULL CHECK(channel IN ('energy_meter', 'solar', 'battery', 'grid', 'inverter', 'home_load')),
      measured_at TEXT NOT NULL,
      received_at TEXT NOT NULL,
      values_json TEXT NOT NULL,
      UNIQUE(owner_id, home_id, source_id, channel, measured_at)
    );
    CREATE INDEX IF NOT EXISTS telemetry_home_channel_time_idx
      ON telemetry_readings(owner_id, home_id, channel, measured_at DESC);
    CREATE TABLE IF NOT EXISTS billing_settings (
      owner_id TEXT NOT NULL,
      home_id TEXT NOT NULL,
      grid_source_id TEXT NOT NULL,
      energy_rate_per_kwh REAL NOT NULL,
      export_rate_per_kwh REAL NOT NULL,
      fixed_charges REAL NOT NULL,
      additional_charges REAL NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(owner_id, home_id)
    );
  `);

  const insertIntegration = database.prepare(`
    INSERT INTO integrations (id, owner_id, home_id, protocol, name, credentials, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 'not_tested', ?)
  `);
  const getIntegration = database.prepare('SELECT * FROM integrations WHERE id = ? AND owner_id = ? AND home_id = ?');
  const listIntegrations = database.prepare(`
    SELECT id, owner_id, home_id, protocol, name, status, last_error, created_at
    FROM integrations WHERE owner_id = ? AND home_id = ? ORDER BY created_at DESC
  `);
  const listAllIntegrations = database.prepare('SELECT * FROM integrations');
  const updateIntegration = database.prepare('UPDATE integrations SET status = ?, last_error = ? WHERE id = ?');
  const deleteIntegration = database.prepare('DELETE FROM integrations WHERE id = ? AND owner_id = ? AND home_id = ?');
  const upsertDevice = database.prepare(`
    INSERT INTO devices (
      id, integration_id, owner_id, home_id, room_id, source_id, name, manufacturer, model,
      hardware_type, protocol, connection_type, capabilities, state, availability, last_communication
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(integration_id, source_id) DO UPDATE SET
      name = excluded.name,
      manufacturer = excluded.manufacturer,
      model = excluded.model,
      hardware_type = excluded.hardware_type,
      protocol = excluded.protocol,
      connection_type = excluded.connection_type,
      capabilities = excluded.capabilities,
      state = excluded.state,
      availability = excluded.availability,
      last_communication = excluded.last_communication
  `);
  const listDevices = database.prepare('SELECT * FROM devices WHERE owner_id = ? AND home_id = ? ORDER BY name');
  const listIntegrationDevices = database.prepare('SELECT * FROM devices WHERE integration_id = ? AND owner_id = ? AND home_id = ? ORDER BY name');
  const getDevice = database.prepare('SELECT * FROM devices WHERE id = ? AND owner_id = ? AND home_id = ?');
  const updateDevice = database.prepare(`
    UPDATE devices SET state = ?, availability = ?, last_communication = ?
    WHERE id = ? AND owner_id = ? AND home_id = ?
  `);
  const updateRoom = database.prepare('UPDATE devices SET room_id = ? WHERE id = ? AND owner_id = ? AND home_id = ?');
  const getTelemetryReading = database.prepare(`
    SELECT * FROM telemetry_readings
    WHERE owner_id = ? AND home_id = ? AND source_id = ? AND channel = ? AND measured_at = ?
  `);
  const insertTelemetryReading = database.prepare(`
    INSERT OR IGNORE INTO telemetry_readings
      (id, owner_id, home_id, source_id, channel, measured_at, received_at, values_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const getBillingSettings = database.prepare(`
    SELECT * FROM billing_settings WHERE owner_id = ? AND home_id = ?
  `);
  const saveBillingSettings = database.prepare(`
    INSERT INTO billing_settings (
      owner_id, home_id, grid_source_id, energy_rate_per_kwh, export_rate_per_kwh,
      fixed_charges, additional_charges, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(owner_id, home_id) DO UPDATE SET
      grid_source_id = excluded.grid_source_id,
      energy_rate_per_kwh = excluded.energy_rate_per_kwh,
      export_rate_per_kwh = excluded.export_rate_per_kwh,
      fixed_charges = excluded.fixed_charges,
      additional_charges = excluded.additional_charges,
      updated_at = excluded.updated_at
  `);

  function toPublicDevice(row) {
    return {
      id: row.id,
      integrationId: row.integration_id,
      homeId: row.home_id,
      roomId: row.room_id,
      sourceId: row.source_id,
      name: row.name,
      manufacturer: row.manufacturer,
      model: row.model,
      hardwareType: row.hardware_type,
      protocol: row.protocol,
      connectionType: row.connection_type,
      capabilities: JSON.parse(row.capabilities),
      state: JSON.parse(row.state),
      availability: row.availability,
      lastCommunication: row.last_communication,
      simulated: false,
    };
  }

  function toPublicTelemetryReading(row) {
    return {
      id: row.id,
      homeId: row.home_id,
      sourceId: row.source_id,
      channel: row.channel,
      measuredAt: row.measured_at,
      receivedAt: row.received_at,
      values: JSON.parse(row.values_json),
    };
  }

  function toPublicBillingSettings(row) {
    return {
      homeId: row.home_id,
      gridSourceId: row.grid_source_id,
      tariffPerKWh: row.energy_rate_per_kwh,
      exportTariffPerKWh: row.export_rate_per_kwh,
      fixedCharges: row.fixed_charges,
      additionalCharges: row.additional_charges,
      updatedAt: row.updated_at,
    };
  }

  return {
    close: () => database.close(),
    saveIntegration(record) {
      const id = randomUUID();
      const createdAt = new Date().toISOString();
      insertIntegration.run(
        id, record.ownerId, record.homeId, record.protocol, record.name,
        record.credentials, createdAt,
      );
      return { id, ...record, status: 'not_tested', lastError: null, createdAt };
    },
    getIntegration(id, ownerId, homeId) {
      return getIntegration.get(id, ownerId, homeId) || null;
    },
    listIntegrations(ownerId, homeId) {
      return listIntegrations.all(ownerId, homeId).map((row) => ({
        id: row.id, homeId: row.home_id, protocol: row.protocol, name: row.name,
        status: row.status, lastError: row.last_error, createdAt: row.created_at,
      }));
    },
    listAllIntegrations: () => listAllIntegrations.all(),
    setIntegrationStatus(id, status, error = null) {
      updateIntegration.run(status, error, id);
    },
    deleteIntegration(id, ownerId, homeId) {
      return deleteIntegration.run(id, ownerId, homeId).changes > 0;
    },
    upsertDevice(record) {
      const current = database.prepare('SELECT id, room_id FROM devices WHERE integration_id = ? AND source_id = ?')
        .get(record.integrationId, record.sourceId);
      const id = current?.id || randomUUID();
      upsertDevice.run(
        id, record.integrationId, record.ownerId, record.homeId, current?.room_id || record.roomId || null,
        record.sourceId, record.name, record.manufacturer || null, record.model || null,
        record.hardwareType, record.protocol, record.connectionType,
        JSON.stringify(record.capabilities), JSON.stringify(record.state || {}),
        record.availability || 'unknown', record.lastCommunication || null,
      );
      return this.getDevice(id, record.ownerId, record.homeId);
    },
    listDevices(ownerId, homeId) {
      return listDevices.all(ownerId, homeId).map(toPublicDevice);
    },
    listIntegrationDevices(integrationId, ownerId, homeId) {
      return listIntegrationDevices.all(integrationId, ownerId, homeId).map(toPublicDevice);
    },
    getDevice(id, ownerId, homeId) {
      const row = getDevice.get(id, ownerId, homeId);
      return row ? toPublicDevice(row) : null;
    },
    updateDevice(record) {
      const result = updateDevice.run(
        JSON.stringify(record.state), record.availability, record.lastCommunication,
        record.id, record.ownerId, record.homeId,
      );
      return result.changes > 0 ? this.getDevice(record.id, record.ownerId, record.homeId) : null;
    },
    updateRoom(id, ownerId, homeId, roomId) {
      return updateRoom.run(roomId, id, ownerId, homeId).changes > 0;
    },
    saveTelemetryReading(record) {
      const valuesJson = JSON.stringify(Object.fromEntries(
        Object.entries(record.values).sort(([left], [right]) => left.localeCompare(right)),
      ));
      const existing = getTelemetryReading.get(
        record.ownerId, record.homeId, record.sourceId, record.channel, record.measuredAt,
      );
      if (existing) {
        return {
          created: false,
          conflict: existing.values_json !== valuesJson,
          reading: toPublicTelemetryReading(existing),
        };
      }

      const receivedAt = new Date().toISOString();
      const id = randomUUID();
      insertTelemetryReading.run(
        id, record.ownerId, record.homeId, record.sourceId, record.channel,
        record.measuredAt, receivedAt, valuesJson,
      );
      const saved = getTelemetryReading.get(
        record.ownerId, record.homeId, record.sourceId, record.channel, record.measuredAt,
      );
      return {
        created: saved.id === id,
        conflict: saved.values_json !== valuesJson,
        reading: toPublicTelemetryReading(saved),
      };
    },
    listTelemetryReadings({ ownerId, homeId, channel, sourceId, since, until, limit }) {
      const conditions = ['owner_id = ?', 'home_id = ?'];
      const parameters = [ownerId, homeId];
      if (channel) {
        conditions.push('channel = ?');
        parameters.push(channel);
      }
      if (sourceId) {
        conditions.push('source_id = ?');
        parameters.push(sourceId);
      }
      if (since) {
        conditions.push('measured_at >= ?');
        parameters.push(since);
      }
      if (until) {
        conditions.push('measured_at <= ?');
        parameters.push(until);
      }
      parameters.push(limit);
      const rows = database.prepare(`
        SELECT * FROM telemetry_readings
        WHERE ${conditions.join(' AND ')}
        ORDER BY measured_at DESC, received_at DESC
        LIMIT ?
      `).all(...parameters);
      return rows.map(toPublicTelemetryReading);
    },
    getBillingSettings(ownerId, homeId) {
      const row = getBillingSettings.get(ownerId, homeId);
      return row ? toPublicBillingSettings(row) : null;
    },
    saveBillingSettings(record) {
      const updatedAt = new Date().toISOString();
      saveBillingSettings.run(
        record.ownerId, record.homeId, record.gridSourceId, record.tariffPerKWh, record.exportTariffPerKWh,
        record.fixedCharges, record.additionalCharges, updatedAt,
      );
      return this.getBillingSettings(record.ownerId, record.homeId);
    },
  };
}
