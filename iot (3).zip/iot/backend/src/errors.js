export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
  }
}

export function publicError(error) {
  if (error instanceof HttpError) return { status: error.status, message: error.message };
  return { status: 500, message: 'The integration request could not be completed.' };
}
