# HOMIOT | Intelligent Living

HOMIOT is a browser-based smart-home prototype, founded by Pruthviraj, for organizing electronics projects and previewing smart-home controls.

The app opens with a responsive HOMIOT dashboard with five device/energy/gateway summaries, a desktop sidebar, a compact mobile navigation bar, and a fixed dark appearance. A draggable robot assistant opens on-device help and browser voice input; it is not connected to a cloud AI service. The authentication screens provide a frontend-only demo flow for registration, local OTP verification, sign-in, and password recovery. Demo accounts and password hashes exist only in the current page session; the displayed OTP is generated locally and is not sent by email or SMS. The optional remembered email is stored in this browser. Five failed sign-in attempts lock this browser for one hour. This client-side demo limit is not production account security; production systems must enforce rate limits on the server. The dashboard's device inventory, scenes, and browser profile are preview data unless separately identified as imported backend devices. Energy readings are shown only when submitted to the authenticated telemetry backend. Billing includes a distinct backend estimate based on monthly grid readings and user-entered flat-rate assumptions, plus a separate local demo projection; neither should be treated as a utility bill or verified meter data.

## Run locally

Open `index.html` in a modern browser for the frontend-only demo; it has no build step or frontend package dependencies. An optional Node.js backend is available for MQTT/Home Assistant discovery and verified controls, plus home-scoped energy telemetry storage. Telemetry still requires a separately provisioned trusted producer; no meter, inverter, or ESP firmware is bundled or configured. Google Fonts are optional; the interface falls back to local sans-serif and monospace fonts when offline.

## Production readiness boundary

This project is not a production smart-home service. The frontend demo authentication is not server authentication: accounts and password hashes are in memory, and are lost when the page closes or reloads. Locally generated verification codes are displayed on screen and are not delivered to an email address or phone. Google sign-in is unavailable because no provider is connected. The backend integration bearer tokens are administrator-provisioned and are not user accounts. Production account access requires a selected identity provider, server-side token verification, account recovery/verification delivery, and home-level authorization.

### Try the authentication demo

Serve the project from `localhost` (recommended, so the browser's secure cryptography APIs are available) or HTTPS, then:

1. Choose **Create profile**, complete the required fields, and accept the terms. The password needs at least eight characters with uppercase and lowercase letters and a number.
2. Select email or mobile as the verification destination and submit. The next screen displays a locally generated six-digit code; enter it to finish creating the in-memory demo account.
3. Sign out by returning to welcome, then log in with the account created during this same page session. **Remember my email** stores only the email address in local browser storage.
4. To test recovery, select **Forgot password?**, enter that session's account email, verify the on-screen local code, and set a new password. Return to login and sign in with the updated password.
5. Try invalid emails, missing terms acceptance, mismatched passwords, incomplete or incorrect codes, password visibility, OTP paste/arrow/backspace navigation, and the resend countdown. Google sign-in reports that no provider is configured.

This demo deliberately does not persist account credentials and does not send messages. Reloading the page clears demo accounts, so create a new account to repeat the flow. Sign-in accepts the registered email or a unique full name. Five failed sign-ins, including an unknown email/name or incorrect password, lock further attempts for one hour in this browser; the countdown survives page reloads. Because this is a browser-only prototype, the limit can be bypassed by clearing browser storage and must not be used as production security. Do not enter a production or reused password.

The backend SQLite database persists integrations and imported devices only. Profiles, homes, rooms, automations, dashboard preferences, and most activity remain browser-local or illustrative; they are not yet a multi-user synchronized data service. Automation rules are saved as examples and do not run in the background. Security-camera tiles do not provide live CCTV streams or recording. The Device Integrations settings page can connect the browser to the optional integration API using its administrator-provisioned bearer token; that API token remains in page memory only. Imported integration devices are displayed separately from the local preview inventory and expose only backend-advertised, verified controls.

No identity-provider project, production database, email/SMS delivery provider, camera gateway, real device broker/Home Assistant instance, cloud AI service, hosting account, Android package, or custom domain has been configured. Production deployment therefore requires selecting and provisioning those services, using HTTPS, migrating local demo data with explicit ownership rules, and validating real devices and camera access. Do not treat the custom domain or any real-world operation as available until the owner has configured and verified it.

## Optional MQTT and Home Assistant backend

Phase one implements MQTT Home Assistant discovery and authenticated Home Assistant REST/WebSocket integration. The Device Integrations settings page connects to this backend, saves integration credentials encrypted on the server, imports supported devices, and sends only capability-validated commands that the adapter verifies against reported state. The home dashboard's preview appliances remain simulated and are never presented as physical devices. Matter is reserved for a separate phase.

Use Node.js 22.5 or later. From PowerShell in this project folder, install the backend's MQTT client, generate a unique local API token and credential-encryption key, then start the backend in the same shell so the environment variables remain available:

```powershell
npm.cmd --prefix backend install
$env:HOMIOT_CREDENTIAL_KEY = node -p "require('node:crypto').randomBytes(32).toString('base64')"
$token = node -p "require('node:crypto').randomBytes(32).toString('hex')"
$env:HOMIOT_API_USERS_JSON = ConvertTo-Json -Compress @(@{ id = 'local-user'; token = $token; homes = @('my-home') })
$env:HOMIOT_ALLOWED_INTEGRATION_HOSTS = 'localhost,127.0.0.1'
$env:HOMIOT_ALLOW_INSECURE_LOCAL = 'true'
npm.cmd --prefix backend start
```

Keep the generated values private; they are examples for the current PowerShell session, not values to commit. Generate the encryption key once and securely preserve/reuse it whenever the backend restarts; generating a new key makes existing stored integrations unreadable. Use HTTPS/TLS for remote integration endpoints. The insecure-local switch is only for a trusted private-network development setup and must not be used to expose the service publicly. The server binds to loopback by default and serves the app at `http://127.0.0.1:8788`; use the API directly with the token and exact authorized home ID (`my-home` in the example). The default SQLite file is stored outside the project at `~/.homiot/homiot.sqlite`. See [the backend API and configuration guide](./backend/API.md) for request examples, schema, and test procedures.

Integration credentials are encrypted server-side with AES-256-GCM in the backend SQLite database. Browser/API user tokens are home-scoped and can read telemetry; separate producer tokens are restricted to one owner, home, and source ID for telemetry writes. Keep producer tokens on a trusted gateway or bridge, not in the browser. The telemetry API stores timestamped values but does not verify physical sensors, subscribe to MQTT telemetry, or map inverter registers. Open the **Bill estimate** section with the configured backend connection to enter the exact grid telemetry source ID, import/export flat rates, and monthly charges. The backend estimate remains unavailable until required current-calendar-month readings arrive; missing import/export measurements are not assumed to be zero. The pre-existing editable projection is labeled as a local demo and does not use telemetry. The test suite uses injected adapters and does not claim successful communication with physical hardware. Run it with:

```powershell
npm.cmd --prefix backend test
```

MQTT discovery requires compatible Home Assistant MQTT discovery messages and state topics. Home Assistant imports supported entities and verifies control results against reported state. ESP32/ESP8266/Arduino/Raspberry Pi devices are not automatically compatible by board name; they need a supported broker/gateway or Home Assistant entity. Matter commissioning is reserved for a later phase. Generic device HTTP/WebSocket, direct Zigbee/Bluetooth gateway, and Modbus control are not implemented. No physical broker or Home Assistant instance is bundled, so live connectivity must be tested against a user's own supported service.

## Install on a phone

HOMIOT is an installable Progressive Web App. The root `manifest.json` provides standalone launch metadata and 192px/512px icons; the versioned service worker precaches the application shell for offline navigation. Runtime requests are not added to the cache, so authentication, device, and camera requests are never stored as part of offline caching. To enable installation and offline app-shell caching, serve this folder from `localhost` or deploy it to an HTTPS site. Opening `index.html` directly as a `file://` URL keeps the preview usable but browsers do not allow PWA installation or service workers from file URLs.

For a quick local preview, open PowerShell in this folder and run `py -m http.server 8000`, then visit `http://localhost:8000` in a browser. The **Install HOMIOT** button appears on the welcome screen and dashboard; it opens the native installation prompt when available or platform-specific instructions otherwise. On Android Chrome, use the browser menu's **Install app** or **Add to Home screen** option. On iPhone, open the HTTPS site in Safari, tap **Share**, then **Add to Home Screen**. Supported desktop browsers may show an install icon in the address bar.

The dashboard uses a compact, responsive upper navigation for Home, Devices, Automation, Energy, Solar, and Profile, with the current section highlighted. Solar is also available from the desktop sidebar. It respects the phone's safe-area insets. Offline support caches the app shell; the separate local energy lab explicitly labels its sample telemetry as simulated. The Energy and Solar pages use only timestamped backend readings and show unavailable states when none are present. Solar history graphs summarize reported daily, monthly, and yearly telemetry; incomplete coverage is called out rather than filled with invented values. Solar's potential bill offset uses the configured import tariff and is explicitly an upper-bound illustration, not measured savings. Installing the app does not connect it to physical hardware.

The movable robot launcher opens local chat/help for navigation, device preview, and gateway setup. Optional voice input/output depends on browser speech support. A backend bill estimate requires a current-month grid reading and configured flat-rate assumptions; it is separate from the local demo projection and is not a utility bill.

## What works in this preview

- Separate energy lab with periodically refreshed demo voltage/current/power/energy values and explicit simulation warnings
- Backend Energy page with timestamped telemetry history when a trusted producer and authenticated backend are configured
- Solar energy page with icon-led sections for overview, production, home use, grid, battery, inverter, analytics, potential savings, and source readings. It uses backend-only telemetry, daily/monthly/yearly graphs, and a clearly qualified potential bill-offset estimate when a tariff is configured.
- Simulated threshold alert test and acknowledge flow; no real protective trip or meter connection
- Named demo switches with editable appliance and room labels
- Wi-Fi settings that clearly report an unconfigured gateway, show optional sample network entries, and never request router passwords
- Overview dashboard with sample telemetry and connection summary
- Device inventory with search, connection filters, add-device, and simulated connect/disconnect controls
- Project list and local project designer with board selection, Wi-Fi/Bluetooth options, and clickable component palette
- Automation rule toggles and local draft creation
- Settings view documenting the hardware bridge boundary
- HOMIOT dashboard with room filters, device controls, local demo-state persistence, and sample automation scenes
- Dashboard device counts reflect the saved local preview state; energy and gateway cards wait for verified sensor or connection data
- Appliance management for eight simulated device types, room and search filters, individual controls, detail/history views, and local demo schedules
- Device renaming/removal, add-to-preview inventory, group control with offline skips, and persistent settings shared between dashboard views; offline device state and readings remain unverified
- Advanced HOMIOT preview for local-only automations, date or weekday schedules, a local demo bill projection and a separate backend tariff estimate, preset/custom scenes, notifications, family-role examples, and simulated security indicators; live energy history is unavailable without a meter
- Advanced automation triggers and schedules are saved as examples and never execute in the background; scene and rule previews explicitly skip offline devices and report partial results
- Settings module for local profile and app preferences; the voice preview handles local navigation only and does not provide cloud AI or physical device control
- Movable robot assistant with on-device help, optional browser speech input/output, and explicit local-only responses
- Multi-home HOMIOT preview with home switching, per-home appliance/schedule/automation state, eight-room management, device/equipment inventory, and a home settings page; all home data stays in this browser
- CCTV inventory and camera live-view/recording-history placeholders; camera credentials are discarded, and no stream or recording is available without a secure media gateway
- Dark appearance is fixed; theme switching is not available

## Production integration starting point

The demo uses a 230 V single-phase sample profile, not a confirmed installation requirement. The optional phase-one backend supports MQTT discovery and Home Assistant REST/WebSocket; it is not a generic ESP32, camera, or cloud adapter. A supported gateway must still publish authenticated readings and accept authorized commands with reported-state acknowledgement. There is no bundled broker, Home Assistant server, or cloud endpoint. Browser-demo device-state changes are not hardware acknowledgements. Provision Wi-Fi through the module's own secure local portal; do not send Wi-Fi passwords through this static page.

Use separate, correctly rated enclosed relay/contactor hardware with state feedback for switching. Size it for the load and startup/inrush current. Protective cutoff must be implemented locally and independently of the browser and network.

## Hardware boundary

Without a configured backend, all appliance controls, electrical readings, connection actions, and automation rules remain simulated in the browser. Imported devices in the optional backend flow are real only when connected to a user's own supported broker or Home Assistant service, and controls require an observed state acknowledgement. HOMIOT does not bundle hardware or guarantee that a given device is compatible. Demo voltage/current limits are not protection settings. A production system needs a certified enclosed energy meter, a secure local gateway, and appropriately rated enclosed relays/contactors. Mains installation must be performed by a qualified electrician. Wi-Fi credentials should be provisioned through the controller's secure local setup portal, not stored in the browser app. Hardware protections must operate independently of the UI/network. The frontend demo remains browser-local; backend integration metadata and device state are stored in the optional server's SQLite database.
