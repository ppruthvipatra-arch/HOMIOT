(() => {
  const service = window.SmartNestAdvancedService;
  const devicesService = window.SmartNestDeviceService;
  const root = document.querySelector('#advanced-features');
  const content = document.querySelector('#advanced-content');
  if (!service || !devicesService || !root || !content) return;

  const routes = {
    'dash-automation': ['Automations', 'automation'],
    'dash-schedules': ['Schedules', 'schedules'],
    'dash-energy': ['Energy monitoring', 'energy'],
    'dash-billing': ['Bill estimate', 'billing'],
    'dash-solar': ['Solar energy', 'solar'],
    'dash-scenes': ['Smart scenes', 'scenes'],
    'dash-notifications': ['Notifications', 'notifications'],
    'dash-family': ['Family access', 'family'],
    'dash-security': ['Security preview', 'security'],
  };
  const triggerNames = {
    MANUAL: 'Manual preview',
    TIME: 'At a chosen time',
    SENSOR_VALUE: 'Demo sensor threshold',
    DEVICE_STATE: 'Device state change',
    ENERGY_THRESHOLD: 'Energy threshold',
  };
  const conditionNames = {
    ALWAYS: 'Always',
    DEVICE_ON: 'Selected device is on',
    DEVICE_OFF: 'Selected device is off',
    ENERGY_ABOVE: 'Daily energy exceeds threshold',
    TEMPERATURE_ABOVE: 'Demo temperature exceeds threshold',
  };
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  let activeRoute = '';
  let query = '';
  let historyFilter = 'all';
  let lastDevices = devicesService.getDevices();
  let energyTelemetry = { status: 'disconnected', readings: [], error: '' };
  let energyTelemetryRequest = 0;
  let billingData = { status: 'disconnected', settings: null, estimate: null, reason: '', error: '' };
  let billingRequest = 0;
  let solarTelemetry = { status: 'disconnected', channels: {}, settings: null, error: '' };
  let solarRequest = 0;
  let solarRange = 'daily';
  let solarActiveSection = 'solar-overview';
  let solarScrollFrame = 0;
  let toastTimer;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[character]);
  }

  function toast(message, error = false) {
    const node = document.querySelector('#dashboard-toast');
    if (!node) return;
    node.textContent = message;
    node.classList.toggle('is-error', error);
    node.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('is-visible'), 3800);
  }

  function snapshot() {
    return service.getSnapshot();
  }

  function run(operation, successMessage) {
    try {
      const result = operation();
      if (successMessage) toast(successMessage);
      render();
      return result;
    } catch (error) {
      toast(error instanceof Error ? error.message : 'This local preview action could not be completed.', true);
      return null;
    }
  }

  function escAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
  }

  function navMarkup(active) {
    const links = [
      ['dash-schedules', 'Schedules', '◷'],
      ['dash-billing', 'Bill estimate', '₹'],
      ['dash-scenes', 'Scenes', '✦'],
      ['dash-notifications', 'Alerts', '♧'],
      ['dash-family', 'Family', '♡'],
      ['dash-security', 'Security', '⌑'],
    ];
    const unread = snapshot().notifications.filter((item) => !item.read).length;
    return `<nav class="advanced-nav" aria-label="More HOMIOT features">${links.map(([route, name, icon]) => `<button type="button" class="${active === route ? 'active' : ''}" data-advanced-route="${route}" aria-current="${active === route ? 'page' : 'false'}"><span aria-hidden="true">${icon}</span>${name}${route === 'dash-notifications' && unread ? `<i>${unread}</i>` : ''}</button>`).join('')}</nav>`;
  }

  function heading(route, title, description, actions = '') {
    const unread = snapshot().notifications.filter((item) => !item.read).length;
    const isEnergy = route === 'dash-energy';
    const isSolar = route === 'dash-solar';
    const isBilling = route === 'dash-billing';
    const connected = window.HomiotConnectivityClient?.getSnapshot().connected;
    const badge = isEnergy || isSolar ? (connected ? 'BACKEND CONNECTED' : 'NO LIVE SOURCE')
      : isBilling ? (connected ? 'BACKEND + DEMO' : 'DEMO ONLY') : 'SIMULATED DATA';
    const disclaimer = isEnergy
      ? '<div class="advanced-disclaimer" role="note"><b>Telemetry boundary.</b> Energy readings shown here are values submitted to your authenticated backend by a trusted producer; HOMIOT does not independently verify the physical meter. No readings are fabricated. Local appliance inventory and the editable demo bill projection remain previews.</div>'
      : isSolar
        ? '<div class="advanced-disclaimer" role="note"><b>Solar data boundary.</b> Production, home use, grid exchange, and battery values are displayed only when reported by authenticated telemetry. Potential bill offset uses the saved import rate and is not an actual bill or verified savings.</div>'
      : isBilling
        ? '<div class="advanced-disclaimer" role="note"><b>Estimate boundary.</b> The separate backend estimate uses submitted monthly grid readings and tariff assumptions saved for this home; HOMIOT cannot verify physical meter data or utility rates. The local projection is simulated. Neither is a utility bill.</div>'
      : '<div class="advanced-disclaimer" role="note"><b>Demo mode.</b> Rules, schedules, sensors, alerts and readings are stored locally. Nothing runs in the background or connects to real appliances.</div>';
    return `<header class="advanced-heading"><div><p class="dashboard-kicker"><span class="dashboard-live-pip"></span> HOMIOT <i>·</i> ${isEnergy ? 'ENERGY MONITORING' : 'ADVANCED PREVIEW'}</p><h1>${title}</h1><p>${description}</p></div><div class="advanced-heading-actions"><span class="advanced-demo-pill">${badge}</span><button type="button" class="advanced-notice-button" data-advanced-route="dash-notifications" aria-label="Open notifications">${unread ? `<i>${unread}</i>` : '♧'}</button>${actions}</div></header>${navMarkup(route)}${disclaimer}`;
  }

  function deviceOptions(devices, selectedId = '') {
    return devices.map((device) => `<option value="${escAttr(device.id)}"${device.id === selectedId ? ' selected' : ''}>${escapeHtml(device.name)} · ${escapeHtml(device.room)}</option>`).join('');
  }

  function enabledDeviceCount(devices) {
    return devices.filter((device) => device.online && device.on).length;
  }

  function money(value) {
    return `₹${Number(value).toFixed(2)}`;
  }

  function summaryCards(data) {
    const estimate = data.settings.dailyKwh * data.settings.billingDays * data.settings.tariff
      + data.settings.fixedCharges + data.settings.additionalCharges;
    const cards = [
      ['Active automations', data.automations.filter((rule) => rule.enabled).length, 'Saved rules · not running automatically', 'ϟ'],
      ['Scheduled devices', new Set(data.schedules.filter((item) => item.enabled).map((item) => item.deviceId)).size, 'Local preview schedules', '◷'],
      ["Today's energy", 'Waiting for sensor data', 'No meter connected', '↗'],
      ['Monthly bill estimate', money(estimate), `${data.settings.billingDays}-day projection · demo tariff`, '₹'],
      ['Energy saved', 'Not measured', 'No meter connected', '✦'],
    ];
    return `<div class="advanced-summary-grid">${cards.map(([label, value, note, icon]) => `<article class="advanced-summary-card"><span class="advanced-summary-icon">${icon}</span><small>${label}</small><strong>${value}</strong><p>${note}</p></article>`).join('')}</div>`;
  }

  function automationCard(rule, devices) {
    const targetNames = rule.actions.map((action) => devices.find((device) => device.id === action.deviceId)?.name || 'Removed device');
    const actionText = rule.actions.map((action) => {
      const device = devices.find((item) => item.id === action.deviceId);
      const setting = action.settings && Object.entries(action.settings)[0];
      return setting
        ? `${device?.name || 'Device'} · ${setting[0].replace(/[A-Z]/g, (letter) => ` ${letter.toLowerCase()}`)} ${setting[1]}`
        : `${device?.name || 'Device'} · ${action.on ? 'turn on' : 'turn off'}`;
    }).join(' · ');
    return `<article class="advanced-card automation-rule${rule.enabled ? '' : ' is-paused'}" data-advanced-item data-name="${escAttr(rule.name)}">
      <div class="advanced-card-top"><span class="advanced-feature-icon">ϟ</span><label class="advanced-switch"><input type="checkbox" data-rule-enabled="${escAttr(rule.id)}" aria-label="${rule.enabled ? 'Pause' : 'Enable'} ${escAttr(rule.name)}"${rule.enabled ? ' checked' : ''}><i></i></label></div>
      <h3>${escapeHtml(rule.name)}</h3><p>${escapeHtml(actionText)}</p>
      <div class="advanced-rule-meta"><span>${escapeHtml(triggerNames[rule.trigger.type] || rule.trigger.type)}${rule.trigger.value ? ` · ${escapeHtml(rule.trigger.value)}` : ''}</span><span>${escapeHtml(conditionNames[rule.condition] || 'Always')}</span></div>
      <div class="advanced-card-footer"><span>${rule.enabled ? 'Enabled · manual preview only' : 'Paused'}</span><div><button type="button" data-edit-rule="${escAttr(rule.id)}">Edit</button><button type="button" data-run-rule="${escAttr(rule.id)}"${rule.enabled ? '' : ' disabled'}>Run preview</button><button type="button" class="advanced-delete" data-delete-rule="${escAttr(rule.id)}" aria-label="Delete ${escAttr(rule.name)}">×</button></div></div>
    </article>`;
  }

  function historyMarkup(data) {
    const rows = data.history.filter((item) => historyFilter === 'all'
      || (historyFilter === 'rules' ? item.ruleId : !item.ruleId));
    if (!rows.length) return '<div class="advanced-empty">No preview runs yet. Run an enabled rule or scene to create local history.</div>';
    return `<div class="advanced-history-list">${rows.map((item) => `<article class="advanced-history-row"><span class="history-status ${item.success ? 'is-ok' : 'is-warning'}">${item.success ? '✓' : '!'}</span><div><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.message)}</small></div><time>${new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(item.createdAt))}</time></article>`).join('')}</div>`;
  }

  function renderAutomations(data) {
    const activeCount = data.automations.filter((rule) => rule.enabled).length;
    return `${heading('dash-automation', 'Smarter routines, your way.', 'Build clear demo rules and preview their actions without enabling background control.', '<button type="button" class="advanced-primary-button" data-create-rule>＋ New automation</button>')}
      ${summaryCards(data)}
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">RULE LIBRARY</p><h2>Automations <span>${activeCount} active</span></h2></div><label class="advanced-search">⌕ <input id="advanced-search" type="search" value="${escAttr(query)}" placeholder="Search automations" aria-label="Search automations"></label></div>
      <div class="advanced-card-grid">${data.automations.map((rule) => automationCard(rule, data.devices)).join('')}</div>${data.automations.length ? '' : '<div class="advanced-empty">No automations yet. Create a rule to get started.</div>'}</section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">LOCAL PREVIEW ACTIVITY</p><h2>Execution history</h2></div><label class="advanced-filter">Show<select id="history-filter"><option value="all"${historyFilter === 'all' ? ' selected' : ''}>All activity</option><option value="rules"${historyFilter === 'rules' ? ' selected' : ''}>Automations</option><option value="scenes"${historyFilter === 'scenes' ? ' selected' : ''}>Scenes</option></select></label></div>${historyMarkup(data)}</section>`;
  }

  function scheduleMarkup(item, devices) {
    const device = devices.find((candidate) => candidate.id === item.deviceId);
    const repeats = item.date
      ? `One time · ${new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(`${item.date}T00:00:00`))}`
      : item.days.slice().sort((a, b) => a - b).map((day) => dayNames[day]).join(' · ');
    return `<article class="advanced-schedule-row" data-advanced-item data-name="${escAttr(device?.name || '')} ${escAttr(repeats)}"><span class="advanced-feature-icon">◷</span><div class="advanced-schedule-device"><b>${escapeHtml(device?.name || 'Removed device')}</b><small>${escapeHtml(device?.room || 'Unknown room')} · local preview</small></div><div class="advanced-schedule-times"><b>${escapeHtml(item.onTime)} <i>→</i> ${escapeHtml(item.offTime)}</b><small>${escapeHtml(repeats || 'No repeat')}</small></div><span class="advanced-status ${item.enabled ? 'is-active' : ''}">${item.enabled ? 'Enabled' : 'Paused'}</span><div class="advanced-row-actions"><label class="advanced-switch"><input type="checkbox" data-schedule-enabled="${escAttr(item.id)}" aria-label="${item.enabled ? 'Pause' : 'Resume'} schedule for ${escAttr(device?.name || 'device')}"${item.enabled ? ' checked' : ''}><i></i></label><button type="button" data-edit-schedule="${escAttr(item.id)}">Edit</button><button type="button" class="advanced-delete" data-delete-schedule="${escAttr(item.id)}" aria-label="Delete schedule">×</button></div></article>`;
  }

  function renderSchedules(data) {
    const sorted = data.schedules.slice().sort((a, b) => a.onTime.localeCompare(b.onTime));
    return `${heading('dash-schedules', 'Schedules that fit your day.', 'Review one-time and repeating device rules. They are saved locally and never run automatically.', '<button type="button" class="advanced-primary-button" data-open-schedule>＋ New schedule</button>')}
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">UPCOMING PREVIEW RULES</p><h2>Device schedules <span>${sorted.length}</span></h2></div><label class="advanced-search">⌕ <input id="advanced-search" type="search" value="${escAttr(query)}" placeholder="Search schedules" aria-label="Search schedules"></label></div>
      <div class="advanced-timeline">${sorted.length ? sorted.map((item) => scheduleMarkup(item, data.devices)).join('') : '<div class="advanced-empty">No schedules saved yet. Add a one-time or repeating local rule.</div>'}</div>
      <p class="advanced-footnote">Each row shows a configured preview, not a live timer. A secure backend and device acknowledgment are required for real scheduling.</p></section>`;
  }

  function latestTelemetry(channel) {
    return energyTelemetry.readings.find((reading) => reading.channel === channel) || null;
  }

  function metricText(reading, key, unit, divisor = 1) {
    const value = reading?.values?.[key];
    if (typeof value !== 'number' || !Number.isFinite(value)) return 'Waiting for sensor data';
    return `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value / divisor)} ${unit}`;
  }

  function measuredAtText(reading) {
    if (!reading) return 'No measurement reported';
    const label = new Date(reading.measuredAt).toLocaleString();
    return `Measured ${escapeHtml(label)}`;
  }

  function renderEnergyHistory() {
    const readings = energyTelemetry.readings.slice(0, 20);
    if (!readings.length) return '<div class="advanced-empty">No timestamped readings are available yet.</div>';
    return `<div class="energy-history-table-wrap"><table class="energy-history-table"><thead><tr><th scope="col">Channel / source</th><th scope="col">Measured at</th><th scope="col">Reported values</th></tr></thead><tbody>${readings.map((reading) => {
      const values = Object.entries(reading.values).map(([name, value]) => {
        const displayed = typeof value === 'number'
          ? new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value)
          : Array.isArray(value) ? value.join(', ') : String(value);
        return `<span><b>${escapeHtml(name)}</b> ${escapeHtml(displayed)}</span>`;
      }).join('');
      const timestamp = new Date(reading.measuredAt).toLocaleString();
      return `<tr><td><b>${escapeHtml(reading.channel.replace(/_/g, ' '))}</b><small>${escapeHtml(reading.sourceId)}</small></td><td><time datetime="${escAttr(reading.measuredAt)}">${escapeHtml(timestamp)}</time><small>Received ${escapeHtml(new Date(reading.receivedAt).toLocaleString())}</small></td><td><div class="energy-history-values">${values}</div></td></tr>`;
    }).join('')}</tbody></table></div>`;
  }

  function renderEnergy(data) {
    const energyMeter = latestTelemetry('energy_meter');
    const homeLoad = latestTelemetry('home_load');
    const solar = latestTelemetry('solar');
    const battery = latestTelemetry('battery');
    const grid = latestTelemetry('grid');
    const currentPower = energyMeter?.values?.powerW !== undefined ? energyMeter : homeLoad;
    let statusTitle = 'Waiting for sensor data';
    let statusMessage = 'Connect the integration backend, then send readings from a trusted meter or gateway. No sensor is configured automatically.';
    if (energyTelemetry.status === 'loading') {
      statusTitle = 'Loading telemetry';
      statusMessage = 'Requesting timestamped measurements from the configured backend.';
    } else if (energyTelemetry.status === 'error') {
      statusTitle = 'Telemetry unavailable';
      statusMessage = energyTelemetry.error;
    } else if (energyTelemetry.status === 'empty') {
      statusTitle = 'No telemetry received yet';
      statusMessage = 'The backend is connected, but it has no timestamped meter, solar, battery, grid, or home-load readings for this home.';
    } else if (energyTelemetry.status === 'ready') {
      statusTitle = 'Backend readings available';
      statusMessage = `Showing ${energyTelemetry.readings.length} backend reading(s). Reported values are not independently verified by HOMIOT.`;
    }
    const connectAction = energyTelemetry.status === 'disconnected'
      ? '<button type="button" class="advanced-primary-button" data-advanced-route="dash-connectivity">Open device integrations</button>'
      : '';
    const refreshAction = energyTelemetry.status === 'disconnected'
      ? ''
      : '<button type="button" class="advanced-secondary-button" data-refresh-energy>Refresh readings</button>';
    return `${heading('dash-energy', 'A clearer view of energy.', 'Measured values appear here only after a trusted producer submits telemetry to the authenticated backend.', `${refreshAction}${connectAction}`)}
      <section class="energy-telemetry-summary" aria-label="Latest reported energy measurements">
        <article><span class="section-overline">HOME ENERGY TODAY</span><strong>${escapeHtml(metricText(energyMeter || homeLoad, 'energyTodayWh', 'kWh', 1000))}</strong><small>${measuredAtText(energyMeter || homeLoad)}</small></article>
        <article><span class="section-overline">CURRENT HOME POWER</span><strong>${escapeHtml(metricText(currentPower, 'powerW', 'W'))}</strong><small>${measuredAtText(currentPower)}</small></article>
        <article><span class="section-overline">SOLAR GENERATED TODAY</span><strong>${escapeHtml(metricText(solar, 'energyTodayWh', 'kWh', 1000))}</strong><small>${measuredAtText(solar)}</small></article>
        <article><span class="section-overline">BATTERY CHARGE</span><strong>${escapeHtml(metricText(battery, 'stateOfChargePercent', '%'))}</strong><small>${measuredAtText(battery)}</small></article>
        <article><span class="section-overline">GRID IMPORT TODAY</span><strong>${escapeHtml(metricText(grid, 'importTodayWh', 'kWh', 1000))}</strong><small>${measuredAtText(grid)}</small></article>
      </section>
      <section class="energy-sensor-waiting" role="status" aria-live="polite"><span class="energy-sensor-bolt" aria-hidden="true">ϟ</span><div><p class="section-overline">AUTHENTICATED BACKEND TELEMETRY</p><h2>${escapeHtml(statusTitle)}</h2><p>${escapeHtml(statusMessage)}</p></div><div class="energy-sensor-values"><span>Current usage <b>${escapeHtml(metricText(currentPower, 'powerW', 'W'))}</b></span><span>Energy today <b>${escapeHtml(metricText(energyMeter || homeLoad, 'energyTodayWh', 'kWh', 1000))}</b></span></div></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">TIMESTAMPED READINGS</p><h2>Energy and system history <span>${energyTelemetry.readings.length}</span></h2></div></div>${renderEnergyHistory()}<p class="advanced-footnote">Measured time comes from the producer; received time is recorded by the backend. No live stream or inverter-specific register mapping is configured. The separate Bill estimate page can use configured monthly grid readings and saved flat-rate assumptions.</p></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">METER AVAILABILITY</p><h2>Device energy</h2></div><button type="button" class="advanced-text-button" data-advanced-route="dash-billing">Estimate bill ↗</button></div><p class="advanced-footnote">Device power ratings and preview switch states are not energy sensor readings.</p><div class="advanced-device-energy">${data.devices.map((device) => `<article><span class="advanced-feature-icon">${device.kind === 'light' ? '☼' : '⌁'}</span><div><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.room)} · local preview state only</small></div><strong>Not measured</strong></article>`).join('')}</div></section>`;
  }

  function solarReadings(channel) {
    const readings = solarTelemetry.channels[channel] || [];
    if (!readings.length) return [];
    const latest = readings.reduce((recent, reading) => reading.measuredAt > recent.measuredAt ? reading : recent);
    return readings.filter((reading) => reading.sourceId === latest.sourceId)
      .slice()
      .sort((a, b) => a.measuredAt.localeCompare(b.measuredAt));
  }

  function solarLatest(channel) {
    const readings = solarReadings(channel);
    return readings[readings.length - 1] || null;
  }

  function solarLatestMetric(channel, metric) {
    const readings = solarReadings(channel).filter((reading) => (
      typeof reading.values?.[metric] === 'number' && Number.isFinite(reading.values[metric])
    ));
    return readings[readings.length - 1] || null;
  }

  function solarConsumptionMetric(metric) {
    return solarLatestMetric('home_load', metric) || solarLatestMetric('energy_meter', metric);
  }

  function solarKWh(reading, key) {
    const value = reading?.values?.[key];
    return typeof value === 'number' && Number.isFinite(value) ? value / 1000 : null;
  }

  function solarValue(reading, key, unit, divisor = 1) {
    const value = reading?.values?.[key];
    if (typeof value !== 'number' || !Number.isFinite(value)) return 'Waiting for sensor data';
    return `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value / divisor)} ${unit}`;
  }

  function solarTextValue(reading, key) {
    const value = reading?.values?.[key];
    if (typeof value === 'string' && value) return value;
    if (Array.isArray(value) && value.length) return value.join(', ');
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    return 'Not reported';
  }

  function utcDateKey(timestamp) {
    return new Date(timestamp).toISOString().slice(0, 10);
  }

  function solarDailyValues(readings) {
    const daily = new Map();
    readings.forEach((reading) => {
      const key = utcDateKey(reading.measuredAt);
      const current = daily.get(key);
      const value = solarKWh(reading, 'energyTodayWh');
      if (value !== null && (!current || reading.measuredAt > current.measuredAt)) {
        daily.set(key, { value, measuredAt: reading.measuredAt });
      }
    });
    return daily;
  }

  function latestPeriodValues(readings, metric, periodKey) {
    const values = new Map();
    readings.forEach((reading) => {
      const value = solarKWh(reading, metric);
      if (value === null) return;
      const key = periodKey(reading.measuredAt);
      const current = values.get(key);
      if (!current || reading.measuredAt > current.measuredAt) values.set(key, { value, measuredAt: reading.measuredAt });
    });
    return values;
  }

  function solarChartBuckets(range) {
    const solar = solarReadings('solar');
    const consumption = solarReadings('home_load').length ? solarReadings('home_load') : solarReadings('energy_meter');
    const solarDaily = solarDailyValues(solar);
    const consumptionDaily = solarDailyValues(consumption);
    const now = new Date();
    let keys;
    let labels;
    let solarPeriods;
    let consumptionPeriods;
    const solarCoverage = new Map();

    if (range === 'daily') {
      keys = Array.from({ length: 14 }, (_, index) => {
        const day = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - 13 + index));
        return day.toISOString().slice(0, 10);
      });
      labels = keys.map((key) => new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(`${key}T00:00:00Z`)));
      solarPeriods = solarDaily;
      consumptionPeriods = consumptionDaily;
    } else if (range === 'monthly') {
      keys = Array.from({ length: 12 }, (_, index) => {
        const month = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 11 + index, 1));
        return month.toISOString().slice(0, 7);
      });
      labels = keys.map((key) => new Intl.DateTimeFormat(undefined, { month: 'short', timeZone: 'UTC' }).format(new Date(`${key}-01T00:00:00Z`)));
      solarPeriods = latestPeriodValues(solar, 'energyMonthWh', (timestamp) => utcDateKey(timestamp).slice(0, 7));
      consumptionPeriods = new Map();
      keys.forEach((key) => {
        const values = [...consumptionDaily.entries()].filter(([date]) => date.startsWith(key)).map(([, item]) => item.value);
        if (values.length) consumptionPeriods.set(key, { value: values.reduce((sum, value) => sum + value, 0), coverage: values.length });
        if (!solarPeriods.has(key)) {
          const solarValues = [...solarDaily.entries()].filter(([date]) => date.startsWith(key)).map(([, item]) => item.value);
          if (solarValues.length) {
            solarPeriods.set(key, { value: solarValues.reduce((sum, value) => sum + value, 0), coverage: solarValues.length });
            solarCoverage.set(key, { count: solarValues.length, unit: 'reported day(s)' });
          }
        }
      });
    } else {
      keys = Array.from({ length: 5 }, (_, index) => String(now.getUTCFullYear() - 4 + index));
      labels = keys;
      solarPeriods = latestPeriodValues(solar, 'energyYearWh', (timestamp) => utcDateKey(timestamp).slice(0, 4));
      const solarMonths = latestPeriodValues(solar, 'energyMonthWh', (timestamp) => utcDateKey(timestamp).slice(0, 7));
      consumptionPeriods = new Map();
      keys.forEach((key) => {
        const values = [...consumptionDaily.entries()].filter(([date]) => date.startsWith(`${key}-`)).map(([, item]) => item.value);
        if (values.length) consumptionPeriods.set(key, { value: values.reduce((sum, value) => sum + value, 0), coverage: values.length });
        if (!solarPeriods.has(key)) {
          const monthlyValues = [...solarMonths.entries()].filter(([month]) => month.startsWith(`${key}-`)).map(([, item]) => item.value);
          if (monthlyValues.length) {
            solarPeriods.set(key, { value: monthlyValues.reduce((sum, value) => sum + value, 0), coverage: monthlyValues.length });
            solarCoverage.set(key, { count: monthlyValues.length, unit: 'reported month(s)' });
          }
          else {
            const dailyValues = [...solarDaily.entries()].filter(([date]) => date.startsWith(`${key}-`)).map(([, item]) => item.value);
            if (dailyValues.length) {
              solarPeriods.set(key, { value: dailyValues.reduce((sum, value) => sum + value, 0), coverage: dailyValues.length });
              solarCoverage.set(key, { count: dailyValues.length, unit: 'reported day(s)' });
            }
          }
        }
      });
    }

    return keys.map((key, index) => ({
      key,
      label: labels[index],
      solar: solarPeriods.get(key)?.value ?? null,
      consumption: consumptionPeriods.get(key)?.value ?? null,
      solarCoverage: solarCoverage.get(key)?.count || 0,
      solarCoverageUnit: solarCoverage.get(key)?.unit || '',
      consumptionCoverage: consumptionPeriods.get(key)?.coverage || 0,
    }));
  }

  function renderSolarChart() {
    const buckets = solarChartBuckets(solarRange);
    const availableValues = buckets.flatMap((bucket) => [bucket.solar, bucket.consumption]).filter((value) => value !== null);
    if (!availableValues.length) return '<div class="advanced-empty solar-chart-empty">No readings for this time range. Solar and consumption chart values will appear after the authenticated backend receives telemetry.</div>';
    const width = 900;
    const height = 260;
    const top = 18;
    const bottom = 38;
    const plotHeight = height - top - bottom;
    const max = Math.max(...availableValues, 1);
    const step = width / buckets.length;
    const barWidth = Math.min(20, step * 0.26);
    const grid = Array.from({ length: 5 }, (_, index) => {
      const y = top + plotHeight * index / 4;
      const value = max * (4 - index) / 4;
      return `<g class="solar-chart-grid"><line x1="0" y1="${y}" x2="${width}" y2="${y}"/><text x="0" y="${y - 4}">${new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(value)}</text></g>`;
    }).join('');
    const bars = buckets.map((bucket, index) => {
      const center = step * (index + .5);
      return [
        ['solar', bucket.solar, '#70d4a0', center - barWidth - 2],
        ['consumption', bucket.consumption, '#6d9cff', center + 2],
      ].map(([series, value, color, x]) => {
        if (value === null) return '';
        const barHeight = Math.max(2, value / max * (plotHeight - 8));
        const y = top + plotHeight - barHeight;
        const coverage = series === 'consumption' && bucket.consumptionCoverage
          ? ` · ${bucket.consumptionCoverage} reported day(s)`
          : series === 'solar' && bucket.solarCoverage
            ? ` · sum of ${bucket.solarCoverage} ${bucket.solarCoverageUnit}`
            : '';
        return `<rect class="solar-chart-bar ${series}" x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" rx="3" fill="${color}"><title>${escapeHtml(bucket.label)} · ${series === 'solar' ? 'Solar generation' : 'Home consumption'}: ${value.toFixed(2)} kWh${coverage}</title></rect>`;
      }).join('');
    }).join('');
    const xLabels = buckets.map((bucket, index) => `<text class="solar-chart-label" x="${step * (index + .5)}" y="${height - 10}">${escapeHtml(bucket.label)}</text>`).join('');
    const title = solarRange === 'daily' ? 'Daily energy, kilowatt-hours for the last 14 days'
      : solarRange === 'monthly' ? 'Monthly energy, kilowatt-hours for the last 12 months'
        : 'Yearly energy, kilowatt-hours for the last 5 years';
    return `<div class="solar-chart-wrap" role="region" tabindex="0" aria-label="Scrollable solar energy chart"><svg class="solar-chart-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${title}">${grid}${bars}${xLabels}</svg></div><div class="solar-chart-legend"><span><i class="solar-legend-production"></i>Solar generation</span><span><i class="solar-legend-consumption"></i>Home consumption</span></div>`;
  }

  function solarMetricCard(label, value, note, icon) {
    return `<article class="solar-metric-card solar-tone-${icon}"><span class="solar-metric-icon" aria-hidden="true">${solarIcon(icon)}</span><div><span class="section-overline">${label}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(note)}</small></div></article>`;
  }

  function solarIcon(name) {
    const icons = {
      sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>',
      bolt: '<path d="M13 2 4.5 13h6l-.5 9 9.5-12h-6z"/>',
      home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1z"/>',
      grid: '<path d="M12 3 6 21m6-18 6 18M8 9h8M6.5 15h11M4 21h16"/><path d="m8 3 4 2 4-2"/>',
      battery: '<rect x="3" y="7" width="17" height="10" rx="2"/><path d="M22 10v4M7 10v4m4-4v4"/>',
      inverter: '<rect x="4" y="3" width="16" height="18" rx="3"/><path d="m13 7-4 5h4l-2 5m-4 1h10"/>',
      chart: '<path d="M3 3v18h18"/><path d="m7 14 4-4 4 3 6-7"/>',
      savings: '<path d="M12 2v20m5-15H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
      readings: '<path d="M7 3h10l4 4v14H3V3z"/><path d="M7 3v5h10V3m-9 10h8m-8 4h8"/>',
    };
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.sun}</svg>`;
  }

  function solarSection(id, icon, eyebrow, title, description, body, className = '') {
    return `<section id="${id}" class="advanced-panel solar-section ${className}" tabindex="-1" aria-labelledby="${id}-title"><header class="solar-section-heading"><span class="solar-section-icon solar-tone-${icon}" aria-hidden="true">${solarIcon(icon)}</span><div><p class="section-overline">${eyebrow}</p><h2 id="${id}-title">${title}</h2><p>${description}</p></div></header>${body}</section>`;
  }

  function solarSectionNavigation(sections) {
    const links = [
      ['solar-overview', 'sun', 'Overview'],
      ['solar-production', 'bolt', 'Production'],
      ['solar-usage', 'home', 'Home use'],
      ['solar-grid', 'grid', 'Grid'],
      ['solar-battery', 'battery', 'Battery'],
      ['solar-inverter', 'inverter', 'Inverter'],
      ['solar-analytics', 'chart', 'Analytics'],
      ['solar-savings', 'savings', 'Savings'],
      ['solar-readings', 'readings', 'Readings'],
    ];
    return `<nav class="solar-section-nav" aria-label="Solar system sections">${links.map(([id, icon, label]) => `<button type="button" data-solar-jump="${id}"${solarActiveSection === id ? ' aria-current="location"' : ''}><span class="solar-tone-${icon}" aria-hidden="true">${solarIcon(icon)}</span>${label}</button>`).join('')}</nav><div class="solar-sections">${sections}</div>`;
  }

  function setActiveSolarSection(id) {
    solarActiveSection = id;
    document.querySelectorAll('[data-solar-jump]').forEach((button) => {
      if (button.dataset.solarJump === id) button.setAttribute('aria-current', 'location');
      else button.removeAttribute('aria-current');
    });
  }

  function updateSolarSectionFromScroll() {
    if (solarScrollFrame) return;
    solarScrollFrame = window.requestAnimationFrame(() => {
      solarScrollFrame = 0;
      if (document.querySelector('#advanced-features')?.hidden) return;
      const sections = [...document.querySelectorAll('.solar-sections .solar-section')];
      if (!sections.length) return;
      const marker = Math.min(230, window.innerHeight * .3);
      let current = sections[0];
      for (const section of sections) {
        if (section.getBoundingClientRect().top > marker) break;
        current = section;
      }
      setActiveSolarSection(current.id);
    });
  }

  function renderSolar() {
    const solar = solarLatest('solar');
    const solarPower = solarLatestMetric('solar', 'powerW');
    const solarToday = solarLatestMetric('solar', 'energyTodayWh');
    const solarMonth = solarLatestMetric('solar', 'energyMonthWh');
    const solarYear = solarLatestMetric('solar', 'energyYearWh');
    const load = solarConsumptionMetric('energyTodayWh') || solarLatest('home_load') || solarLatest('energy_meter');
    const loadPower = solarConsumptionMetric('powerW');
    const gridExport = solarLatestMetric('grid', 'exportTodayWh');
    const gridImport = solarLatestMetric('grid', 'importTodayWh');
    const battery = solarLatestMetric('battery', 'stateOfChargePercent');
    const solarVoltage = solarLatestMetric('solar', 'voltageV');
    const solarCurrent = solarLatestMetric('solar', 'currentA');
    const settings = solarTelemetry.settings;
    const todayKWh = solarKWh(solarToday, 'energyTodayWh');
    const monthKWh = solarKWh(solarMonth, 'energyMonthWh');
    const yearKWh = solarKWh(solarYear, 'energyYearWh');
    const tariff = settings?.tariffPerKWh;
    const dailyOffset = todayKWh !== null && typeof tariff === 'number' ? money(todayKWh * tariff) : 'Unavailable';
    const monthOffset = monthKWh !== null && typeof tariff === 'number' ? money(monthKWh * tariff) : 'Unavailable';
    const yearOffset = yearKWh !== null && typeof tariff === 'number' ? money(yearKWh * tariff) : 'Unavailable';
    const status = solarTelemetry.status === 'loading' ? 'Loading solar telemetry'
      : solarTelemetry.status === 'error' ? 'Solar telemetry unavailable'
        : solarTelemetry.status === 'disconnected' ? 'Backend not connected'
          : solar ? 'Backend solar readings available' : 'Waiting for solar sensor data';
    const detail = solarTelemetry.status === 'error' ? solarTelemetry.error
      : solar ? `Source ${solar.sourceId} · measured ${new Date(solar.measuredAt).toLocaleString()}`
        : 'Connect an authenticated backend and a trusted solar producer. No production values are simulated.';
    const consumptionNote = load
      ? `${load.sourceId} · measured ${new Date(load.measuredAt).toLocaleString()}`
      : 'Waiting for home-load meter data';
    const tariffNote = typeof tariff === 'number'
      ? `At saved import rate ${money(tariff)}/kWh · potential gross offset`
      : 'Configure import tariff in Bill estimate to calculate a potential value';
    const refresh = solarTelemetry.status === 'disconnected' ? '' : '<button type="button" class="advanced-secondary-button" data-refresh-solar>Refresh readings</button>';
    const inverter = solarLatest('inverter');
    const batteryCharge = solarLatestMetric('battery', 'chargePowerW');
    const batteryDischarge = solarLatestMetric('battery', 'dischargePowerW');
    const inverterPv = solarLatestMetric('inverter', 'pvInputW');
    const inverterAc = solarLatestMetric('inverter', 'acOutputW');
    const systemRows = ['solar', 'home_load', 'energy_meter', 'grid', 'battery', 'inverter'].flatMap((channel) => solarReadings(channel)).sort((a, b) => b.measuredAt.localeCompare(a.measuredAt)).slice(0, 12);
    const details = systemRows.length ? `<div class="solar-reading-list">${systemRows.map((reading) => `<article><span><b>${escapeHtml(reading.channel.replace(/_/g, ' '))} · ${escapeHtml(reading.sourceId)}</b><small>${escapeHtml(new Date(reading.measuredAt).toLocaleString())}</small></span><div>${Object.entries(reading.values).map(([key, value]) => `<span>${escapeHtml(key.replace(/([A-Z])/g, ' $1'))}<b>${escapeHtml(typeof value === 'number' ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value)} ${/Wh$/.test(key) ? 'Wh' : /W$/.test(key) ? 'W' : /V$/.test(key) ? 'V' : /A$/.test(key) ? 'A' : /Percent$/.test(key) ? '%' : ''}`.trim() : Array.isArray(value) ? value.join(', ') : String(value))}</b></span>`).join('')}</div></article>`).join('')}</div>` : '<div class="advanced-empty">No solar or inverter readings have been reported for this home yet.</div>';
    const solarSections = [
      solarSection('solar-overview', 'sun', 'SYSTEM OVERVIEW', 'Your solar system at a glance', 'Start here for today’s production, household usage, and estimated offset.', `<section class="solar-status-card solar-system-status" role="status" aria-live="polite"><span class="solar-status-icon" aria-hidden="true">${solarIcon('sun')}</span><div><p class="section-overline">RENEWABLE ENERGY · AUTHENTICATED TELEMETRY</p><h2>${escapeHtml(status)}</h2><p>${escapeHtml(detail)}</p></div><button type="button" class="advanced-text-button" data-advanced-route="dash-connectivity">Device integrations ↗</button></section><div class="solar-metric-grid solar-overview-grid">${solarMetricCard('GENERATED TODAY', solarValue(solarToday, 'energyTodayWh', 'kWh', 1000), solarToday ? `Measured ${new Date(solarToday.measuredAt).toLocaleString()}` : 'Waiting for solar sensor data', 'bolt')}${solarMetricCard('HOME USED TODAY', solarValue(load, 'energyTodayWh', 'kWh', 1000), consumptionNote, 'home')}${solarMetricCard('POTENTIAL OFFSET TODAY', dailyOffset, tariffNote, 'savings')}</div>`, 'solar-overview-section'),
      solarSection('solar-production', 'bolt', 'SOLAR PANELS', 'Production', 'Power and energy reported by your solar array.', `<div class="solar-metric-grid">${solarMetricCard('OUTPUT RIGHT NOW', solarValue(solarPower, 'powerW', 'W'), solarPower ? `Measured ${new Date(solarPower.measuredAt).toLocaleTimeString()}` : 'No solar power reported', 'sun')}${solarMetricCard('GENERATED THIS MONTH', solarValue(solarMonth, 'energyMonthWh', 'kWh', 1000), solarMonth ? `Measured ${new Date(solarMonth.measuredAt).toLocaleString()}` : 'No monthly production reported', 'chart')}${solarMetricCard('GENERATED THIS YEAR', solarValue(solarYear, 'energyYearWh', 'kWh', 1000), solarYear ? `Measured ${new Date(solarYear.measuredAt).toLocaleString()}` : 'No yearly production reported', 'chart')}${solarMetricCard('ARRAY VOLTAGE', solarValue(solarVoltage, 'voltageV', 'V'), solarVoltage ? solarVoltage.sourceId : 'No voltage reported', 'inverter')}${solarMetricCard('ARRAY CURRENT', solarValue(solarCurrent, 'currentA', 'A'), solarCurrent ? solarCurrent.sourceId : 'No current reported', 'bolt')}</div>`),
      solarSection('solar-usage', 'home', 'HOUSEHOLD', 'Home energy use', 'See the energy and live power your household meter reports.', `<div class="solar-metric-grid">${solarMetricCard('HOME ENERGY USED TODAY', solarValue(load, 'energyTodayWh', 'kWh', 1000), consumptionNote, 'home')}${solarMetricCard('HOME POWER NOW', solarValue(loadPower, 'powerW', 'W'), loadPower ? `${loadPower.sourceId} · measured ${new Date(loadPower.measuredAt).toLocaleString()}` : 'No home-load power reported', 'chart')}</div>`),
      solarSection('solar-grid', 'grid', 'UTILITY CONNECTION', 'Grid exchange', 'Track energy reported as imported from or exported to the utility grid.', `<div class="solar-metric-grid">${solarMetricCard('IMPORTED TODAY', solarValue(gridImport, 'importTodayWh', 'kWh', 1000), gridImport ? `Grid source ${gridImport.sourceId}` : 'No grid import reported', 'grid')}${solarMetricCard('EXPORTED TODAY', solarValue(gridExport, 'exportTodayWh', 'kWh', 1000), gridExport ? `Grid source ${gridExport.sourceId}` : 'No grid export reported', 'bolt')}</div>`),
      solarSection('solar-battery', 'battery', 'ENERGY STORAGE', 'Battery', 'Review reported battery charge and discharge measurements.', `<div class="solar-metric-grid">${solarMetricCard('STATE OF CHARGE', solarValue(battery, 'stateOfChargePercent', '%'), battery ? battery.sourceId : 'No battery charge reported', 'battery')}${solarMetricCard('CHARGING POWER', solarValue(batteryCharge, 'chargePowerW', 'W'), batteryCharge ? batteryCharge.sourceId : 'No charging power reported', 'bolt')}${solarMetricCard('DISCHARGING POWER', solarValue(batteryDischarge, 'dischargePowerW', 'W'), batteryDischarge ? batteryDischarge.sourceId : 'No discharging power reported', 'home')}</div>`),
      solarSection('solar-inverter', 'inverter', 'POWER CONVERSION', 'Inverter', 'View reported PV input, AC output, operating mode, status, and notices.', `<div class="solar-metric-grid">${solarMetricCard('PV INPUT', solarValue(inverterPv, 'pvInputW', 'W'), inverterPv ? inverterPv.sourceId : 'No inverter PV input reported', 'sun')}${solarMetricCard('AC OUTPUT', solarValue(inverterAc, 'acOutputW', 'W'), inverterAc ? inverterAc.sourceId : 'No inverter AC output reported', 'bolt')}${solarMetricCard('OPERATING MODE', solarTextValue(inverter, 'operatingMode'), inverter ? inverter.sourceId : 'No inverter mode reported', 'inverter')}${solarMetricCard('INVERTER STATUS', solarTextValue(inverter, 'status'), inverter ? `Reported by ${inverter.sourceId}` : 'No inverter status reported', 'readings')}</div>${inverter?.values?.faults?.length ? `<p class="solar-savings-disclaimer">Producer-reported notices: ${escapeHtml(inverter.values.faults.join(', '))}. Informational telemetry only; not safety guidance.</p>` : ''}`),
      solarSection('solar-analytics', 'chart', 'HISTORY', 'Energy analytics', 'Compare reported solar generation and household consumption over time.', `<div class="advanced-section-heading solar-chart-toolbar"><div><p class="section-overline">REPORTED HISTORY · kWh</p><h2>Generation & consumption</h2></div><div class="solar-range-switch" role="group" aria-label="Chart time range">${[['daily', 'Daily'], ['monthly', 'Monthly'], ['yearly', 'Yearly']].map(([range, label]) => `<button type="button" data-solar-range="${range}" aria-pressed="${solarRange === range}">${label}</button>`).join('')}</div></div>${renderSolarChart()}<p class="advanced-footnote">Monthly totals sum reported daily values when a monthly counter is unavailable. Yearly totals prefer annual counters, then monthly, then daily values. Missing days or months are not filled or counted as zero, so aggregates may be incomplete. All timestamps are grouped in UTC.</p>`, 'solar-chart-panel'),
      solarSection('solar-savings', 'savings', 'TARIFF ESTIMATE', 'Potential bill offset', 'An illustrative value calculated from production and your saved import rate.', `<div class="solar-metric-grid">${solarMetricCard('POTENTIAL OFFSET · TODAY', dailyOffset, tariffNote, 'savings')}${solarMetricCard('POTENTIAL OFFSET · MONTH', monthOffset, tariffNote, 'savings')}${solarMetricCard('POTENTIAL OFFSET · YEAR', yearOffset, tariffNote, 'savings')}</div><p class="solar-savings-disclaimer">This is a potential gross offset, not a utility bill or realized savings. It assumes every generated kWh replaces grid purchases and excludes exports, battery losses, utility tiers, taxes, and measured self-consumption.</p>`),
      solarSection('solar-readings', 'readings', 'TELEMETRY', 'Latest system readings', 'Source-by-source values received from your authenticated telemetry backend.', `<div class="advanced-section-heading solar-reading-toolbar"><span></span><button type="button" class="advanced-text-button" data-advanced-route="dash-billing">Configure tariff ↗</button></div>${details}`),
    ].join('');

    return `${heading('dash-solar', 'Solar energy, clearly measured.', 'Track your solar panels, household use, grid, battery and system analytics.', refresh)}
      ${solarSectionNavigation(solarSections)}
      <section id="solar-overview-legacy" class="solar-status-card" role="status" aria-live="polite"><span class="solar-status-icon" aria-hidden="true">${solarIcon('sun')}</span><div><p class="section-overline">RENEWABLE ENERGY · AUTHENTICATED TELEMETRY</p><h2>${escapeHtml(status)}</h2><p>${escapeHtml(detail)}</p></div><button type="button" class="advanced-text-button" data-advanced-route="dash-connectivity">Device integrations ↗</button></section>
      <section class="solar-metric-grid solar-overview-metrics" aria-label="Solar system summary">
        ${solarMetricCard('SOLAR GENERATED TODAY', solarValue(solarToday, 'energyTodayWh', 'kWh', 1000), solarToday ? `Measured ${new Date(solarToday.measuredAt).toLocaleString()}` : 'Waiting for solar sensor data', 'bolt')}
        ${solarMetricCard('HOME ENERGY USED TODAY', solarValue(load, 'energyTodayWh', 'kWh', 1000), consumptionNote, 'home')}
        ${solarMetricCard('POTENTIAL OFFSET TODAY', dailyOffset, tariffNote, 'savings')}
      </section>
      <section id="solar-analytics-legacy" class="advanced-panel solar-chart-panel"><div class="advanced-section-heading"><div><p class="section-overline">REPORTED ENERGY HISTORY · kWh</p><h2>${solarIcon('chart')}Generation & consumption</h2></div><div class="solar-range-switch" role="group" aria-label="Chart time range">${[['daily', 'Daily'], ['monthly', 'Monthly'], ['yearly', 'Yearly']].map(([range, label]) => `<button type="button" data-solar-range="${range}" aria-pressed="${solarRange === range}">${label}</button>`).join('')}</div></div>${renderSolarChart()}<p class="advanced-footnote">Solar uses the producer's daily, monthly, or yearly counter when available. Otherwise, monthly totals sum reported daily values and yearly totals sum reported monthly values (or daily values if monthly counters are absent). Home consumption sums only days with readings. Missing days or months are not filled or counted as zero, so aggregated periods may be incomplete. All timestamps are grouped in UTC.</p></section>
      <section class="advanced-panel solar-flow-panel"><div class="advanced-section-heading"><div><p class="section-overline">ENERGY FLOW DETAILS</p><h2>What is reported for your home</h2></div></div><div class="solar-flow-grid"><article><span>Solar current</span><b>${escapeHtml(solarValue(solarPower, 'powerW', 'W'))}</b><small>${solarPower ? escapeHtml(new Date(solarPower.measuredAt).toLocaleString()) : 'No reading'}</small></article><article><span>Home load current</span><b>${escapeHtml(solarValue(loadPower, 'powerW', 'W'))}</b><small>${loadPower ? escapeHtml(new Date(loadPower.measuredAt).toLocaleString()) : 'No reading'}</small></article><article><span>Inverter PV input</span><b>${escapeHtml(solarValue(inverterPv, 'pvInputW', 'W'))}</b><small>${inverterPv ? escapeHtml(inverterPv.sourceId) : 'No reading'}</small></article><article><span>Inverter AC output</span><b>${escapeHtml(solarValue(inverterAc, 'acOutputW', 'W'))}</b><small>${inverterAc ? escapeHtml(inverterAc.sourceId) : 'No reading'}</small></article><article><span>Grid import today</span><b>${escapeHtml(solarValue(gridImport, 'importTodayWh', 'kWh', 1000))}</b><small>${gridImport ? escapeHtml(gridImport.sourceId) : 'No reading'}</small></article><article><span>Grid exported today</span><b>${escapeHtml(solarValue(gridExport, 'exportTodayWh', 'kWh', 1000))}</b><small>${gridExport ? escapeHtml(gridExport.sourceId) : 'No reading'}</small></article><article><span>Battery state of charge</span><b>${escapeHtml(solarValue(battery, 'stateOfChargePercent', '%'))}</b><small>${battery ? escapeHtml(battery.sourceId) : 'No reading'}</small></article><article><span>Battery charging power</span><b>${escapeHtml(solarValue(batteryCharge, 'chargePowerW', 'W'))}</b><small>${batteryCharge ? escapeHtml(batteryCharge.sourceId) : 'No reading'}</small></article><article><span>Battery discharging power</span><b>${escapeHtml(solarValue(batteryDischarge, 'dischargePowerW', 'W'))}</b><small>${batteryDischarge ? escapeHtml(batteryDischarge.sourceId) : 'No reading'}</small></article><article><span>Inverter mode / status</span><b>${escapeHtml(solarTextValue(inverter, 'operatingMode'))} / ${escapeHtml(solarTextValue(inverter, 'status'))}</b><small>${inverter ? escapeHtml(inverter.sourceId) : 'No reading'}</small></article><article><span>Solar array voltage</span><b>${escapeHtml(solarValue(solarVoltage, 'voltageV', 'V'))}</b><small>${solarVoltage ? escapeHtml(solarVoltage.sourceId) : 'No reading'}</small></article><article><span>Solar array current</span><b>${escapeHtml(solarValue(solarCurrent, 'currentA', 'A'))}</b><small>${solarCurrent ? escapeHtml(solarCurrent.sourceId) : 'No reading'}</small></article></div>${inverter?.values?.faults?.length ? `<p class="solar-savings-disclaimer">Producer-reported inverter notices: ${escapeHtml(inverter.values.faults.join(', '))}. These are informational telemetry only and are not safety guidance.</p>` : ''}</section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">LATEST SYSTEM MEASUREMENTS</p><h2>Solar & inverter readings</h2></div><button type="button" class="advanced-text-button" data-advanced-route="dash-billing">Configure tariff ↗</button></div>${details}<p class="solar-savings-disclaimer">Potential bill offset is solar generation multiplied by the saved grid-import rate. It is an upper-bound illustration that assumes all production replaces grid purchases; it is not measured bill savings and excludes export credits, battery losses, tariff tiers, taxes, and actual self-consumption.</p></section>`;
  }

  function renderBackendBilling() {
    const saved = billingData.settings;
    let estimateMarkup = '<p class="advanced-footnote">Waiting for a backend estimate.</p>';
    if (billingData.status === 'disconnected') {
      estimateMarkup = '<div class="advanced-empty">Connect an authorized backend to configure a tariff and read measured monthly grid totals.</div>';
    } else if (billingData.status === 'loading') {
      estimateMarkup = '<div class="advanced-empty" role="status">Loading tariff settings and measured grid data…</div>';
    } else if (billingData.status === 'error') {
      estimateMarkup = `<div class="advanced-empty is-error" role="alert">${escapeHtml(billingData.error)}</div>`;
    } else if (!saved) {
      estimateMarkup = '<div class="advanced-empty">No tariff is configured. Enter the rates and charges confirmed for your utility; HOMIOT will not choose defaults.</div>';
    } else if (!billingData.estimate) {
      const message = billingData.reason === 'monthly_grid_export_unavailable'
        ? `Waiting for monthly export readings from ${saved.gridSourceId}; the configured export rate is not treated as zero.`
        : `Waiting for a monthly grid import reading from ${saved.gridSourceId}. Missing readings are not estimated as zero.`;
      estimateMarkup = `<div class="advanced-empty">${escapeHtml(message)}</div>`;
    } else {
      const estimate = billingData.estimate;
      const exportLine = estimate.exportKWh === null
        ? '<div class="advanced-bill-line"><span>Export credit</span><b>Not reported</b></div>'
        : `<div class="advanced-bill-line"><span>Grid export · credit</span><b>${estimate.exportKWh.toFixed(2)} kWh · −${money(estimate.exportCredit)}</b></div>`;
      estimateMarkup = `<div class="advanced-actual-bill"><p class="section-overline">MONTHLY FLAT-RATE ESTIMATE</p><h3>Estimated energy total</h3><strong>${money(estimate.total)}</strong><small>Grid meter ${escapeHtml(estimate.sourceId)} · measured ${escapeHtml(new Date(estimate.measuredAt).toLocaleString())}</small><div class="advanced-bill-line"><span>Grid import</span><b>${estimate.importKWh.toFixed(2)} kWh · ${money(estimate.importCost)}</b></div>${exportLine}<div class="advanced-bill-line"><span>Fixed charges</span><b>${money(estimate.fixedCharges)}</b></div><div class="advanced-bill-line"><span>Additional charges</span><b>${money(estimate.additionalCharges)}</b></div><p>This is an estimate based on submitted backend telemetry and your saved flat rates, not a utility bill. It excludes tiered pricing, taxes, and non-calendar billing periods.</p></div>`;
    }

    const connectAction = billingData.status === 'disconnected'
      ? '<button type="button" class="advanced-primary-button" data-advanced-route="dash-connectivity">Connect backend</button>'
      : '<button type="button" class="advanced-secondary-button" data-refresh-billing>Refresh estimate</button>';
    const settingsFields = billingData.status === 'disconnected'
      ? ''
      : `<form class="advanced-bill-form backend-billing-form" id="backend-billing-form">
        <label>Grid meter source ID<input name="gridSourceId" type="text" maxlength="160" value="${escAttr(saved?.gridSourceId || '')}" placeholder="Exact source ID from telemetry" required><small>Must match a source reporting the grid channel.</small></label>
        <label>Import tariff<input name="tariffPerKWh" type="number" min="0" max="100000" step="0.01" value="${saved ? saved.tariffPerKWh : ''}" required><small>₹ per imported kWh</small></label>
        <label>Export tariff<input name="exportTariffPerKWh" type="number" min="0" max="100000" step="0.01" value="${saved ? saved.exportTariffPerKWh : ''}" required><small>₹ credit per exported kWh</small></label>
        <label>Fixed charges<input name="fixedCharges" type="number" min="0" max="1000000" step="0.01" value="${saved ? saved.fixedCharges : ''}" required><small>₹ per calendar month</small></label>
        <label>Additional charges<input name="additionalCharges" type="number" min="0" max="1000000" step="0.01" value="${saved ? saved.additionalCharges : ''}" required><small>₹ per calendar month</small></label>
        <button class="advanced-primary-button" type="submit">Save tariff settings</button><p class="advanced-form-error" id="backend-billing-error" aria-live="polite"></p>
      </form>`;
    return `<section class="advanced-panel backend-billing-panel"><div class="advanced-section-heading"><div><p class="section-overline">MEASURED GRID DATA · BACKEND</p><h2>Home bill estimate</h2></div>${connectAction}</div>${estimateMarkup}<details class="backend-billing-settings"${!saved && billingData.status === 'ready' ? ' open' : ''}><summary>Configure monthly tariff assumptions</summary>${settingsFields}    <p class="advanced-footnote">Values are stored for this authorized home on the backend. The estimate uses the selected source's latest readings from the current UTC calendar month.</p></details></section>`;
  }

  function renderBilling(data) {
    const settings = data.settings;
    const units = settings.dailyKwh * settings.billingDays;
    const energyCost = units * settings.tariff;
    const estimate = energyCost + settings.fixedCharges + settings.additionalCharges;
    return `${heading('dash-billing', 'Estimate your electricity bill.', 'Compare a separate local demo projection with an estimate based on configured tariff assumptions and measured grid data.', '<button type="button" class="advanced-secondary-button" data-refresh-billing>Refresh backend estimate</button>')}
      ${renderBackendBilling()}
      <div class="advanced-billing-layout"><section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">LOCAL DEMO ASSUMPTIONS</p><h2>Preview projection</h2></div><span class="advanced-demo-pill">SIMULATED INPUTS</span></div>
      <form class="advanced-bill-form" id="bill-form"><label>Energy tariff<input name="tariff" type="number" min="0" max="100000" step="0.01" value="${settings.tariff}" required><small>₹ per kWh · demo</small></label><label>Daily consumption<input name="dailyKwh" type="number" min="0" max="10000" step="0.01" value="${settings.dailyKwh}" required><small>kWh per day · demo estimate</small></label><label>Billing period<input name="billingDays" type="number" min="1" max="366" step="1" value="${settings.billingDays}" required><small>Days in this estimate</small></label><label>Fixed charges<input name="fixedCharges" type="number" min="0" max="1000000" step="0.01" value="${settings.fixedCharges}" required><small>₹ per billing period · demo</small></label><label>Additional charges<input name="additionalCharges" type="number" min="0" max="1000000" step="0.01" value="${settings.additionalCharges}" required><small>₹ per billing period · demo</small></label><button class="advanced-primary-button" type="submit">Update local estimate</button><p class="advanced-form-error" id="bill-error" aria-live="polite"></p></form></section>
      <section class="advanced-bill-result"><p class="section-overline">LOCAL DEMO ESTIMATE</p><h2>Projected bill</h2><strong>${money(estimate)}</strong><small>For ${settings.billingDays} days · demo inputs</small><div class="advanced-bill-line"><span>Units consumed</span><b>${units.toFixed(1)} kWh</b></div><div class="advanced-bill-line"><span>Energy charge</span><b>${money(energyCost)}</b></div><div class="advanced-bill-line"><span>Fixed + additional</span><b>${money(settings.fixedCharges + settings.additionalCharges)}</b></div><div class="advanced-bill-line"><span>Daily average cost</span><b>${money(estimate / settings.billingDays)}</b></div><div class="advanced-bill-line is-total"><span>30-day projection</span><b>${money(settings.dailyKwh * 30 * settings.tariff + settings.fixedCharges + settings.additionalCharges)}</b></div><p>Estimate only. Actual bills can include tariff slabs, taxes, duties, and other utility charges.</p></section></div>`;
  }

  function sceneCard(scene, devices, custom = false) {
    const selected = scene.actions?.map((action) => devices.find((device) => device.id === action.deviceId)?.name).filter(Boolean) || [];
    return `<article class="advanced-card scene-preview-card" data-scene-id="${escAttr(scene.id)}"><div class="advanced-card-top"><span class="advanced-feature-icon">${escapeHtml(scene.icon || '✦')}</span>${custom ? `<div class="scene-card-actions"><button type="button" data-edit-scene="${escAttr(scene.id)}" aria-label="Edit ${escAttr(scene.name)}">Edit</button><button type="button" class="advanced-delete" data-delete-scene="${escAttr(scene.id)}" aria-label="Delete ${escAttr(scene.name)}">×</button></div>` : ''}</div><h3>${escapeHtml(scene.name)}</h3><p>${escapeHtml(scene.description)}</p><small class="scene-device-names">${escapeHtml(selected.length ? selected.join(' · ') : scene.type === 'off' ? 'Online demo devices' : 'Selected home devices')}</small><button type="button" class="advanced-primary-button" data-activate-scene="${escAttr(scene.id)}">Activate preview</button></article>`;
  }

  function renderScenes(data) {
    return `${heading('dash-scenes', 'One tap, a different mood.', 'Preview scene actions against your shared device state. Offline devices are skipped and reported.', '<button type="button" class="advanced-primary-button" data-create-scene>＋ Create scene</button>')}
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">READY WHEN YOU ARE</p><h2>Preset scenes</h2></div></div><div class="advanced-card-grid scenes-grid">${data.presets.map((scene) => sceneCard(scene, data.devices)).join('')}</div></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">MADE FOR YOUR HOME</p><h2>Custom scenes</h2></div></div><div class="advanced-card-grid scenes-grid">${data.customScenes.length ? data.customScenes.map((scene) => sceneCard(scene, data.devices, true)).join('') : '<div class="advanced-empty">Create a custom preview scene with the devices you choose.</div>'}</div></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">PREVIEW LOG</p><h2>Recent scene and automation actions</h2></div></div>${historyMarkup({ ...data, history: data.history.filter((item) => !item.ruleId) })}</section>`;
  }

  function notificationItem(item) {
    return `<article class="advanced-notification ${item.type}${item.read ? ' is-read' : ''}"><span class="notification-symbol">${item.type === 'warning' ? '!' : item.type === 'success' ? '✓' : 'i'}</span><div><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.message)}</p><small>${new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(item.createdAt))} · demo</small></div><button type="button" data-read-notice="${escAttr(item.id)}" aria-label="${item.read ? 'Mark unread' : 'Mark read'}">${item.read ? '↶' : '✓'}</button></article>`;
  }

  function renderNotifications(data) {
    const unread = data.notifications.filter((item) => !item.read).length;
    return `${heading('dash-notifications', 'A thoughtful home update.', 'See local demo events and choose which preview alerts to keep visible.', '<button type="button" class="advanced-text-button" data-mark-all-read>Mark all read</button>')}
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">LOCAL PREVIEW EVENTS</p><h2>Notifications <span>${unread} unread</span></h2></div><button type="button" class="advanced-text-button" data-clear-notices>Clear all</button></div>
      <div class="advanced-notification-list">${data.notifications.length ? data.notifications.map(notificationItem).join('') : '<div class="advanced-empty">You are all caught up. Use “Create demo alert” to preview an alert.</div>'}</div>
      <button type="button" class="advanced-secondary-button" data-create-notice>Create demo alert</button></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">PREFERENCES</p><h2>Alert preferences</h2></div></div><div class="advanced-preferences">${[['deviceAlerts', 'Device state changes'], ['energyAlerts', 'Energy demo alerts'], ['securityAlerts', 'Security preview alerts']].map(([key, label]) => `<label>${label}<input type="checkbox" data-notification-setting="${key}"${data.settings[key] ? ' checked' : ''}></label>`).join('')}</div><p class="advanced-footnote">Preferences apply to this browser demo only. No push or email notifications are sent.</p></section>`;
  }

  function memberCard(member, devices) {
    const isOwner = member.role === 'Owner';
    const all = member.devices.includes('all');
    return `<article class="advanced-family-card"><div class="family-person"><span class="family-avatar">${escapeHtml(member.name.split(/\s+/).map((word) => word[0]).slice(0, 2).join('').toUpperCase())}</span><div><b>${escapeHtml(member.name)}</b><small>${escapeHtml(member.email)}</small></div><span class="family-status">${escapeHtml(member.status)}</span></div><div class="family-permission"><label>Permission<select data-member-role="${escAttr(member.id)}"${isOwner ? ' disabled' : ''}>${['Owner', 'Administrator', 'Member', 'Guest'].map((role) => `<option${role === member.role ? ' selected' : ''}>${role}</option>`).join('')}</select></label><button type="button" class="advanced-delete" data-remove-member="${escAttr(member.id)}"${isOwner ? ' disabled' : ''}>Revoke</button></div><fieldset class="family-device-access"><legend>${isOwner ? 'Owner has full demo access' : 'Permitted demo devices'}</legend>${isOwner ? '<small>Role examples only; not enforced authorization.</small>' : devices.map((device) => `<label><input type="checkbox" data-member-device="${escAttr(member.id)}" data-device-id="${escAttr(device.id)}"${all || member.devices.includes(device.id) ? ' checked' : ''}>${escapeHtml(device.name)}</label>`).join('')}</fieldset></article>`;
  }

  function renderFamily(data) {
    const profile = window.SmartNestSettingsService?.getSnapshot().profile;
    const members = data.members.map((member) => member.id === 'member-owner' && profile
      ? { ...member, name: profile.preferredName || profile.name, email: profile.email }
      : member);
    return `${heading('dash-family', 'Your home, shared thoughtfully.', 'Manage example household roles and device access in this browser only.', '<button type="button" class="advanced-primary-button" data-invite-member>＋ Add member</button>')}
      <div class="family-role-grid">${[['Owner', 'Full example control'], ['Administrator', 'Manage preview devices and routines'], ['Member', 'Control assigned demo appliances'], ['Guest', 'Limited sample access']].map(([role, desc]) => `<article><b>${role}</b><small>${desc}</small></article>`).join('')}</div>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">HOUSEHOLD PREVIEW</p><h2>Family members <span>${members.length}</span></h2></div></div><div class="advanced-family-grid">${members.map((member) => memberCard(member, data.devices)).join('')}</div><p class="advanced-footnote">These roles are presentation-only. Enforce real permissions on a trusted backend before connecting hardware.</p></section>`;
  }

  function renderSecurity(data) {
    const online = data.devices.filter((device) => device.online).length;
    const offline = data.devices.length - online;
    return `${heading('dash-security', 'A security status preview.', 'View simulated connectivity and sensor indicators; this is not a security or alarm system.')}
      <div class="security-status-grid"><article><span class="advanced-feature-icon">⌂</span><div><small>Home connection</small><b>Local preview</b><em>No gateway connected</em></div></article><article><span class="advanced-feature-icon">⌁</span><div><small>Device connectivity</small><b>${online} demo online · ${offline} offline</b><em>Connection is not hardware verified</em></div></article><article><span class="advanced-feature-icon">◈</span><div><small>Door sensor</small><b>${escapeHtml(data.security.door === 'closed' ? 'Closed · simulated' : 'Open · simulated')}</b><em>No physical sensor linked</em></div><button type="button" class="advanced-secondary-button" data-toggle-door>Simulate ${data.security.door === 'closed' ? 'open' : 'closed'}</button></article><article><span class="advanced-feature-icon">◉</span><div><small>Motion sensor</small><b>${escapeHtml(data.security.motion === 'clear' ? 'Clear · simulated' : 'Motion · simulated')}</b><em>No physical sensor linked</em></div><button type="button" class="advanced-secondary-button" data-toggle-motion>Simulate ${data.security.motion === 'clear' ? 'motion' : 'clear'}</button></article></div>
      <section class="security-away-card"><div><p class="section-overline">PREVIEW SCENE</p><h2>${data.security.awayMode ? 'Away preview is active' : 'Home is in stay preview'}</h2><p>${data.security.awayMode ? 'Available demo appliances were switched off locally; no sensor is monitoring your home.' : 'Away preview can switch off available devices locally. It does not activate a real alarm.'}</p></div><button type="button" class="${data.security.awayMode ? 'advanced-secondary-button' : 'advanced-primary-button'}" data-away-mode>${data.security.awayMode ? 'End away preview' : 'Activate away preview'}</button></section>
      <section class="advanced-panel"><div class="advanced-section-heading"><div><p class="section-overline">ALERT HISTORY</p><h2>Recent security and connection updates</h2></div></div><div class="advanced-notification-list">${data.notifications.filter((item) => /offline|security|door|motion|away/i.test(`${item.title} ${item.message}`)).map(notificationItem).join('') || '<div class="advanced-empty">No security-related demo alerts recorded.</div>'}</div><label class="security-alert-preference">Security preview alerts<input type="checkbox" data-notification-setting="securityAlerts"${data.settings.securityAlerts ? ' checked' : ''}></label><p class="advanced-footnote">No physical sensors, alarm response, or safety monitoring is connected or provided.</p></section>`;
  }

  function render() {
    if (!activeRoute || !routes[activeRoute]) return;
    let data;
    try {
      data = snapshot();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Advanced preview data could not be loaded.', true);
      return;
    }
    const views = {
      'dash-automation': () => renderAutomations(data),
      'dash-schedules': () => renderSchedules(data),
      'dash-energy': () => renderEnergy(data),
      'dash-billing': () => renderBilling(data),
      'dash-solar': () => renderSolar(),
      'dash-scenes': () => renderScenes(data),
      'dash-notifications': () => renderNotifications(data),
      'dash-family': () => renderFamily(data),
      'dash-security': () => renderSecurity(data),
    };
    content.innerHTML = views[activeRoute]();
    root.dataset.route = activeRoute;
    const searchInput = content.querySelector('#advanced-search');
    if (searchInput && query) filterItems(query);
  }

  async function loadEnergyTelemetry() {
    const requestId = ++energyTelemetryRequest;
    const client = window.HomiotConnectivityClient;
    if (!client || !client.getSnapshot().connected || typeof client.readTelemetry !== 'function') {
      energyTelemetry = { status: 'disconnected', readings: [], error: '' };
      if (activeRoute === 'dash-energy') render();
      return;
    }

    energyTelemetry = { status: 'loading', readings: energyTelemetry.readings, error: '' };
    if (activeRoute === 'dash-energy') render();
    try {
      const result = await client.readTelemetry({ limit: 100 });
      if (requestId !== energyTelemetryRequest) return;
      energyTelemetry = {
        status: result.available ? 'ready' : 'empty',
        readings: result.readings,
        error: '',
      };
    } catch (error) {
      if (requestId !== energyTelemetryRequest) return;
      energyTelemetry = {
        status: 'error',
        readings: [],
        error: error instanceof Error ? error.message : 'The backend telemetry request failed.',
      };
    }
    if (activeRoute === 'dash-energy') render();
  }

  async function loadBillingData() {
    const requestId = ++billingRequest;
    const client = window.HomiotConnectivityClient;
    if (!client || !client.getSnapshot().connected || typeof client.readBillingEstimate !== 'function') {
      billingData = { status: 'disconnected', settings: null, estimate: null, reason: '', error: '' };
      if (activeRoute === 'dash-billing') render();
      return;
    }

    billingData = { status: 'loading', settings: null, estimate: null, reason: '', error: '' };
    if (activeRoute === 'dash-billing') render();
    try {
      const result = await client.readBillingEstimate();
      if (requestId !== billingRequest) return;
      billingData = {
        status: 'ready',
        settings: result.settings,
        estimate: result.available ? result.estimate : null,
        reason: result.reason || '',
        error: '',
      };
    } catch (error) {
      if (requestId !== billingRequest) return;
      billingData = {
        ...billingData,
        status: 'error',
        estimate: null,
        error: error instanceof Error ? error.message : 'The backend billing request failed.',
      };
    }
    if (activeRoute === 'dash-billing') render();
  }

  async function loadSolarTelemetry() {
    const requestId = ++solarRequest;
    const client = window.HomiotConnectivityClient;
    if (!client || !client.getSnapshot().connected || typeof client.readTelemetry !== 'function') {
      solarTelemetry = { status: 'disconnected', channels: {}, settings: null, error: '' };
      if (activeRoute === 'dash-solar') render();
      return;
    }

    solarTelemetry = { status: 'loading', channels: solarTelemetry.channels, settings: solarTelemetry.settings, error: '' };
    if (activeRoute === 'dash-solar') render();
    try {
      const [solar, homeLoad, energyMeter, grid, battery, inverter, billing] = await Promise.all([
        client.readTelemetry({ channel: 'solar', limit: 500 }),
        client.readTelemetry({ channel: 'home_load', limit: 500 }),
        client.readTelemetry({ channel: 'energy_meter', limit: 500 }),
        client.readTelemetry({ channel: 'grid', limit: 500 }),
        client.readTelemetry({ channel: 'battery', limit: 500 }),
        client.readTelemetry({ channel: 'inverter', limit: 500 }),
        client.readBillingEstimate(),
      ]);
      if (requestId !== solarRequest) return;
      solarTelemetry = {
        status: solar.readings.length ? 'ready' : 'empty',
        channels: {
          solar: solar.readings,
          home_load: homeLoad.readings,
          energy_meter: energyMeter.readings,
          grid: grid.readings,
          battery: battery.readings,
          inverter: inverter.readings,
        },
        settings: billing.settings,
        error: '',
      };
    } catch (error) {
      if (requestId !== solarRequest) return;
      solarTelemetry = {
        status: 'error',
        channels: {},
        settings: null,
        error: error instanceof Error ? error.message : 'The solar telemetry request failed.',
      };
    }
    if (activeRoute === 'dash-solar') render();
  }

  function filterItems(value) {
    query = value.trim().toLowerCase();
    content.querySelectorAll('[data-advanced-item]').forEach((item) => {
      item.hidden = !item.dataset.name.toLowerCase().includes(query);
    });
  }

  function updateRuleFormVisibility() {
    const form = document.querySelector('#automation-form');
    if (!form) return;
    const trigger = form.elements.triggerType.value;
    const condition = form.elements.condition.value;
    const action = form.elements.actionType.value;
    form.querySelector('[data-rule-time]').hidden = trigger !== 'TIME';
    form.querySelector('[data-rule-threshold]').hidden = !['SENSOR_VALUE', 'ENERGY_THRESHOLD'].includes(trigger);
    form.querySelector('[data-rule-device]').hidden = trigger !== 'DEVICE_STATE';
    form.querySelector('[data-rule-condition-device]').hidden = !['DEVICE_ON', 'DEVICE_OFF'].includes(condition);
    form.querySelector('[data-rule-condition-value]').hidden = !['ENERGY_ABOVE', 'TEMPERATURE_ABOVE'].includes(condition);
    form.querySelector('[data-rule-action-value]').hidden = !action.startsWith('SET_');
    const bounds = action === 'SET_TEMPERATURE' ? [16, 75] : action === 'SET_FAN_SPEED' ? [1, 5] : [0, 100];
    form.elements.actionValue.min = bounds[0];
    form.elements.actionValue.max = bounds[1];
    form.elements.actionValue.value = Math.max(bounds[0], Math.min(bounds[1], Number(form.elements.actionValue.value) || bounds[0]));
  }

  function openAutomation(rule) {
    const form = document.querySelector('#automation-form');
    form.reset();
    const devices = devicesService.getDevices();
    for (const name of ['actionDevice', 'triggerDevice', 'conditionDevice']) {
      form.elements[name].innerHTML = deviceOptions(devices);
    }
    if (devices[0]) form.elements.actionDevice.options[0].selected = true;
    form.elements.id.value = rule?.id || '';
    document.querySelector('#automation-dialog-title').textContent = rule ? 'Edit automation' : 'Create automation';
    document.querySelector('#automation-error').textContent = '';
    if (rule) {
      form.elements.name.value = rule.name;
      form.elements.triggerType.value = rule.trigger.type;
      form.elements.triggerTime.value = rule.trigger.type === 'TIME' ? rule.trigger.value : '06:00';
      form.elements.threshold.value = rule.trigger.value || 5;
      form.elements.triggerDevice.value = rule.trigger.deviceId || devices[0]?.id || '';
      form.elements.condition.value = rule.condition;
      form.elements.conditionDevice.value = rule.conditionDeviceId || devices[0]?.id || '';
      form.elements.conditionValue.value = rule.conditionValue ?? 5;
      const action = rule.actions[0];
      const selectedActionIds = new Set(rule.actions.map((item) => item.deviceId));
      [...form.elements.actionDevice.options].forEach((option) => { option.selected = selectedActionIds.has(option.value); });
      if (action?.settings) {
        const [key, value] = Object.entries(action.settings)[0] || [];
        const actionNames = { brightness: 'SET_BRIGHTNESS', temperature: 'SET_TEMPERATURE', speed: 'SET_FAN_SPEED', fanSpeed: 'SET_FAN_SPEED' };
        form.elements.actionType.value = actionNames[key] || (action.on ? 'ON' : 'OFF');
        form.elements.actionValue.value = value ?? 50;
      } else {
        form.elements.actionType.value = action?.on ? 'ON' : 'OFF';
      }
    }
    updateRuleFormVisibility();
    document.querySelector('#automation-dialog').showModal();
  }

  function openScene(scene = null) {
    const form = document.querySelector('#scene-form');
    form.elements.id.value = scene?.id || '';
    form.elements.name.value = scene?.name || '';
    form.elements.description.value = scene?.description || '';
    const actions = new Map((scene?.actions || []).map((action) => [action.deviceId, action]));
    const deviceList = form.querySelector('#scene-device-list');
    const devices = devicesService.getDevices();
    deviceList.innerHTML = devices.length ? devices.map((device) => {
      const action = actions.get(device.id);
      const inputId = `scene-device-${device.id}`;
      return `<div class="scene-device-option"><label for="${escAttr(inputId)}"><input id="${escAttr(inputId)}" type="checkbox" name="sceneDevice" value="${escAttr(device.id)}"${action ? ' checked' : ''}><span><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.room)} · ${escapeHtml(device.kind)}</small></span></label><select data-scene-state="${escAttr(device.id)}" aria-label="State for ${escAttr(device.name)}"${action ? '' : ' disabled'}><option value="true"${action?.on ? ' selected' : ''}>On</option><option value="false"${action && !action.on ? ' selected' : ''}>Off</option></select></div>`;
    }).join('') : '<p class="advanced-empty">Add a local preview device before creating a scene.</p>';
    document.querySelector('#scene-dialog h2').textContent = scene ? 'Edit your custom scene' : 'Create a custom scene';
    form.querySelector('[type="submit"]').textContent = scene ? 'Save scene changes' : 'Save custom scene';
    document.querySelector('#scene-error').textContent = '';
    document.querySelector('#scene-dialog').showModal();
  }

  function handleClick(event) {
    const solarJump = event.target.closest('[data-solar-jump]');
    if (solarJump) {
      const section = document.getElementById(solarJump.dataset.solarJump);
      if (section) {
        setActiveSolarSection(section.id);
        section.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
        section.focus({ preventScroll: true });
      }
      return;
    }
    const nav = event.target.closest('[data-advanced-route]');
    if (nav) {
      window.setRoute(nav.dataset.advancedRoute);
      return;
    }
    if (event.target.closest('[data-refresh-energy]')) {
      loadEnergyTelemetry();
      return;
    }
    if (event.target.closest('[data-refresh-billing]')) {
      loadBillingData();
      return;
    }
    if (event.target.closest('[data-refresh-solar]')) {
      loadSolarTelemetry();
      return;
    }
    const solarRangeButton = event.target.closest('[data-solar-range]');
    if (solarRangeButton) {
      solarRange = solarRangeButton.dataset.solarRange;
      render();
      return;
    }
    if (event.target.closest('[data-create-rule]')) { openAutomation(); return; }
    if (event.target.closest('[data-open-schedule]')) {
      window.setRoute('dash-devices');
      window.setTimeout(() => document.querySelector('[data-open-schedule]')?.click(), 0);
      return;
    }
    if (event.target.closest('[data-create-scene]')) {
      openScene();
      return;
    }
    const editScene = event.target.closest('[data-edit-scene]');
    if (editScene) {
      openScene(snapshot().customScenes.find((scene) => scene.id === editScene.dataset.editScene));
      return;
    }
    if (event.target.closest('[data-invite-member]')) {
      document.querySelector('#family-error').textContent = '';
      document.querySelector('#family-dialog').showModal();
      return;
    }
    if (event.target.closest('[data-close-dialog]')) {
      document.querySelector(`#${event.target.closest('[data-close-dialog]').dataset.closeDialog}`).close();
      return;
    }
    const edit = event.target.closest('[data-edit-rule]');
    if (edit) { openAutomation(snapshot().automations.find((rule) => rule.id === edit.dataset.editRule)); return; }
    const runRule = event.target.closest('[data-run-rule]');
    if (runRule) {
      const result = run(() => service.executeAutomation(runRule.dataset.runRule));
      if (result) toast(result.conditionMet === false ? 'Condition not met · no demo actions were applied.' : `${result.applied.length} demo action${result.applied.length === 1 ? '' : 's'} applied; ${result.skipped.length} skipped. No hardware commands were sent.`, result.skipped.length > 0);
      return;
    }
    const deleteRule = event.target.closest('[data-delete-rule]');
    if (deleteRule) {
      if (!window.confirm('Delete this local demo automation?')) return;
      run(() => service.deleteAutomation(deleteRule.dataset.deleteRule), 'Automation removed from the local preview.');
      return;
    }
    const editSchedule = event.target.closest('[data-edit-schedule]');
    if (editSchedule) {
      window.setRoute('dash-devices');
      window.setTimeout(() => {
        const button = document.querySelector(`[data-edit-schedule="${CSS.escape(editSchedule.dataset.editSchedule)}"]`);
        button?.click();
      }, 0);
      return;
    }
    const deleteSchedule = event.target.closest('[data-delete-schedule]');
    if (deleteSchedule) {
      if (!window.confirm('Delete this local preview schedule? It will not affect a real device.')) return;
      run(() => devicesService.removeSchedule(deleteSchedule.dataset.deleteSchedule), 'Schedule removed from this browser preview.');
      return;
    }
    const activate = event.target.closest('[data-activate-scene]');
    if (activate) {
      const result = run(() => service.activateScene(activate.dataset.activateScene));
      if (result) toast(`Scene preview: ${result.applied.length} updated, ${result.skipped.length} skipped. No hardware command was sent.`, result.skipped.length > 0);
      return;
    }
    const deleteScene = event.target.closest('[data-delete-scene]');
    if (deleteScene) {
      if (!window.confirm('Delete this custom preview scene?')) return;
      run(() => service.deleteCustomScene(deleteScene.dataset.deleteScene), 'Custom scene removed.');
      return;
    }
    const notice = event.target.closest('[data-read-notice]');
    if (notice) {
      const current = snapshot().notifications.find((item) => item.id === notice.dataset.readNotice);
      run(() => service.markNotificationRead(notice.dataset.readNotice, !current?.read));
      return;
    }
    if (event.target.closest('[data-mark-all-read]')) {
      snapshot().notifications.filter((item) => !item.read).forEach((item) => service.markNotificationRead(item.id, true));
      render();
      return;
    }
    if (event.target.closest('[data-clear-notices]')) {
      if (!window.confirm('Clear all local preview notifications?')) return;
      run(() => service.clearNotifications(), 'Demo notifications cleared.');
      return;
    }
    if (event.target.closest('[data-create-notice]')) {
      run(() => service.addNotification({ title: 'Preview alert', message: 'This example alert was generated locally; no sensor or device event was received.', type: 'warning' }), 'Demo alert added.');
      return;
    }
    if (event.target.closest('[data-toggle-door]')) {
      const open = snapshot().security.door === 'closed';
      run(() => service.updateSecurity({ door: open ? 'open' : 'closed' }));
      if (open && snapshot().settings.securityAlerts) service.addNotification({ title: 'Door sensor preview', message: 'A simulated door-open state was selected.', type: 'warning' });
      render();
      return;
    }
    if (event.target.closest('[data-toggle-motion]')) {
      const motion = snapshot().security.motion === 'clear';
      run(() => service.updateSecurity({ motion: motion ? 'detected' : 'clear' }));
      if (motion && snapshot().settings.securityAlerts) service.addNotification({ title: 'Motion sensor preview', message: 'A simulated motion state was selected.', type: 'warning' });
      render();
      return;
    }
    if (event.target.closest('[data-away-mode]')) {
      const enabled = !snapshot().security.awayMode;
      if (enabled && !window.confirm('Activate Away preview? Online demo devices will be switched off locally. This does not arm a real security system.')) return;
      try {
        const result = enabled ? service.activateScene('away-mode') : { skipped: [] };
        service.updateSecurity({ awayMode: enabled });
        toast(`Away ${enabled ? 'preview activated' : 'preview ended'} · no security system is connected.${result.skipped.length ? ` ${result.skipped.length} offline device(s) skipped.` : ''}`, result.skipped.length > 0);
        render();
      } catch (error) {
        toast(error instanceof Error ? error.message : 'The away preview could not be updated.', true);
      }
      return;
    }
  }

  function handleChange(event) {
    const sceneDevice = event.target.closest('input[name="sceneDevice"]');
    if (sceneDevice) {
      const state = [...document.querySelectorAll('#scene-device-list [data-scene-state]')]
        .find((select) => select.dataset.sceneState === sceneDevice.value);
      if (state) state.disabled = !sceneDevice.checked;
      return;
    }
    const toggle = event.target.closest('[data-rule-enabled]');
    if (toggle) {
      run(() => service.setAutomationEnabled(toggle.dataset.ruleEnabled, toggle.checked), `Demo rule ${toggle.checked ? 'enabled' : 'paused'} · background triggers remain inactive.`);
      return;
    }
    const schedule = event.target.closest('[data-schedule-enabled]');
    if (schedule) {
      run(() => devicesService.setScheduleEnabled(schedule.dataset.scheduleEnabled, schedule.checked), `Local schedule ${schedule.checked ? 'enabled' : 'paused'} · it will not execute automatically.`);
      return;
    }
    const setting = event.target.closest('[data-notification-setting]');
    if (setting) {
      run(() => service.saveSettings({ [setting.dataset.notificationSetting]: setting.checked }));
      return;
    }
    const role = event.target.closest('[data-member-role]');
    if (role) {
      run(() => service.updateFamilyMember(role.dataset.memberRole, { role: role.value }), 'Demo permissions updated locally.');
      return;
    }
    const access = event.target.closest('[data-member-device]');
    if (access) {
      const member = snapshot().members.find((item) => item.id === access.dataset.memberDevice);
      if (!member) return;
      const devices = member.devices.includes('all') ? snapshot().devices.map((device) => device.id) : member.devices.slice();
      const next = new Set(devices);
      if (access.checked) next.add(access.dataset.deviceId);
      else next.delete(access.dataset.deviceId);
      run(() => service.updateFamilyMember(member.id, { devices: [...next] }), 'Demo device access updated.');
      return;
    }
    const historySelect = event.target.closest('#history-filter');
    if (historySelect) {
      historyFilter = historySelect.value;
      render();
    }
  }

  function handleInput(event) {
    if (event.target.matches('#advanced-search')) filterItems(event.target.value);
    if (event.target.closest('#automation-form')
      && ['triggerType', 'condition', 'actionType'].includes(event.target.name)) updateRuleFormVisibility();
  }

  async function handleSubmit(event) {
    const form = event.target.closest('form') || event.submitter?.form;
    if (!form) return;
    const formId = form.getAttribute('id');
    if (formId === 'backend-billing-form') {
      event.preventDefault();
      const data = new FormData(form);
      const settings = {
        gridSourceId: String(data.get('gridSourceId') || '').trim(),
        tariffPerKWh: Number(data.get('tariffPerKWh')),
        exportTariffPerKWh: Number(data.get('exportTariffPerKWh')),
        fixedCharges: Number(data.get('fixedCharges')),
        additionalCharges: Number(data.get('additionalCharges')),
      };
      const submit = form.querySelector('[type="submit"]');
      submit.disabled = true;
      submit.textContent = 'Saving settings…';
      try {
        const client = window.HomiotConnectivityClient;
        if (!client || !client.getSnapshot().connected) throw new Error('Connect to the authorized backend before saving tariff settings.');
        billingData = { ...billingData, status: 'loading', estimate: null, reason: '', error: '' };
        billingData.settings = await client.saveBillingSettings(settings);
        const result = await client.readBillingEstimate();
        billingData = {
          status: 'ready',
          settings: result.settings,
          estimate: result.available ? result.estimate : null,
          reason: result.reason || '',
          error: '',
        };
        toast('Backend tariff settings saved.');
      } catch (error) {
        billingData = {
          ...billingData,
          status: 'error',
          estimate: null,
          error: error instanceof Error ? error.message : 'The tariff settings could not be saved.',
        };
      }
      if (activeRoute === 'dash-billing') render();
      return;
    }
    if (formId === 'bill-form') {
      event.preventDefault();
      const values = Object.fromEntries(new FormData(form).entries());
      const settings = Object.fromEntries(Object.entries(values).map(([key, value]) => [key, Number(value)]));
      try {
        service.saveSettings(settings);
        toast('Bill estimate updated with your demo tariff.');
        render();
      } catch (error) {
        document.querySelector('#bill-error').textContent = error.message || 'Check the billing inputs.';
      }
      return;
    }
    if (formId === 'automation-form') {
      event.preventDefault();
      const data = new FormData(form);
      const selectedDevices = [...form.elements.actionDevice.selectedOptions].map((option) => option.value);
      const actionType = data.get('actionType');
      const actionValue = Number(data.get('actionValue'));
      const triggerType = data.get('triggerType');
      const trigger = { type: triggerType };
      if (triggerType === 'TIME') trigger.value = data.get('triggerTime');
      if (['ENERGY_THRESHOLD', 'SENSOR_VALUE'].includes(triggerType)) trigger.value = data.get('threshold');
      if (triggerType === 'DEVICE_STATE') trigger.deviceId = data.get('triggerDevice');
      const condition = data.get('condition');
      try {
        if (actionType.startsWith('SET_') && selectedDevices.length !== 1) {
          throw new Error('Choose exactly one appliance for an appliance-specific setting.');
        }
        const actions = selectedDevices.map((deviceId) => {
          const device = devicesService.getDeviceById(deviceId);
          let settings = {};
          let on = true;
          if (actionType === 'OFF') on = false;
          if (actionType === 'SET_BRIGHTNESS') {
            if (device.kind !== 'light') throw new Error(`${device.name} does not support brightness.`);
            settings = { brightness: actionValue };
          }
          if (actionType === 'SET_TEMPERATURE') {
            if (!['ac', 'geyser'].includes(device.kind)) throw new Error(`${device.name} does not support temperature settings.`);
            settings = { temperature: actionValue };
          }
          if (actionType === 'SET_FAN_SPEED') {
            if (!['ac', 'fan', 'exhaust'].includes(device.kind)) throw new Error(`${device.name} does not support fan speed.`);
            settings = { [device.kind === 'ac' ? 'fanSpeed' : 'speed']: actionValue };
          }
          return { deviceId, on, ...(Object.keys(settings).length ? { settings } : {}) };
        });
        service.saveAutomation({
          id: data.get('id') || undefined,
          name: data.get('name'),
          trigger,
          condition,
          conditionDeviceId: ['DEVICE_ON', 'DEVICE_OFF'].includes(condition) ? data.get('conditionDevice') : undefined,
          conditionValue: ['ENERGY_ABOVE', 'TEMPERATURE_ABOVE'].includes(condition) ? Number(data.get('conditionValue')) : undefined,
          actions,
          enabled: true,
        });
        document.querySelector('#automation-dialog').close();
        toast('Automation saved locally · triggers run only when you choose Run preview.');
        render();
      } catch (error) {
        document.querySelector('#automation-error').textContent = error instanceof Error ? error.message : 'The automation could not be saved.';
      }
      return;
    }
    if (formId === 'scene-form') {
      event.preventDefault();
      const data = new FormData(form);
      try {
        const actions = [...form.querySelectorAll('input[name="sceneDevice"]:checked')].map((checkbox) => {
          const state = [...form.querySelectorAll('[data-scene-state]')]
            .find((select) => select.dataset.sceneState === checkbox.value);
          return { deviceId: checkbox.value, on: state?.value === 'true' };
        });
        const scene = { name: data.get('name'), description: data.get('description'), actions };
        if (data.get('id')) service.updateCustomScene(data.get('id'), scene);
        else service.createScene(scene);
        document.querySelector('#scene-dialog').close();
        toast(data.get('id') ? 'Custom scene updated in the local preview.' : 'Custom scene saved to the local preview.');
        render();
      } catch (error) {
        document.querySelector('#scene-error').textContent = error instanceof Error ? error.message : 'The scene could not be saved.';
      }
      return;
    }
    if (formId === 'family-form') {
      event.preventDefault();
      const data = new FormData(form);
      try {
        service.addFamilyMember({ name: data.get('name'), email: data.get('email'), role: data.get('role') });
        event.target.reset();
        document.querySelector('#family-dialog').close();
        toast('Member added to the local family preview · no invitation was sent.');
        render();
      } catch (error) {
        document.querySelector('#family-error').textContent = error instanceof Error ? error.message : 'The demo member could not be added.';
      }
    }
  }

  function handleClickCapture(event) {
    const removeMember = event.target.closest('[data-remove-member]');
    if (removeMember) {
      event.preventDefault();
      if (!window.confirm('Remove this member from the local demo list? No real account access is changed.')) return;
      run(() => service.removeFamilyMember(removeMember.dataset.removeMember), 'Member removed from the local preview.');
    }
  }

  function handleRoute(route) {
    activeRoute = route;
    const isAdvanced = Object.hasOwn(routes, route);
    root.hidden = !isAdvanced;
    if (isAdvanced) {
      document.querySelector('#device-management').hidden = true;
      document.querySelector('#device-detail-page').hidden = true;
      document.querySelector('#dashboard-content').hidden = true;
      document.querySelectorAll('.dashboard-tab').forEach((tab) => {
        const routeGroup = route === 'dash-energy' || route === 'dash-billing' ? 'dash-energy'
          : route === 'dash-profile' ? 'dash-profile'
            : route === 'dash-devices' || route.startsWith('dash-device-') ? 'dash-devices'
              : 'dash-automation';
        const active = tab.dataset.dashRoute === routeGroup;
        tab.classList.toggle('active', active);
        if (active) tab.setAttribute('aria-current', 'page');
        else tab.removeAttribute('aria-current');
      });
      render();
      if (route === 'dash-energy') loadEnergyTelemetry();
      if (route === 'dash-billing') loadBillingData();
      if (route === 'dash-solar') loadSolarTelemetry();
    }
  }

  document.addEventListener('click', handleClick);
  document.addEventListener('click', handleClickCapture, true);
  window.addEventListener('scroll', updateSolarSectionFromScroll, { passive: true });
  window.addEventListener('resize', updateSolarSectionFromScroll, { passive: true });
  document.addEventListener('input', handleInput);
  document.addEventListener('change', handleChange);
  document.addEventListener('submit', (event) => {
    const form = event.target instanceof HTMLFormElement
      ? event.target
      : event.submitter?.form || event.target.form || event.target.closest?.('form');
    if (form && ['bill-form', 'backend-billing-form', 'automation-form', 'scene-form', 'family-form'].includes(form.getAttribute('id'))) {
      event.preventDefault();
      handleSubmit(event);
    }
  }, true);
  for (const id of ['automation-dialog', 'scene-dialog', 'family-dialog']) {
    document.querySelector(`#${id}`).addEventListener('click', (event) => {
      if (event.target === event.currentTarget) event.currentTarget.close();
    });
  }
  document.querySelector('#automation-form').elements.triggerType.addEventListener('change', updateRuleFormVisibility);
  document.querySelector('#automation-form').elements.condition.addEventListener('change', updateRuleFormVisibility);
  document.querySelector('#automation-form').elements.actionType.addEventListener('change', updateRuleFormVisibility);

  window.addEventListener('smartnest-advanced-changed', () => {
    if (activeRoute && routes[activeRoute]) render();
  });
  window.addEventListener('homiot-connectivity-changed', () => {
    if (activeRoute === 'dash-energy') loadEnergyTelemetry();
    if (activeRoute === 'dash-billing') loadBillingData();
    if (activeRoute === 'dash-solar') loadSolarTelemetry();
  });
  window.addEventListener('smartnest-settings-changed', () => {
    if (activeRoute === 'dash-family') render();
  });
  window.addEventListener('smartnest-devices-changed', () => {
    const current = devicesService.getDevices();
    const previous = new Map(lastDevices.map((device) => [device.id, device]));
    const settings = snapshot().settings;
    current.forEach((device) => {
      const before = previous.get(device.id);
      if (before && settings.deviceAlerts && before.online && !device.online) {
        service.addNotification({ title: `${device.name} offline`, message: 'The demo connection was marked offline. State and readings are unverified.', type: 'warning' });
      } else if (before && settings.deviceAlerts && before.online && device.online && before.on !== device.on) {
        service.addNotification({ title: `${device.name} ${device.on ? 'on' : 'off'} · demo`, message: 'A local preview state changed. No hardware command was sent.', type: 'info' });
      }
    });
    lastDevices = current;
    if (activeRoute && routes[activeRoute]) render();
  });

  window.SmartNestAdvancedFeatures = { handleRoute, render };
})();
