const initialDevices = [
  { id: 1, name: 'Greenhouse monitor', type: 'ESP32 DevKit V1', connection: 'Wi-Fi', status: 'Online', signal: '2 sec ago', battery: 'Powered' },
  { id: 2, name: 'Desk climate node', type: 'Raspberry Pi Pico W', connection: 'Bluetooth', status: 'Online', signal: '12 sec ago', battery: '86%' },
  { id: 3, name: 'Workshop relay', type: 'Arduino Uno R4 WiFi', connection: 'Wi-Fi', status: 'Online', signal: '38 sec ago', battery: 'Powered' },
  { id: 4, name: 'Window sensor', type: 'nRF52840 Feather', connection: 'Bluetooth', status: 'Offline', signal: '24 min ago', battery: '42%' },
];
const initialSwitches = [
  { id: 'fan', name: 'Fan', label: 'Living room', type: 'Fan', on: true, watts: 75 },
  { id: 'light', name: 'Light', label: 'Kitchen', type: 'Light', on: true, watts: 18 },
  { id: 'pump', name: 'Water Pump', label: 'Garden', type: 'Water Pump', on: false, watts: 680 },
];
const initialProjects = [
  { name: 'Greenhouse monitor', description: 'Temperature and humidity tracking with an alerting relay.', board: 'ESP32 DevKit V1', connections: ['Wi-Fi'], components: ['Sensor', 'Relay'], updated: 'Updated 18 min ago', cover: 'green', device: 'Greenhouse monitor' },
  { name: 'Desk climate node', description: 'A compact ambient sensor for the home workspace.', board: 'Raspberry Pi Pico W', connections: ['Bluetooth'], components: ['Sensor', 'Display'], updated: 'Updated yesterday', cover: 'blue', device: 'Desk climate node' },
  { name: 'Workshop relay', description: 'Bench power control with a local safety cutoff.', board: 'Arduino Uno R4 WiFi', connections: ['Wi-Fi'], components: ['Relay', 'Button'], updated: 'Updated 3 days ago', cover: 'orange', device: 'Workshop relay' },
];
const initialAutomations = [
  { name: 'Greenhouse temperature alert', description: 'Keep an eye on warm days.', trigger: 'Temperature > 28°C', action: 'Send a local alert', device: 'Greenhouse monitor', enabled: true },
  { name: 'Evening desk quiet mode', description: 'Dim the desk display after hours.', trigger: 'Time is after 21:00', action: 'Set display brightness to 20%', device: 'Desk climate node', enabled: true },
];
let devices = structuredClone(initialDevices);
let switches = structuredClone(initialSwitches);
let projects = structuredClone(initialProjects);
let automations = structuredClone(initialAutomations);
let components = ['Sensor', 'Relay'];
let activeProject = null;
let activeSwitchId = null;
let wifiProfile = null;
let demoFaultActive = false;
let demoEnergy = 2.64;
let lastFaultSignature = null;
let toastTimer;
let onboardingIndex = 0;
const dashboardRoutes = new Set([
  'dashboard', 'dash-devices', 'dash-automation', 'dash-schedules', 'dash-energy',
  'dash-billing', 'dash-solar', 'dash-scenes', 'dash-notifications', 'dash-family', 'dash-security', 'dash-profile',
  'dash-settings', 'dash-wifi', 'dash-rooms',
  'dash-user-profile', 'dash-account-security', 'dash-remote', 'dash-preferences',
  'dash-privacy', 'dash-help', 'dash-connectivity', 'dash-homes', 'dash-add-home', 'dash-home-overview',
  'dash-home-rooms', 'dash-room-detail', 'dash-home-settings', 'dash-add-device',
  'dash-cameras', 'dash-camera-live', 'dash-recordings',
  'dash-all-devices',
]);
const isDashboardRoute = (route) => dashboardRoutes.has(route) || route.startsWith('dash-device-');
const flowScreens = new Set(['welcome', 'onboarding', 'login', 'signup', 'verify', 'forgot', 'reset', ...dashboardRoutes]);
const studioScreens = new Set(['energy', 'overview', 'projects', 'devices', 'automations', 'settings', 'builder']);
const flowRoot = document.querySelector('#welcome-flow');
const appShell = document.querySelector('#app-shell');
const mobileTabbar = document.querySelector('.mobile-tabbar');

function renderOnboarding() {
  const track = document.querySelector('#onboarding-track');
  if (!track.dataset.premiumReady) {
    track.innerHTML = `
      <article class="onboard-slide premium-intro-slide" aria-labelledby="slide-title-1">
        <div class="premium-onboarding-visual intro-visual" role="img" aria-label="Warmly lit luxury living room"><span class="premium-visual-chip">SMART LIVING · YOUR WAY</span><div class="intro-visual-copy"><span>THE HOME, IN HARMONY</span><b>Welcome to<br><em>Smart Living.</em></b><small>A calmer way to care for the place you call home.</small></div><i class="visual-light-orb"></i></div>
        <div class="slide-copy"><span class="slide-number">01 <i></i> A MORE THOUGHTFUL HOME</span><h2 id="slide-title-1">Welcome to<br><em>Smart Living.</em></h2><p>Bring comfort, convenience, and a little more peace of mind into every room.</p><ul class="intro-feature-list"><li>Control your home from anywhere</li><li>Manage connected devices in one place</li><li>Keep an eye on your property</li><li>Make everyday living feel effortless</li></ul></div>
      </article>
      <article class="onboard-slide premium-benefits-slide" aria-labelledby="slide-title-2">
        <div class="slide-copy"><span class="slide-number">02 <i></i> MADE FOR THE WAY YOU LIVE</span><h2 id="slide-title-2">More ease in<br><em>every day.</em></h2><p>Small thoughtful details add up to a home that feels more like yours.</p><div class="premium-benefit-grid">
          <article class="benefit-card benefit-comfort"><span>✧</span><b>Smart Comfort</b><small>Set a welcoming rhythm for every room.</small></article>
          <article class="benefit-card benefit-security"><span>⌑</span><b>Home Security</b><small>Stay aware of your property and its status.</small></article>
          <article class="benefit-card benefit-energy"><span>↘</span><b>Energy Management</b><small>Explore illustrative usage insights.</small></article>
          <article class="benefit-card benefit-control"><span>⌂</span><b>Centralized Control</b><small>Keep spaces and devices together.</small></article>
        </div><p class="premium-simulation-note">Connectivity and readings shown here are a local demo, not live hardware.</p></div>
      </article>
      <article class="onboard-slide premium-get-started-slide" aria-labelledby="slide-title-3">
        <div class="premium-onboarding-visual start-visual" role="img" aria-label="A modern home glowing at dusk"><span class="premium-visual-chip">HOMIOT · INTELLIGENT LIVING</span><div class="intro-visual-copy"><span>MAKE YOURSELF AT HOME</span><b>A more considered<br><em>kind of living.</em></b><small>Your rooms. Your routines. One considered experience.</small></div><i class="visual-light-orb"></i></div>
        <div class="slide-copy"><span class="slide-number">03 <i></i> YOUR HOMIOT STARTS HERE</span><h2 id="slide-title-3">Make it<br><em>your own.</em></h2><p>Create a local browser profile or go straight to the simulated dashboard.</p><div class="premium-start-actions"><button type="button" class="flow-primary" data-flow-route="signup">Create profile <span aria-hidden="true">→</span></button><button type="button" class="premium-login-link" data-flow-route="dashboard">Explore without a profile</button></div></div>
      </article>`;
    document.querySelector('.onboarding-footer').innerHTML = `
      <button type="button" class="premium-onboarding-back" data-flow-action="back">← <span>Back</span></button>
      <div class="onboarding-dots" role="group" aria-label="Choose an introduction screen"></div>
      <span class="slide-progress" id="slide-progress" aria-live="polite"></span>
      <button class="flow-primary onboarding-next" id="onboarding-next" data-flow-action="next">Continue <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5"/></svg></button>`;
    track.dataset.premiumReady = 'true';
  }
  track.style.transform = `translateX(-${onboardingIndex * 100}%)`;
  document.querySelectorAll('.onboard-slide').forEach((slide, index) => {
    slide.setAttribute('aria-hidden', String(index !== onboardingIndex));
  });
  const dots = document.querySelector('.onboarding-dots');
  dots.innerHTML = Array.from({ length: 3 }, (_, index) => `<button class="onboarding-dot${index === onboardingIndex ? ' is-active' : ''}" data-onboarding-dot="${index}" aria-label="Screen ${index + 1} of 3"${index === onboardingIndex ? ' aria-current="step"' : ''}></button>`).join('');
  document.querySelectorAll('[data-onboarding-dot]').forEach((dot, index) => {
    const active = index === onboardingIndex;
    dot.classList.toggle('is-active', active);
    if (active) dot.setAttribute('aria-current', 'step');
    else dot.removeAttribute('aria-current');
  });
  document.querySelector('#slide-progress').innerHTML = `0${onboardingIndex + 1} <i>/</i> 03`;
  const next = document.querySelector('#onboarding-next');
  next.innerHTML = onboardingIndex === 2
    ? 'Continue <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5"/></svg>'
    : 'Continue <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5"/></svg>';
  document.querySelector('[data-flow-action="back"]').setAttribute('aria-label', onboardingIndex ? 'Go to previous onboarding screen' : 'Back to welcome screen');
}

function syncRoute() {
  const route = window.location.hash.slice(1);
  const isFlow = isDashboardRoute(route) || flowScreens.has(route) || !studioScreens.has(route);
  flowRoot.hidden = !isFlow;
  appShell.hidden = isFlow;
  mobileTabbar.hidden = isFlow;
  document.body.classList.toggle('flow-active', isFlow);

  if (isFlow) {
    const screen = isDashboardRoute(route) ? 'dashboard' : flowScreens.has(route) ? route : 'welcome';
    document.querySelectorAll('.flow-screen').forEach((element) => {
      element.hidden = element.id !== `screen-${screen}`;
    });
    document.body.classList.toggle('flow-auth', !['welcome', 'onboarding'].includes(screen));
    document.body.classList.toggle('flow-dashboard', isDashboardRoute(route));
    document.body.dataset.flowScreen = screen;
    if (isDashboardRoute(route)) document.body.dataset.flowRoute = route;
    else delete document.body.dataset.flowRoute;
    if (screen === 'onboarding') renderOnboarding();
    window.SmartNestDashboard?.handleRoute(route);
    window.SmartNestDeviceManagement?.handleRoute(route);
    window.SmartNestAdvancedFeatures?.handleRoute(route);
    window.SmartNestSettingsModule?.handleRoute(route);
    window.SmartNestHomeModule?.handleRoute(route);
    window.dispatchEvent(new CustomEvent('app-route-change', { detail: { route: screen } }));
    return;
  }

  document.body.classList.remove('flow-auth');
  document.body.classList.remove('flow-dashboard');
  delete document.body.dataset.flowScreen;
  delete document.body.dataset.flowRoute;
  navigate(route);
  window.dispatchEvent(new CustomEvent('app-route-change', { detail: { route } }));
}

function setRoute(route) {
  if (window.location.hash !== `#${route}`) history.pushState(null, '', `#${route}`);
  syncRoute();
}
window.setRoute = setRoute;

const icon = (name) => {
  const paths = {
    board: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 7h6M9 17h6"/>',
    sensor: '<circle cx="12" cy="12" r="3"/><path d="M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8"/>',
    project: '<path d="M3 7.5h7l2 2h9v10H3z"/><path d="M3 7.5V5h7l2 2.5"/>',
    wifi: '<path d="M5 9.5a11 11 0 0 1 14 0M8 12.5a6.5 6.5 0 0 1 8 0M11 15.5a2 2 0 0 1 2 0M12 19h.01"/>',
    bt: '<path d="M12 3v18l7-6-7-6 7-6-7-6M5 8l14 8M5 16 19 8"/>',
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.board}</svg>`;
};
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
function showToast(message) {
  const toast = document.querySelector('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}
function renderWorkspaceProfile() {
  try {
    const profile = window.SmartNestSettingsService?.getSnapshot().profile;
    if (!profile) return;
    const name = profile.preferredName || profile.name.trim() || 'Home owner';
    const initials = name.split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase();
    document.querySelectorAll('[data-workspace-name]').forEach((node) => { node.textContent = name; });
    document.querySelectorAll('[data-workspace-avatar]').forEach((node) => {
      if (profile.avatar) {
        const image = document.createElement('img');
        image.src = profile.avatar;
        image.alt = '';
        node.replaceChildren(image);
      } else {
        node.textContent = initials;
      }
    });
  } catch (error) {
    showToast(error instanceof Error ? `Profile could not be loaded: ${error.message}` : 'Profile could not be loaded.');
  }
}
function navigate(view) {
  const target = document.querySelector(`#view-${view}`);
  if (!target) return;
  document.querySelectorAll('.view').forEach((section) => section.classList.toggle('active', section === target));
  document.querySelectorAll('.nav-item[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
  document.querySelectorAll('.mobile-tab[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
  const labels = { energy: 'Home energy', overview: 'Overview', projects: 'Projects', devices: 'Devices', automations: 'Automations', settings: 'Settings', builder: 'Project designer' };
  document.querySelector('#breadcrumb-current').textContent = labels[view] || 'Overview';
  document.querySelector('#sidebar').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function updateCounts() {
  const online = devices.filter((device) => device.status === 'Online');
  document.querySelector('#online-count').textContent = online.length;
  document.querySelector('#total-count').textContent = devices.length;
  document.querySelector('#device-count').textContent = devices.length;
  document.querySelector('#project-count').textContent = projects.length;
  document.querySelector('#active-project-count').textContent = projects.length;
  document.querySelector('#automation-count').textContent = automations.filter((rule) => rule.enabled).length;
  document.querySelector('#wifi-count').textContent = online.filter((device) => device.connection === 'Wi-Fi').length;
  document.querySelector('#bluetooth-count').textContent = online.filter((device) => device.connection === 'Bluetooth').length;
  document.querySelector('#offline-count').textContent = devices.length - online.length;
  document.querySelector('#device-toolbar-count').textContent = `${devices.length} device${devices.length === 1 ? '' : 's'}`;
  document.querySelector('#projects-toolbar-count').textContent = `${projects.length} project${projects.length === 1 ? '' : 's'}`;
}
function renderSwitches() {
  const list = document.querySelector('#switch-list');
  list.innerHTML = switches.map((item) => `<article class="switch-row"><span class="switch-glyph ${item.on ? 'switch-on' : ''}">${item.type === 'Light' ? '◉' : item.type === 'Water Pump' ? '↻' : '⌁'}</span><div class="switch-identity"><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.label)} · ${escapeHtml(item.type)}</small></div><span class="switch-state ${item.on ? 'switch-state-on' : ''}"><i></i>${item.on ? 'On' : 'Off'}</span><button class="switch-edit" data-edit-switch="${escapeHtml(item.id)}" aria-label="Edit ${escapeHtml(item.name)} name and label">Edit</button><button class="toggle ${item.on ? 'on' : ''}" data-switch-toggle="${escapeHtml(item.id)}" role="switch" aria-checked="${item.on}" aria-label="Turn ${item.on ? 'off' : 'on'} ${escapeHtml(item.name)} (simulated)"></button></article>`).join('') || '<div class="empty-state"><b>No switches yet</b>Add a demo switch to organize a device.</div>';
}
function renderFaults(voltage, current) {
  const voltageFault = voltage < 207 || voltage > 253;
  const currentFault = current > 12;
  const signature = `${voltageFault}:${currentFault}`;
  if (signature === lastFaultSignature) return;
  lastFaultSignature = signature;
  const faultCount = Number(voltageFault) + Number(currentFault);
  const count = document.querySelector('#fault-count');
  count.textContent = `${faultCount} active`;
  count.classList.toggle('has-fault', faultCount > 0);
  const content = document.querySelector('#fault-content');
  if (!faultCount) {
    content.innerHTML = '<div class="fault-clear"><span>✓</span><div><b>No demo faults detected</b><small>Readings are inside the illustrative limits.</small></div></div>';
    return;
  }
  const alerts = [];
  if (voltageFault) alerts.push(`<article class="fault-alert"><span class="fault-alert-icon">!</span><div><b>Voltage outside demo range</b><p>${voltage.toFixed(1)} V · illustrative range 207–253 V</p><small>Demo alert · no protective trip is connected</small></div></article>`);
  if (currentFault) alerts.push(`<article class="fault-alert"><span class="fault-alert-icon">!</span><div><b>Overcurrent warning</b><p>${current.toFixed(1)} A · demo warning limit 12.0 A</p><small>Simulated test event · local hardware protection required</small></div></article>`);
  content.innerHTML = `${alerts.join('')}<button class="fault-ack" data-action="ack-fault">Acknowledge demo alert</button>`;
}
function renderEnergy() {
  const voltage = 229.4 + Math.sin(Date.now() / 12000) * 0.35;
  const activeWatts = switches.reduce((total, item) => total + (item.on ? item.watts : 0), 0);
  const current = demoFaultActive ? 12.8 : 1.62 + activeWatts / voltage;
  const power = voltage * current;
  demoEnergy += power * 3 / 3600000;
  document.querySelector('#voltage-reading').textContent = voltage.toFixed(1);
  document.querySelector('#voltage-trend').textContent = voltage.toFixed(1);
  document.querySelector('#current-reading').textContent = current.toFixed(2);
  document.querySelector('#current-trend').textContent = current.toFixed(2);
  document.querySelector('#power-reading').textContent = Math.round(power);
  document.querySelector('#energy-reading').textContent = demoEnergy.toFixed(3);
  document.querySelector('#reading-time').textContent = new Date().toLocaleTimeString();
  document.querySelector('#reading-updated').textContent = `Updated ${new Date().toLocaleTimeString()}`;
  renderFaults(voltage, current);
}
function openSwitchDialog(id = null) {
  const item = switches.find((entry) => entry.id === id);
  activeSwitchId = item?.id || null;
  document.querySelector('#switch-modal-title').textContent = item ? 'Edit switch' : 'Add a switch';
  document.querySelector('#switch-name').value = item?.name || '';
  document.querySelector('#switch-label').value = item?.label || '';
  document.querySelector('#switch-type').value = item?.type || 'Fan';
  document.querySelector('#switch-modal').showModal();
}
function saveSwitch() {
  const name = document.querySelector('#switch-name').value.trim();
  const label = document.querySelector('#switch-label').value.trim();
  const type = document.querySelector('#switch-type').value;
  if (!name || !label) return;
  const item = switches.find((entry) => entry.id === activeSwitchId);
  if (item) Object.assign(item, { name, label, type });
  else switches.push({ id: `switch-${Date.now()}`, name, label, type, on: false, watts: 60 });
  document.querySelector('#switch-modal').close();
  renderSwitches();
  renderEnergy();
  showToast(`${name} saved in this browser demo.`);
}
function saveWifiProfile() {
  wifiProfile = {
    name: document.querySelector('#wifi-module-name').value.trim(),
    ssid: document.querySelector('#wifi-ssid').value.trim(),
    endpoint: document.querySelector('#wifi-endpoint').value.trim(),
  };
  const state = document.querySelector('#wifi-state');
  state.innerHTML = '<i class="profile-saved"></i>Profile saved · demo';
  document.querySelector('#wifi-modal').close();
  showToast(`${wifiProfile.name} profile saved locally. No module was contacted.`);
}
function renderRecentDevices() {
  const rows = devices.slice(0, 4).map((device) => `<tr><td><span class="device-name"><span class="device-thumb ${device.connection === 'Bluetooth' ? 'bt-thumb' : ''}">${icon('board')}</span>${escapeHtml(device.name)}</span></td><td><span class="connection-label"><i class="${device.connection === 'Bluetooth' ? 'bt-pip' : ''}"></i>${escapeHtml(device.connection)}</span></td><td>${escapeHtml(device.signal)}</td><td><span class="table-status ${device.status === 'Offline' ? 'offline' : ''}"><i></i>${device.status === 'Online' ? 'Online' : 'Offline'}</span></td><td></td></tr>`).join('');
  document.querySelector('#recent-devices').innerHTML = rows || '<tr><td colspan="5">No devices in this workspace.</td></tr>';
}
function renderDevices() {
  const filter = document.querySelector('#device-filter').value;
  const query = document.querySelector('#device-search').value.trim().toLowerCase();
  const filtered = devices.filter((device) => (filter === 'all' || device.connection === filter) && `${device.name} ${device.type}`.toLowerCase().includes(query));
  const list = document.querySelector('#device-list');
  if (!filtered.length) {
    list.innerHTML = '<div class="empty-state"><b>No matching devices</b>Try a different search or connection filter.</div>';
    return;
  }
  list.innerHTML = filtered.map((device) => `<article class="device-row"><div class="device-identity"><span class="device-thumb ${device.connection === 'Bluetooth' ? 'bt-thumb' : ''}">${icon('board')}</span><span><b>${escapeHtml(device.name)}</b><small>${escapeHtml(device.type)}</small></span></div><div class="device-meta"><label>CONNECTION</label><span class="device-connection ${device.connection === 'Bluetooth' ? 'bt' : ''}"><i></i>${escapeHtml(device.connection)}</span></div><div class="device-meta"><label>LAST SIGNAL</label><span>${escapeHtml(device.signal)}</span></div><span class="device-status ${device.status === 'Offline' ? 'offline' : ''}"><i></i>${device.status === 'Online' ? 'Online' : 'Offline'}</span><div class="device-row-actions"><button class="control-button" data-device-control="${device.id}" ${device.status === 'Offline' ? 'disabled title="Connect to enable controls"' : ''}>Controls</button><button class="toggle ${device.status === 'Online' ? 'on' : ''}" data-device-toggle="${device.id}" role="switch" aria-checked="${device.status === 'Online'}" aria-label="${device.status === 'Online' ? 'Disconnect' : 'Connect'} ${escapeHtml(device.name)}"></button></div></article>`).join('');
}
function renderProjects() {
  const container = document.querySelector('#project-grid');
  container.innerHTML = projects.map((project, index) => `<article class="project-card" style="animation-delay:${Math.min(index * 45, 180)}ms"><div class="project-cover cover-${escapeHtml(project.cover || 'purple')}"><span class="cover-badge">${escapeHtml(project.board.split(' ')[0])}</span><span class="project-board-mini"><i class="mini-chip"></i></span>${project.connections.includes('Bluetooth') ? '<i class="cover-wave"></i>' : ''}<i class="cover-sensor"></i></div><div class="project-card-content"><div class="project-card-head"><h3>${escapeHtml(project.name)}</h3></div><p class="project-card-desc">${escapeHtml(project.description)}</p><div class="project-tags"><span class="project-tag">${escapeHtml(project.board)}</span>${project.connections.map((connection) => `<span class="project-tag ${connection === 'Bluetooth' ? 'blue-tag' : ''}">${escapeHtml(connection)}</span>`).join('')}</div><div class="project-card-footer"><span>${escapeHtml(project.updated)}</span><button class="project-open" data-open-project="${escapeHtml(project.name)}">Open designer ↗</button></div></div></article>`).join('') || '<div class="empty-state"><b>No projects yet</b>Create a project to begin designing your next build.</div>';
  document.querySelector('#sidebar-projects').innerHTML = projects.slice(0, 5).map((project) => `<button class="mini-project" data-project="${escapeHtml(project.name)}"><span class="project-swatch swatch-${escapeHtml(project.cover || 'purple')}"></span>${escapeHtml(project.name)}</button>`).join('');
  document.querySelectorAll('[data-project-layout]').forEach((button) => button.classList.toggle('selected', button.dataset.projectLayout === (container.classList.contains('project-list-mode') ? 'list' : 'grid')));
}
function renderAutomations() {
  const list = document.querySelector('#automation-list');
  list.innerHTML = automations.map((rule, index) => `<article class="automation-row"><span class="automation-icon">${icon('sensor')}</span><div class="automation-content"><h3>${escapeHtml(rule.name)}</h3><p>${escapeHtml(rule.description)}</p><div class="automation-flow"><span>${escapeHtml(rule.device)}</span><i>→</i><span>${escapeHtml(rule.trigger)}</span><i>→</i><span>${escapeHtml(rule.action)}</span></div></div><button class="toggle ${rule.enabled ? 'on' : ''}" data-automation-toggle="${index}" role="switch" aria-checked="${rule.enabled}" aria-label="${rule.enabled ? 'Disable' : 'Enable'} ${escapeHtml(rule.name)}"></button></article>`).join('') || '<div class="empty-state"><b>No automations</b>Add a rule to describe how devices should respond.</div>';
}
function updateConnectionSummary() {
  const choices = [];
  if (document.querySelector('#connection-wifi').checked) choices.push('Wi-Fi enabled');
  if (document.querySelector('#connection-bt').checked) choices.push('Bluetooth enabled');
  document.querySelector('#canvas-connection-summary').textContent = choices.join(' · ') || 'No connection selected';
}
function renderComponents() {
  const icons = { Sensor: '◉', Relay: '⌁', LED: '●', Display: '▤', Motor: '⟳', Button: '⊙' };
  document.querySelector('#component-count').textContent = `${components.length} added`;
  document.querySelector('#canvas-components').innerHTML = components.map((component, index) => `<div class="canvas-node" style="--node-top:${16 + (index % 4) * 18}%;--node-right:${8 + (index % 3) * 3}%"><i>${icons[component] || '◉'}</i><span><b>${escapeHtml(component)}</b><small>GPIO ${index + 4}</small></span><button data-remove-component="${index}" aria-label="Remove ${escapeHtml(component)}">×</button></div>`).join('');
}
function startProject(project = null) {
  activeProject = project ? projects.find((item) => item.name === project) : null;
  components = activeProject ? [...activeProject.components] : [];
  document.querySelector('#project-name').value = activeProject?.name || 'Untitled project';
  document.querySelector('#board-select').value = activeProject?.board || 'ESP32 DevKit V1';
  document.querySelector('#connection-wifi').checked = activeProject ? activeProject.connections.includes('Wi-Fi') : true;
  document.querySelector('#connection-bt').checked = activeProject ? activeProject.connections.includes('Bluetooth') : false;
  document.querySelector('#builder-title').innerHTML = activeProject ? `${escapeHtml(activeProject.name.split(' ')[0])} <em>designer.</em>` : 'New <em>project.</em>';
  document.querySelector('#builder-status').innerHTML = '<i></i>Unsaved draft';
  document.querySelector('#canvas-board-name').textContent = document.querySelector('#board-select').value;
  renderComponents();
  updateConnectionSummary();
  navigate('builder');
}
function saveProject() {
  const name = document.querySelector('#project-name').value.trim();
  if (!name) {
    document.querySelector('#project-name').focus();
    showToast('Add a project name before saving.');
    return;
  }
  if (!components.length) {
    showToast('Add at least one component to your board.');
    return;
  }
  const selectedConnections = [];
  if (document.querySelector('#connection-wifi').checked) selectedConnections.push('Wi-Fi');
  if (document.querySelector('#connection-bt').checked) selectedConnections.push('Bluetooth');
  const existing = projects.find((project) => project.name === activeProject?.name || project.name === name);
  const project = { name, description: existing?.description || 'A new electronics build in your HOMIOT workspace.', board: document.querySelector('#board-select').value, connections: selectedConnections.length ? selectedConnections : ['Local'], components: [...components], updated: 'Updated just now', cover: existing?.cover || 'purple', device: name };
  if (existing) Object.assign(existing, project);
  else projects.unshift(project);
  activeProject = project;
  renderProjects();
  updateCounts();
  document.querySelector('#builder-status').innerHTML = '<i style="background:#90b878"></i>Saved locally';
  showToast('Project saved in this browser session.');
}
function addDevice() {
  const nameInput = document.querySelector('#new-device-name');
  const name = nameInput.value.trim();
  if (!name) return;
  if (devices.some((device) => device.name.toLowerCase() === name.toLowerCase())) {
    nameInput.setCustomValidity('A device with this name already exists.');
    nameInput.reportValidity();
    return;
  }
  nameInput.setCustomValidity('');
  const connection = document.querySelector('#new-device-connection').value;
  devices.unshift({ id: Date.now(), name, type: document.querySelector('#new-device-type').value, connection, status: 'Offline', signal: 'Never', battery: 'Unknown' });
  document.querySelector('#device-modal').close();
  document.querySelector('#device-form').reset();
  renderDevices();
  renderRecentDevices();
  updateCounts();
  showToast(`${name} added as an offline demo device.`);
}

document.addEventListener('click', (event) => {
  const flowRoute = event.target.closest('a[data-flow-route], button[data-flow-route]');
  if (flowRoute) {
    event.preventDefault();
    if (flowRoute.dataset.flowRoute === 'onboarding') onboardingIndex = 0;
    setRoute(flowRoute.dataset.flowRoute);
    return;
  }
  const onboardingDot = event.target.closest('[data-onboarding-dot]');
  if (onboardingDot) {
    onboardingIndex = Number(onboardingDot.dataset.onboardingDot);
    renderOnboarding();
    return;
  }
  const flowAction = event.target.closest('[data-flow-action]');
  if (flowAction?.dataset.flowAction === 'skip') { setRoute('login'); return; }
  if (flowAction?.dataset.flowAction === 'back') {
    if (onboardingIndex > 0) {
      onboardingIndex -= 1;
      renderOnboarding();
    } else {
      setRoute('welcome');
    }
    return;
  }
  if (flowAction?.dataset.flowAction === 'next') {
    if (onboardingIndex < 2) {
      onboardingIndex += 1;
      renderOnboarding();
    } else {
      setRoute('signup');
    }
    return;
  }
  if (flowAction?.dataset.flowAction === 'demo') { setRoute('energy'); return; }

  const nav = event.target.closest('[data-view]');
  if (nav) { navigate(nav.dataset.view); return; }
  if (event.target.closest('[data-action="wifi-setup"]')) {
    document.querySelector('#wifi-module-name').value = wifiProfile?.name || 'HOMIOT Energy Bridge';
    document.querySelector('#wifi-ssid').value = wifiProfile?.ssid || '';
    document.querySelector('#wifi-endpoint').value = wifiProfile?.endpoint || '';
    document.querySelector('#wifi-modal').showModal();
    return;
  }
  if (event.target.closest('[data-action="add-switch"]')) { openSwitchDialog(); return; }
  if (event.target.closest('[data-action="test-fault"]')) { demoFaultActive = true; renderEnergy(); showToast('Simulated overcurrent event created.'); return; }
  if (event.target.closest('[data-action="ack-fault"]')) { demoFaultActive = false; renderEnergy(); showToast('Demo alert acknowledged.'); return; }
  const switchToggle = event.target.closest('[data-switch-toggle]');
  if (switchToggle) {
    const item = switches.find((entry) => entry.id === switchToggle.dataset.switchToggle);
    if (item) { item.on = !item.on; renderSwitches(); renderEnergy(); showToast(`${item.name} ${item.on ? 'on' : 'off'} · simulated only.`); }
    return;
  }
  const switchEdit = event.target.closest('[data-edit-switch]');
  if (switchEdit) { openSwitchDialog(switchEdit.dataset.editSwitch); return; }
  if (event.target.closest('[data-action="new-project"]')) { startProject(); return; }
  if (event.target.closest('[data-action="add-device"]')) { document.querySelector('#device-modal').showModal(); return; }
  const deviceToggle = event.target.closest('#view-devices [data-device-toggle]');
  if (deviceToggle) {
    const device = devices.find((item) => item.id === Number(deviceToggle.dataset.deviceToggle));
    device.status = device.status === 'Online' ? 'Offline' : 'Online';
    device.signal = device.status === 'Online' ? 'just now · simulated' : 'disconnected · simulated';
    renderDevices(); renderRecentDevices(); updateCounts();
    showToast(`${device.name} ${device.status.toLowerCase()} (simulated).`);
    return;
  }
  const control = event.target.closest('[data-device-control]');
  if (control) { const device = devices.find((item) => item.id === Number(control.dataset.deviceControl)); showToast(`${device.name}: controls are available when a hardware bridge is configured.`); return; }
  const project = event.target.closest('[data-open-project], [data-project]');
  if (project) { startProject(project.dataset.openProject || project.dataset.project); return; }
  const component = event.target.closest('[data-component]');
  if (component) { components.push(component.dataset.component); renderComponents(); return; }
  const remove = event.target.closest('[data-remove-component]');
  if (remove) { components.splice(Number(remove.dataset.removeComponent), 1); renderComponents(); return; }
  const automationToggle = event.target.closest('[data-automation-toggle]');
  if (automationToggle) { const rule = automations[Number(automationToggle.dataset.automationToggle)]; rule.enabled = !rule.enabled; renderAutomations(); updateCounts(); showToast(`${rule.name} ${rule.enabled ? 'enabled' : 'paused'} in preview.`); return; }
  const layout = event.target.closest('[data-project-layout]');
  if (layout) { document.querySelector('#project-grid').classList.toggle('project-list-mode', layout.dataset.projectLayout === 'list'); renderProjects(); return; }
  if (event.target.closest('#mobile-menu')) { document.querySelector('#sidebar').classList.toggle('open'); return; }
  if (event.target.closest('#save-project')) { saveProject(); return; }
  if (event.target.closest('#confirm-add-device')) { event.preventDefault(); addDevice(); return; }
  if (event.target.closest('#add-automation')) {
    const names = ['New threshold alert', 'Motion response rule', 'Scheduled device action'];
    const name = names.find((candidate) => !automations.some((rule) => rule.name === candidate)) || `New rule ${automations.length + 1}`;
    automations.push({ name, description: 'Configure this local preview rule.', trigger: 'Choose a trigger', action: 'Choose an action', device: devices[0]?.name || 'No device', enabled: false });
    renderAutomations(); updateCounts(); showToast('Draft automation added.');
  }
});
document.querySelector('#device-search').addEventListener('input', renderDevices);
document.querySelector('#device-filter').addEventListener('change', renderDevices);
document.querySelector('#board-select').addEventListener('change', (event) => { document.querySelector('#canvas-board-name').textContent = event.target.value; });
document.querySelector('#connection-wifi').addEventListener('change', updateConnectionSummary);
document.querySelector('#connection-bt').addEventListener('change', updateConnectionSummary);
document.querySelector('#project-name').addEventListener('input', (event) => { if (!activeProject) document.querySelector('#builder-title').innerHTML = `${escapeHtml(event.target.value.trim() || 'New')} <em>project.</em>`; });
document.querySelector('#device-form').addEventListener('submit', (event) => { event.preventDefault(); addDevice(); });
document.querySelector('#switch-form').addEventListener('submit', (event) => { event.preventDefault(); saveSwitch(); });
document.querySelector('#wifi-form').addEventListener('submit', (event) => { event.preventDefault(); saveWifiProfile(); });
document.querySelector('#device-modal').addEventListener('click', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
document.querySelector('#switch-modal').addEventListener('click', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
document.querySelector('#wifi-modal').addEventListener('click', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
document.querySelector('#reset-demo').addEventListener('click', () => {
  devices = structuredClone(initialDevices); switches = structuredClone(initialSwitches); projects = structuredClone(initialProjects); automations = structuredClone(initialAutomations);
  wifiProfile = null; demoFaultActive = false; demoEnergy = 2.64; lastFaultSignature = null;
  document.querySelector('#wifi-state').innerHTML = '<i></i>Not configured';
  renderDevices(); renderRecentDevices(); renderProjects(); renderAutomations(); renderSwitches(); renderEnergy(); updateCounts(); showToast('Preview data reset.');
});
document.querySelector('#telemetry-range').addEventListener('change', (event) => showToast(`Showing demo readings: ${event.target.value.toLowerCase()}.`));
document.querySelector('#wifi-state').addEventListener('click', () => { if (wifiProfile) showToast(`${wifiProfile.name} is a saved demo profile, not a live Wi-Fi connection.`); });
window.addEventListener('popstate', syncRoute);
window.addEventListener('hashchange', syncRoute);
window.addEventListener('smartnest-settings-changed', renderWorkspaceProfile);
if (!window.location.hash) history.replaceState(null, '', '#welcome');
syncRoute();
renderWorkspaceProfile();
let installPrompt = null;
const installButtons = [...document.querySelectorAll('[data-pwa-install]')];
const installDialog = document.querySelector('#pwa-install-dialog');
const installInstructions = document.querySelector('#pwa-install-instructions');
const installMediaQuery = window.matchMedia('(display-mode: standalone)');
function isInstalled() {
  return installMediaQuery.matches || navigator.standalone === true;
}
let installationComplete = isInstalled();
function syncInstallButtons() {
  installButtons.forEach((button) => { button.hidden = installationComplete || isInstalled(); });
}
function showInstallInstructions() {
  const instructions = /iphone|ipad|ipod/i.test(navigator.userAgent)
    ? 'In Safari, tap Share, then choose “Add to Home Screen”. HOMIOT must be served from an HTTPS website.'
    : /android/i.test(navigator.userAgent)
      ? 'In Chrome, open the browser menu and choose “Install app” or “Add to Home screen”. HOMIOT must be served from HTTPS or localhost.'
      : 'Use your browser’s install icon in the address bar or choose “Install HOMIOT” from its menu. Installation requires HTTPS or localhost.';
  installInstructions.textContent = instructions;
  if (typeof installDialog.showModal === 'function') installDialog.showModal();
  else window.alert(instructions);
}
syncInstallButtons();
installMediaQuery.addEventListener?.('change', syncInstallButtons);
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
  syncInstallButtons();
});
document.addEventListener('click', async (event) => {
  if (event.target.closest('[data-pwa-install-close]')) installDialog.close();
  const installButton = event.target.closest('[data-pwa-install]');
  if (!installButton) return;
  if (isInstalled()) {
    syncInstallButtons();
    return;
  }
  if (!installPrompt) {
    showInstallInstructions();
    return;
  }
  try {
    const prompt = installPrompt;
    installPrompt = null;
    await prompt.prompt();
    const choice = await prompt.userChoice;
    if (choice.outcome === 'accepted') syncInstallButtons();
  } catch (error) {
    console.error('HOMIOT installation prompt failed.', error);
    showInstallInstructions();
  }
});
window.addEventListener('appinstalled', () => {
  installPrompt = null;
  installationComplete = true;
  syncInstallButtons();
  showToast('HOMIOT installed on this device.');
});
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch((error) => {
    console.error('HOMIOT offline support could not be enabled.', error);
  }));
}
const dateLabel = document.querySelector('#view-overview .page-heading .eyebrow');
dateLabel.firstChild.textContent = `${new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).format(new Date()).toUpperCase()} `;
renderDevices(); renderRecentDevices(); renderProjects(); renderAutomations(); renderSwitches(); renderEnergy(); updateCounts();
setInterval(renderEnergy, 3000);
