# HOMIOT workspace notes

- HOMIOT is a dependency-free browser prototype. Open `index.html` to run it; there is no package manager or build step.
- Keep hardware state and telemetry clearly identified as simulated until a real gateway and protocol adapters exist.
- The current product scope is a responsive studio UI for overview, projects, device inventory, automations, and bridge settings.
- Prefer semantic HTML, accessible labels, and vanilla JavaScript/CSS so the app remains runnable without installation.
- Do not claim that a simulated action controls a physical Wi-Fi or Bluetooth device.
- Voltage, current, switch states, and fault alerts in the home energy view are simulated; never present demo thresholds as protective settings.
- Keep mains wiring outside the browser app. Recommend certified enclosed meters and correctly rated switching hardware installed by a qualified electrician.
- Do not collect or store Wi-Fi passwords in this static app; use a device or gateway's secure local provisioning flow.
