(() => {
  const state = {
    baseUrl: '',
    token: '',
    homeId: '',
    integrations: [],
    devices: [],
    connected: false,
    message: '',
  };

  function snapshot() {
    return {
      baseUrl: state.baseUrl,
      homeId: state.homeId,
      integrations: structuredClone(state.integrations),
      devices: structuredClone(state.devices),
      connected: state.connected,
      message: state.message,
    };
  }

  function notify() {
    window.dispatchEvent(new CustomEvent('homiot-connectivity-changed', { detail: snapshot() }));
  }

  function configure({ baseUrl, token, homeId }) {
    let url;
    try {
      url = new URL(String(baseUrl || '').trim());
    } catch {
      throw new Error('Enter a valid backend URL.');
    }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password
      || url.search || url.hash || url.pathname !== '/') {
      throw new Error('Use an HTTP(S) backend origin only, without credentials or a path.');
    }
    const accessToken = String(token || '').trim();
    const authorizedHome = String(homeId || '').trim();
    if (accessToken.length < 32 || accessToken.length > 512) {
      throw new Error('The backend access token must contain 32–512 characters.');
    }
    if (!authorizedHome || authorizedHome.length > 100) {
      throw new Error('Enter the exact authorized home ID configured by the backend administrator.');
    }
    state.baseUrl = url.origin;
    state.token = accessToken;
    state.homeId = authorizedHome;
    state.integrations = [];
    state.devices = [];
    state.connected = false;
    state.message = 'Checking backend access…';
    notify();
  }

  async function request(path, { method = 'GET', body } = {}) {
    if (!state.baseUrl || !state.token || !state.homeId) {
      throw new Error('Connect to the integration backend first.');
    }
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 12000);
    let response;
    try {
      const authorizationScheme = 'Bearer';
      response = await fetch(`${state.baseUrl}/api/v1${path}`, {
        method,
        headers: {
          Authorization: `${authorizationScheme} ${state.token}`,
          ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        throw new Error('The backend request timed out. Check that the local backend is running and reachable.');
      }
      if (error instanceof TypeError) {
        throw new Error('The backend could not be reached. Check its URL, CORS allowlist, and network connection.');
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
    let payload;
    try {
      payload = await response.json();
    } catch {
      throw new Error(`The backend returned an invalid response (HTTP ${response.status}).`);
    }
    if (!response.ok) {
      throw new Error(typeof payload.error === 'string' ? payload.error : `Backend request failed (HTTP ${response.status}).`);
    }
    return payload;
  }

  async function refresh() {
    const session = await request('/session');
    if (!Array.isArray(session.homes) || !session.homes.includes(state.homeId)) {
      state.connected = false;
      state.message = 'This access token is not authorized for the selected home.';
      notify();
      throw new Error(state.message);
    }
    const home = `?homeId=${encodeURIComponent(state.homeId)}`;
    const [integrations, devices] = await Promise.all([
      request(`/integrations${home}`),
      request(`/devices${home}`),
    ]);
    if (!Array.isArray(integrations.integrations) || !Array.isArray(devices.devices)) {
      throw new Error('The backend returned an invalid integration or device list.');
    }
    state.integrations = integrations.integrations;
    state.devices = devices.devices;
    state.connected = true;
    state.message = `Authenticated as ${session.user.id}; ${state.integrations.length} integration(s), ${state.devices.length} imported device(s).`;
    notify();
    return snapshot();
  }

  async function load() {
    try {
      return await refresh();
    } catch (error) {
      state.connected = false;
      state.message = error instanceof Error ? error.message : 'Backend authentication failed.';
      notify();
      throw error;
    }
  }

  async function addIntegration(protocol, name, connection) {
    await request('/integrations', {
      method: 'POST',
      body: { protocol, name, homeId: state.homeId, connection },
    });
    state.message = 'Integration saved securely on the backend. Test it before discovery.';
    await refresh();
  }

  async function integrationAction(id, action) {
    if (!['test', 'discover'].includes(action)) throw new Error('Unsupported integration action.');
    const suffix = `?homeId=${encodeURIComponent(state.homeId)}`;
    await request(`/integrations/${encodeURIComponent(id)}/${action}${suffix}`, {
      method: 'POST',
      ...(action === 'discover' ? { body: { homeId: state.homeId } } : {}),
    });
    state.message = action === 'test' ? 'Integration connection verified by its adapter.' : 'Supported devices discovered and imported.';
    await refresh();
  }

  async function removeIntegration(id) {
    await request(`/integrations/${encodeURIComponent(id)}?homeId=${encodeURIComponent(state.homeId)}`, { method: 'DELETE' });
    state.message = 'Integration and its imported devices removed.';
    await refresh();
  }

  async function command(id, action, value) {
    const result = await request(`/devices/${encodeURIComponent(id)}/commands?homeId=${encodeURIComponent(state.homeId)}`, {
      method: 'POST',
      body: { action, value },
    });
    if (result.verified !== true || !result.device) {
      throw new Error('The backend did not verify the device state. No successful control is reported.');
    }
    state.message = 'Device state verified by the integration adapter.';
    await refresh();
  }

  async function assignRoom(id, roomId) {
    await request(`/devices/${encodeURIComponent(id)}?homeId=${encodeURIComponent(state.homeId)}`, {
      method: 'PATCH',
      body: { roomId },
    });
    state.message = 'Device room assignment saved on the backend.';
    await refresh();
  }

  async function readTelemetry({ channel, limit = 100 } = {}) {
    const query = new URLSearchParams({
      homeId: state.homeId,
      limit: String(limit),
    });
    if (channel) query.set('channel', channel);
    const result = await request(`/telemetry?${query}`);
    if (typeof result.available !== 'boolean' || !Array.isArray(result.readings)
      || result.count !== result.readings.length
      || result.readings.some((reading) => !reading || typeof reading.id !== 'string'
        || typeof reading.sourceId !== 'string' || typeof reading.channel !== 'string'
        || typeof reading.measuredAt !== 'string' || typeof reading.receivedAt !== 'string'
        || !reading.values || typeof reading.values !== 'object' || Array.isArray(reading.values))) {
      throw new Error('The backend returned an invalid telemetry history.');
    }
    return result;
  }

  function isBillingSettings(settings) {
    return settings && typeof settings === 'object'
      && typeof settings.homeId === 'string'
      && typeof settings.gridSourceId === 'string'
      && ['tariffPerKWh', 'exportTariffPerKWh', 'fixedCharges', 'additionalCharges']
        .every((field) => typeof settings[field] === 'number' && Number.isFinite(settings[field]))
      && typeof settings.updatedAt === 'string';
  }

  async function readBillingSettings() {
    const query = new URLSearchParams({ homeId: state.homeId });
    const result = await request(`/billing/settings?${query}`);
    if (result.settings !== null && !isBillingSettings(result.settings)) {
      throw new Error('The backend returned invalid billing settings.');
    }
    return result.settings;
  }

  async function saveBillingSettings(settings) {
    const result = await request('/billing/settings', {
      method: 'PUT',
      body: { ...settings, homeId: state.homeId },
    });
    if (!isBillingSettings(result.settings)) throw new Error('The backend did not confirm the saved billing settings.');
    state.message = 'Billing settings saved on the backend.';
    return result.settings;
  }

  async function readBillingEstimate() {
    const query = new URLSearchParams({ homeId: state.homeId });
    const result = await request(`/billing/estimate?${query}`);
    if (typeof result.available !== 'boolean'
      || (result.settings !== null && !isBillingSettings(result.settings))
      || (result.available && (!result.estimate || !['importKWh', 'importCost', 'exportCredit', 'fixedCharges', 'additionalCharges', 'total']
        .every((field) => typeof result.estimate[field] === 'number' && Number.isFinite(result.estimate[field]))
        || !(result.estimate.exportKWh === null || (typeof result.estimate.exportKWh === 'number' && Number.isFinite(result.estimate.exportKWh)))
        || typeof result.estimate.sourceId !== 'string'
        || !result.estimate.sourceId
        || typeof result.estimate.measuredAt !== 'string'
        || !Number.isFinite(Date.parse(result.estimate.measuredAt))))
      || (!result.available && (result.estimate !== null || typeof result.reason !== 'string'))) {
      throw new Error('The backend returned an invalid bill estimate.');
    }
    return result;
  }

  function clearCredentials() {
    state.baseUrl = '';
    state.token = '';
    state.homeId = '';
    state.integrations = [];
    state.devices = [];
    state.connected = false;
    state.message = '';
    notify();
  }

  window.HomiotConnectivityClient = {
    configure, load, refresh, getSnapshot: snapshot, addIntegration, integrationAction,
    removeIntegration, command, assignRoom, readTelemetry, readBillingSettings, saveBillingSettings,
    readBillingEstimate, clearCredentials,
  };
})();
