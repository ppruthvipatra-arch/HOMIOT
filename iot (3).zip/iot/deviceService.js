(() => {
  const STORAGE_KEY = 'smartnest.dashboard.devices.v1';
  const defaults = [
    { id: 'lights', name: 'Smart lights', room: 'Living Room', kind: 'light', on: true, online: true, watts: 68, brightness: 68, lightMode: 'warm' },
    { id: 'fan', name: 'Ceiling fan', room: 'Living Room', kind: 'fan', on: false, online: true, watts: 75, speed: 2 },
    { id: 'tv', name: 'Smart television', room: 'Living Room', kind: 'tv', on: false, online: true, watts: 110, volume: 24 },
    { id: 'ac', name: 'Air conditioner', room: 'Bedroom', kind: 'ac', on: true, online: true, watts: 920, temperature: 23, acMode: 'cool', fanSpeed: 2 },
    { id: 'plug', name: 'Smart plug', room: 'Kitchen', kind: 'plug', on: true, online: true, watts: 42 },
    { id: 'geyser', name: 'Geyser', room: 'Bathroom', kind: 'geyser', on: false, online: true, watts: 1500, temperature: 55 },
    { id: 'pump', name: 'Water pump', room: 'Outdoor', kind: 'pump', on: false, online: true, watts: 680, tankLevel: 72, durationMinutes: 0 },
    { id: 'exhaust', name: 'Exhaust fan', room: 'Bathroom', kind: 'exhaust', on: false, online: true, watts: 35, speed: 2 },
  ];
  const sceneNames = new Set(['good-morning', 'good-night', 'away-mode', 'movie-time']);
  const deviceKinds = new Set(['light', 'fan', 'ac', 'tv', 'geyser', 'pump', 'plug', 'exhaust']);
  const schedules = [];
  let state = { devices: clone(defaults), activeScene: null, schedules: clone(schedules), removedIds: [] };
  let homeScope = 'my-home';
  let loaded = false;

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function setHomeContext(homeId) {
    if (typeof homeId !== 'string' || !homeId.trim()) throw new Error('Choose a valid home context.');
    const nextScope = homeId === 'my-home' ? 'my-home' : homeId;
    if (nextScope === homeScope) return getDevices();
    ensureLoaded();
    persist(state);
    homeScope = nextScope;
    loaded = false;
    ensureLoaded();
    window.dispatchEvent(new CustomEvent('smartnest-devices-changed', {
      detail: { devices: clone(state.devices), schedules: clone(state.schedules), homeId: homeScope },
    }));
    return getDevices();
  }

  function getDevicesForHome(homeId) {
    if (homeId === homeScope) return getDevices();
    if (homeId === 'my-home') {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      return saved ? validateStoredState(JSON.parse(saved), true).devices : clone(defaults);
    }
    const saved = window.localStorage.getItem(storageKey(homeId));
    return saved ? validateStoredState(JSON.parse(saved), false).devices : [];
  }

  function setDeviceStateForHome(homeId, id, on) {
    if (typeof homeId !== 'string' || !homeId.trim() || typeof id !== 'string' || typeof on !== 'boolean') {
      throw new Error('Choose a valid home, device, and simulated state.');
    }
    if (homeId === homeScope) return toggleDevice(id, on);
    const saved = window.localStorage.getItem(storageKey(homeId));
    const next = saved
      ? validateStoredState(JSON.parse(saved), homeId === 'my-home')
      : { devices: homeId === 'my-home' ? clone(defaults) : [], activeScene: null, schedules: [], removedIds: [] };
    const device = next.devices.find((item) => item.id === id);
    if (!device) throw new Error('The selected demo device is not in this home.');
    if (!device.online) throw new Error(`${device.name} is offline; its state is unknown and no command was applied.`);
    device.on = on;
    next.activeScene = null;
    try {
      window.localStorage.setItem(storageKey(homeId), JSON.stringify({ version: 1, ...next }));
    } catch (error) {
      throw new Error(`Could not save this device preview in your browser: ${error instanceof Error ? error.message : 'storage is unavailable'}`);
    }
    window.dispatchEvent(new CustomEvent('smartnest-devices-changed', {
      detail: { devices: clone(next.devices), schedules: clone(next.schedules), homeId },
    }));
    return clone(device);
  }

  function removeHomeContext(homeId) {
    if (!homeId || homeId === 'my-home' || homeId === homeScope) throw new Error('Cannot remove the active or default device context.');
    window.localStorage.removeItem(storageKey(homeId));
  }

  function isValidTime(value) {
    if (typeof value !== 'string' || !/^\d{2}:\d{2}$/.test(value)) return false;
    const [hour, minute] = value.split(':').map(Number);
    return hour <= 23 && minute <= 59;
  }

  function isValidDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(`${value}T00:00:00`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }

  function storageKey(scope = homeScope) {
    return scope === 'my-home' ? STORAGE_KEY : `${STORAGE_KEY}.home.${encodeURIComponent(scope)}`;
  }

  function validateStoredState(value, includeDefaults = homeScope === 'my-home') {
    if (!value || value.version !== 1 || !Array.isArray(value.devices)) {
      throw new Error('Saved SmartNest demo data has an unsupported format.');
    }
    const savedById = new Map(value.devices.map((device) => [device && device.id, device]));
    const removedIds = value.removedIds === undefined ? [] : value.removedIds;
    if (!Array.isArray(removedIds) || removedIds.some((id) => !defaults.some((device) => device.id === id))) {
      throw new Error('Saved device inventory changes are invalid.');
    }
    const removed = new Set(removedIds);
    const knownIds = new Set(includeDefaults ? defaults.map((device) => device.id) : []);
    const validateDevice = (preset, saved) => {
      if (!saved || typeof saved.on !== 'boolean' || typeof saved.online !== 'boolean'
        || typeof saved.name !== 'string' || typeof saved.room !== 'string') {
        throw new Error('Saved SmartNest demo device data is incomplete.');
      }
      const device = { ...preset, on: saved.on, online: saved.online };
      device.name = saved.name.trim();
      device.room = saved.room;
      if (!device.name || device.name.length > 40 || typeof device.room !== 'string'
        || !device.room.trim() || device.room.length > 32) {
        throw new Error('Saved SmartNest device name or room is invalid.');
      }
      if (preset.id.startsWith('demo-')) {
        const displayType = saved.displayType === undefined ? saved.kind : saved.displayType;
        const category = saved.category === undefined ? 'Appliances' : saved.category;
        const icon = saved.icon === undefined ? '' : saved.icon;
        if (typeof displayType !== 'string' || !displayType.trim() || displayType.length > 40
          || typeof category !== 'string' || !category.trim() || category.length > 32
          || typeof icon !== 'string' || icon.length > 4) {
          throw new Error('Saved custom device display information is invalid.');
        }
        device.displayType = displayType;
        device.category = category;
        device.icon = icon;
      }
      if (!Number.isFinite(device.watts) || device.watts < 0 || device.watts > 5000) {
        throw new Error('Saved device power reading is invalid.');
      }
      for (const setting of ['brightness', 'speed', 'temperature', 'volume', 'fanSpeed', 'durationMinutes', 'tankLevel']) {
        if (setting in preset) {
          if (saved[setting] === undefined) continue;
          const limits = setting === 'brightness' || setting === 'volume' || setting === 'tankLevel' ? [0, 100]
            : setting === 'speed' || setting === 'fanSpeed' ? [1, 5]
              : setting === 'durationMinutes' ? [0, 1440]
                : preset.kind === 'ac' ? [16, 30] : [30, 75];
          if (!Number.isInteger(saved[setting]) || saved[setting] < limits[0] || saved[setting] > limits[1]) {
            throw new Error(`Saved ${preset.name} settings are invalid.`);
          }
          device[setting] = saved[setting];
        }
      }
      for (const setting of ['lightMode', 'acMode']) {
        if (setting in preset && typeof saved[setting] === 'string') device[setting] = saved[setting];
      }
      if (device.kind === 'light' && !['warm', 'neutral', 'cool'].includes(device.lightMode)) throw new Error('Saved light mode is invalid.');
      if (device.kind === 'ac' && !['cool', 'heat', 'dry', 'fan'].includes(device.acMode)) throw new Error('Saved AC mode is invalid.');
      return device;
    };
    const devices = (includeDefaults ? defaults : []).filter((preset) => !removed.has(preset.id)).map((preset) => {
      const saved = savedById.get(preset.id);
      return saved ? validateDevice(preset, saved) : clone(preset);
    });
    for (const saved of value.devices) {
      if (saved && !knownIds.has(saved.id)) {
        if (!deviceKinds.has(saved.kind)) throw new Error('Saved custom device type is invalid.');
        devices.push(validateDevice(saved, saved));
        knownIds.add(saved.id);
      }
    }
    if (value.activeScene !== null && !sceneNames.has(value.activeScene)) {
      throw new Error('Saved SmartNest scene data is invalid.');
    }
    const savedSchedules = value.schedules === undefined ? [] : value.schedules;
    if (!Array.isArray(savedSchedules) || savedSchedules.some((item) => !item || typeof item.id !== 'string'
      || !devices.some((device) => device.id === item.deviceId)
      || !isValidTime(item.onTime) || !isValidTime(item.offTime) || item.onTime === item.offTime
      || (item.date && !isValidDate(item.date))
      || !Array.isArray(item.days) || (!item.date && item.days.length === 0) || new Set(item.days).size !== item.days.length
      || item.days.some((day) => !Number.isInteger(day) || day < 0 || day > 6)
      || typeof item.enabled !== 'boolean')
      || new Set(savedSchedules.map((item) => item && item.id)).size !== savedSchedules.length) {
      throw new Error('Saved device schedule data is invalid.');
    }
    return { devices, activeScene: value.activeScene, schedules: clone(savedSchedules), removedIds: clone(removedIds) };
  }

  function persist(nextState) {
    try {
      window.localStorage.setItem(storageKey(), JSON.stringify({ version: 1, ...nextState }));
    } catch (error) {
      throw new Error(`Could not save this device preview in your browser: ${error instanceof Error ? error.message : 'storage is unavailable'}`);
    }
  }

  function ensureLoaded() {
    if (loaded) return;
    loaded = true;
    let saved;
    try {
      saved = window.localStorage.getItem(storageKey());
    } catch (error) {
      loaded = false;
      throw new Error(`Could not read saved device preview data: ${error instanceof Error ? error.message : 'storage is unavailable'}`);
    }
    if (saved === null) {
      if (homeScope !== 'my-home') state = { devices: [], activeScene: null, schedules: [], removedIds: [] };
      return;
    }
    try {
      state = validateStoredState(JSON.parse(saved), homeScope === 'my-home');
    } catch (error) {
      loaded = false;
      throw error instanceof Error ? error : new Error('Saved SmartNest demo data could not be read.');
    }
  }

  function update(mutator) {
    ensureLoaded();
    const next = clone(state);
    mutator(next);
    persist(next);
    state = next;
    window.dispatchEvent(new CustomEvent('smartnest-devices-changed', { detail: { devices: clone(state.devices), schedules: clone(state.schedules) } }));
    return clone(state.devices);
  }

  function getDevices() {
    ensureLoaded();
    return clone(state.devices);
  }

  function getDeviceById(id) {
    const device = getDevices().find((item) => item.id === id);
    if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
    return device;
  }

  function getDeviceStatus(id) {
    const device = getDevices().find((item) => item.id === id);
    if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
    return { on: device.on, online: device.online };
  }

  function toggleDevice(id, on) {
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      if (!device.online) throw new Error(`${device.name} is offline in this demo; no command was applied.`);
      device.on = typeof on === 'boolean' ? on : !device.on;
      next.activeScene = null;
    });
  }

  function updateDeviceSettings(id, settings) {
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      if (!device.online) throw new Error(`${device.name} is offline in this demo; no command was applied.`);
      const allowed = {
        light: ['lightMode'],
        ac: ['acMode', 'fanSpeed'],
        tv: ['volume'],
        fan: ['speed'],
        exhaust: ['speed'],
      }[device.kind] || [];
      for (const [key, value] of Object.entries(settings)) {
        if (!allowed.includes(key)) throw new Error(`This setting is not available for ${device.name}.`);
        if (!device.online) throw new Error(`${device.name} is offline in this demo; no command was applied.`);
        if (['fanSpeed', 'volume', 'speed'].includes(key) && !device.on) throw new Error(`${device.name} must be on before adjusting this control.`);
        if (key === 'lightMode' && !['warm', 'neutral', 'cool'].includes(value)) throw new Error('Choose a supported lighting mode.');
        if (key === 'acMode' && !['cool', 'heat', 'dry', 'fan'].includes(value)) throw new Error('Choose a supported air conditioner mode.');
        const bounds = key === 'volume' ? [0, 100] : [1, 5];
        if (['fanSpeed', 'volume'].includes(key) && (!Number.isInteger(value) || value < bounds[0] || value > bounds[1])) {
          throw new Error(`The requested ${key} value is outside its supported demo range.`);
        }
        device[key] = value;
      }
      next.activeScene = null;
    });
  }

  function setDeviceValue(id, key, value, minimum, maximum) {
    if (!Number.isFinite(value) || value < minimum || value > maximum) {
      throw new Error(`The requested ${key} value is outside its supported demo range.`);
    }
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device || !(key in device)) throw new Error(`This setting is not available for demo device: ${id}`);
      if (!device.online) throw new Error(`${device.name} is offline in this demo; no command was applied.`);
      if (!device.on) throw new Error(`${device.name} must be on before adjusting this control.`);
      device[key] = value;
      next.activeScene = null;
    });
  }

  function updateBrightness(id, brightness) {
    return setDeviceValue(id, 'brightness', brightness, 0, 100);
  }

  function updateFanSpeed(id, speed) {
    return setDeviceValue(id, 'speed', speed, 1, 5);
  }

  function updateTemperature(id, temperature) {
    const device = getDevices().find((item) => item.id === id);
    if (!device || !['ac', 'geyser'].includes(device.kind)) {
      throw new Error(`Temperature adjustment is not available for demo device: ${id}`);
    }
    const bounds = device.kind === 'ac' ? [16, 30] : [30, 75];
    return setDeviceValue(id, 'temperature', temperature, bounds[0], bounds[1]);
  }

  function executeScene(scene) {
    if (!sceneNames.has(scene)) throw new Error(`Unknown SmartNest demo scene: ${scene}`);
    return update((next) => {
      const byId = Object.fromEntries(next.devices.map((device) => [device.id, device]));
      if (scene === 'good-morning') {
        if (byId.lights?.online) { byId.lights.on = true; byId.lights.brightness = 75; }
        if (byId.fan?.online) byId.fan.on = true;
        if (byId.plug?.online) byId.plug.on = true;
      } else if (scene === 'good-night' || scene === 'away-mode') {
        next.devices.forEach((device) => { if (device.online) device.on = false; });
      } else {
        if (byId.lights?.online) { byId.lights.on = true; byId.lights.brightness = 20; }
        if (byId.tv?.online) byId.tv.on = true;
        if (byId.fan?.online) byId.fan.on = false;
      }
      next.activeScene = scene;
    });
  }

  function setAllDevices(on) {
    return update((next) => {
      next.devices.forEach((device) => { if (device.online) device.on = on; });
      next.activeScene = null;
    });
  }

  function setDevices(ids, on) {
    if (!Array.isArray(ids) || !ids.length || typeof on !== 'boolean'
      || ids.some((id) => typeof id !== 'string') || new Set(ids).size !== ids.length) {
      throw new Error('Choose one or more valid demo devices.');
    }
    return update((next) => {
      const selected = ids.map((id) => next.devices.find((device) => device.id === id));
      const unavailable = selected.find((device) => !device);
      if (unavailable) throw new Error('A selected demo device no longer exists.');
      const offline = selected.find((device) => !device.online);
      if (offline) throw new Error(`${offline.name} is offline in this demo; no command was applied.`);
      selected.forEach((device) => { device.on = on; });
      next.activeScene = null;
    });
  }

  function applyDeviceActions(actions) {
    if (!Array.isArray(actions) || !actions.length || actions.length > 32) {
      throw new Error('Choose at least one valid demo device action.');
    }
    const ids = actions.map((action) => action && action.deviceId);
    if (ids.some((id) => typeof id !== 'string' || !id) || new Set(ids).size !== ids.length) {
      throw new Error('Each demo device may only appear once in a scene or automation.');
    }
    let result;
    update((next) => {
      const applied = [];
      const skipped = [];
      actions.forEach((action) => {
        const device = next.devices.find((item) => item.id === action.deviceId);
        if (!device) {
          skipped.push({ id: action.deviceId, reason: 'Device is no longer in the preview.' });
          return;
        }
        if (!device.online) {
          skipped.push({ id: device.id, name: device.name, reason: 'Offline; no command was applied.' });
          return;
        }
        if (typeof action.on !== 'boolean') throw new Error(`Choose an on/off state for ${device.name}.`);
        const settings = action.settings || {};
        if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
          throw new Error(`Settings for ${device.name} are invalid.`);
        }
        const allowed = {
          light: ['brightness', 'lightMode'],
          fan: ['speed'],
          ac: ['temperature', 'fanSpeed', 'acMode'],
          tv: ['volume'],
          geyser: ['temperature'],
          pump: [],
          plug: [],
          exhaust: ['speed'],
        }[device.kind] || [];
        for (const [key, value] of Object.entries(settings)) {
          if (!allowed.includes(key)) throw new Error(`${key} is not available for ${device.name}.`);
          if (key === 'brightness' && (!Number.isInteger(value) || value < 0 || value > 100)) throw new Error('Brightness must be from 0 to 100%.');
          if (key === 'volume' && (!Number.isInteger(value) || value < 0 || value > 100)) throw new Error('Volume must be from 0 to 100%.');
          if (['speed', 'fanSpeed'].includes(key) && (!Number.isInteger(value) || value < 1 || value > 5)) throw new Error('Fan speed must be from 1 to 5.');
          if (key === 'temperature') {
            const bounds = device.kind === 'ac' ? [16, 30] : [30, 75];
            if (!Number.isInteger(value) || value < bounds[0] || value > bounds[1]) throw new Error(`Temperature must be from ${bounds[0]} to ${bounds[1]}°C.`);
          }
          if (key === 'lightMode' && !['warm', 'neutral', 'cool'].includes(value)) throw new Error('Choose a supported lighting tone.');
          if (key === 'acMode' && !['cool', 'heat', 'dry', 'fan'].includes(value)) throw new Error('Choose a supported air conditioner mode.');
          if (!action.on) throw new Error(`Turn ${device.name} on before applying its settings.`);
        }
        device.on = action.on;
        Object.assign(device, settings);
        applied.push({ id: device.id, name: device.name });
      });
      if (applied.length) next.activeScene = null;
      result = { applied, skipped };
    });
    return result;
  }

  function updateDeviceName(id, name) {
    const normalized = String(name).trim();
    if (!normalized || normalized.length > 40) throw new Error('Device names must be between 1 and 40 characters.');
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      device.name = normalized;
    });
  }

  function updateDeviceRoom(id, room) {
    const normalized = String(room).trim();
    if (!normalized || normalized.length > 32) throw new Error('Room names must be between 1 and 32 characters.');
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      device.room = normalized;
    });
  }

  function updateDeviceIcon(id, icon) {
    const normalized = String(icon ?? '').trim().slice(0, 4);
    if (!normalized) throw new Error('Choose a device icon.');
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      device.icon = normalized;
    });
  }

  function updateDeviceDetails(id, changes) {
    const name = String(changes.name ?? '').trim();
    const room = String(changes.room ?? '').trim();
    const icon = String(changes.icon ?? '').trim().slice(0, 4);
    if (!name || name.length > 40) throw new Error('Device names must be between 1 and 40 characters.');
    if (!room || room.length > 32) throw new Error('Room names must be between 1 and 32 characters.');
    if (!icon) throw new Error('Choose a device icon.');
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      device.name = name;
      device.room = room;
      device.icon = icon;
    });
  }

  function renameRoomDevices(previousName, nextName) {
    const previous = String(previousName).trim();
    const nextRoom = String(nextName).trim();
    if (!previous || !nextRoom || nextRoom.length > 32) throw new Error('Room names must be between 1 and 32 characters.');
    return update((next) => {
      next.devices.forEach((device) => {
        if (device.room === previous) device.room = nextRoom;
      });
    });
  }

  function removeDevice(id) {
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      if (defaults.some((item) => item.id === id) && !next.removedIds.includes(id)) next.removedIds.push(id);
      next.devices = next.devices.filter((device) => device.id !== id);
      next.schedules = next.schedules.filter((schedule) => schedule.deviceId !== id);
    });
  }

  function setDeviceOnline(id, online) {
    if (typeof online !== 'boolean') throw new Error('Choose a valid simulated connection state.');
    return update((next) => {
      const device = next.devices.find((item) => item.id === id);
      if (!device) throw new Error(`Unknown SmartNest demo device: ${id}`);
      device.online = online;
    });
  }

  function addDevice(kind, name, room, metadata = {}) {
    if (!deviceKinds.has(kind) || typeof room !== 'string' || !room.trim() || room.trim().length > 32) throw new Error('Choose a supported demo device type and room.');
    const normalized = String(name).trim();
    if (!normalized || normalized.length > 40) throw new Error('Device names must be between 1 and 40 characters.');
    const defaultsByKind = {
      light: { watts: 60, brightness: 60, lightMode: 'warm' },
      fan: { watts: 75, speed: 2 },
      ac: { watts: 900, temperature: 23, acMode: 'cool', fanSpeed: 2 },
      tv: { watts: 100, volume: 25 },
      geyser: { watts: 1500, temperature: 55 },
      pump: { watts: 650, durationMinutes: 0, tankLevel: 70 },
      plug: { watts: 40 },
      exhaust: { watts: 35, speed: 2 },
    };
    const device = {
      id: `demo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: normalized, room, kind, on: false, online: true, ...defaultsByKind[kind],
      displayType: String(metadata.displayType || kind).slice(0, 40),
      category: String(metadata.category || 'Appliances').slice(0, 32),
      icon: String(metadata.icon || '').slice(0, 4),
    };
    update((next) => { next.devices.push(device); });
    return device.id;
  }

  function getSchedules(deviceId) {
    ensureLoaded();
    return clone(state.schedules.filter((schedule) => !deviceId || schedule.deviceId === deviceId));
  }

  function scheduleDevice(schedule) {
    if (!schedule || typeof schedule.deviceId !== 'string'
      || !isValidTime(schedule.onTime) || !isValidTime(schedule.offTime)
      || schedule.onTime === schedule.offTime
      || (schedule.date && !isValidDate(schedule.date))
      || !Array.isArray(schedule.days) || (!schedule.date && schedule.days.length === 0)
      || new Set(schedule.days).size !== schedule.days.length
      || schedule.days.some((day) => !Number.isInteger(day) || day < 0 || day > 6)
      || typeof schedule.enabled !== 'boolean') {
      throw new Error('Choose a device, different valid times, and either a date or repeat weekdays.');
    }
    return update((next) => {
      if (!next.devices.some((device) => device.id === schedule.deviceId)) throw new Error('The selected demo device no longer exists.');
      if (schedule.id && !next.schedules.some((entry) => entry.id === schedule.id)) throw new Error('This demo schedule could not be found.');
      const item = { ...schedule, id: schedule.id || `schedule-${Date.now()}-${Math.random().toString(36).slice(2, 9)}` };
      if (!item.date) delete item.date;
      const index = next.schedules.findIndex((entry) => entry.id === item.id);
      if (index >= 0) next.schedules[index] = item;
      else next.schedules.push(item);
    });
  }

  function removeSchedule(id) {
    return update((next) => { next.schedules = next.schedules.filter((schedule) => schedule.id !== id); });
  }

  function setScheduleEnabled(id, enabled) {
    if (typeof enabled !== 'boolean') throw new Error('Choose whether the schedule is enabled.');
    return update((next) => {
      const schedule = next.schedules.find((item) => item.id === id);
      if (!schedule) throw new Error('This demo schedule could not be found.');
      schedule.enabled = enabled;
    });
  }

  function getEnergyConsumption(id) {
    const device = getDeviceById(id);
    const available = device.online;
    const multiplier = device.on ? 1 : 0.18;
    const dailyKwh = available ? Number((device.watts * multiplier * 5 / 1000).toFixed(2)) : null;
    return {
      watts: available ? (device.on ? device.watts : 0) : null,
      dailyKwh,
      monthlyKwh: available ? Number((dailyKwh * 30).toFixed(1)) : null,
      estimatedCost: available ? Number((dailyKwh * 8).toFixed(2)) : null,
      weeklyKwh: available ? [0.62, 0.54, 0.71, 0.66, 0.48, 0.74, dailyKwh] : [],
      simulated: true,
      available,
    };
  }

  function getActiveScene() {
    ensureLoaded();
    return state.activeScene;
  }

  function resetToDefaults() {
    const next = { devices: clone(defaults), activeScene: null, schedules: [], removedIds: [] };
    loaded = true;
    state = next;
    persist(next);
    return clone(state.devices);
  }

  window.addEventListener('storage', (event) => {
    if (event.key !== storageKey()) return;
    try {
      state = event.newValue ? validateStoredState(JSON.parse(event.newValue), homeScope === 'my-home')
        : homeScope === 'my-home'
          ? { devices: clone(defaults), activeScene: null, schedules: [], removedIds: [] }
          : { devices: [], activeScene: null, schedules: [], removedIds: [] };
      loaded = true;
      window.dispatchEvent(new CustomEvent('smartnest-devices-changed', { detail: { devices: clone(state.devices), schedules: clone(state.schedules) } }));
    } catch (error) {
      window.dispatchEvent(new CustomEvent('smartnest-storage-error', {
        detail: { message: error instanceof Error ? error.message : 'Shared demo device data is invalid.' },
      }));
    }
  });

  window.SmartNestDeviceService = {
    getDevices,
    setHomeContext,
    getDevicesForHome,
    setDeviceStateForHome,
    removeHomeContext,
    getDeviceById,
    getDeviceStatus,
    toggleDevice,
    updateDeviceSettings,
    updateBrightness,
    updateFanSpeed,
    updateTemperature,
    updateDeviceName,
    updateDeviceRoom,
    updateDeviceIcon,
    updateDeviceDetails,
    renameRoomDevices,
    removeDevice,
    setDeviceOnline,
    addDevice,
    getSchedules,
    scheduleDevice,
    removeSchedule,
    setScheduleEnabled,
    getEnergyConsumption,
    executeScene,
    setAllDevices,
    setDevices,
    applyDeviceActions,
    getActiveScene,
    resetToDefaults,
    getDefaultDevices: () => clone(defaults),
  };
})();
