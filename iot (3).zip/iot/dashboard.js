(() => {
  const service = window.SmartNestDeviceService;
  const screen = document.querySelector('#screen-dashboard');
  if (!service || !screen) return;

  const sceneLabels = {
    'good-morning': 'Good morning',
    'good-night': 'Good night',
    'away-mode': 'Away mode',
    'movie-time': 'Movie time',
  };
  const iconMarkup = {
    light: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M10 19.5a9 9 0 1 1 12 0c-1.6 1.2-2 2.8-2 3.5h-8c0-.7-.4-2.3-2-3.5Z"/><path d="M12.5 26h7m-6 3h5m-2.5-9v-7m-3 3 3 3 3-3"/></svg>',
    fan: '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="2.5"/><path d="M16 13c-1-8 2-10 5-9s3 7-3 11m1 3c7 1 9 4 7 7s-8 1-10-5m-2-2c-6 5-10 4-11 1s4-7 10-6"/></svg>',
    ac: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="6" width="24" height="13" rx="3"/><path d="M8 14h16m-12 5-2 5m8-5 2 5m-9 0h2m5 0h2"/></svg>',
    tv: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="6" width="24" height="18" rx="3"/><path d="m12 29 4-5 4 5m-7 0h6"/></svg>',
    geyser: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="7" y="4" width="18" height="24" rx="5"/><path d="M12 9h8m-8 5h8m-7 8c0-2 3-3 3-5 2 2 3 4 1 6a2.5 2.5 0 0 1-4-1Z"/></svg>',
    pump: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 24h22M8 24v-9h16v9M11 15v-4h10v4m-7-8a3 3 0 1 1 6 0v4"/><path d="M10 20h12m-9-3v6m6-6v6"/></svg>',
    plug: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M11 7v7m10-7v7m-14 0h18v3a9 9 0 0 1-9 9v4m-4-16v-3a4 4 0 0 1 8 0v3"/></svg>',
    exhaust: '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="4" width="24" height="24" rx="4"/><circle cx="16" cy="16" r="2"/><path class="fan-rotor" d="M16 13c-1-6 2-8 4-6s1 5-2 7m1 3c5 1 7 3 5 5s-6 0-7-4m-2-1c-4 3-7 3-7 1s3-5 7-4"/></svg>',
  };
  const roomWallpaperGradients = {
    living: 'linear-gradient(135deg,#dcecff,#eef5ff 58%,#dcefe8)',
    bedroom: 'linear-gradient(135deg,#e7e2fb,#f6efff 56%,#dce6fa)',
    kitchen: 'linear-gradient(135deg,#fff1dc,#fbf7ed 55%,#deefe4)',
    bathroom: 'linear-gradient(135deg,#d9f1f3,#f0fbfc 55%,#dce7f8)',
    dining: 'linear-gradient(135deg,#f9e4d8,#fff4e9 55%,#f4e3d5)',
    study: 'linear-gradient(135deg,#dce8f2,#eff5fb 55%,#dce5f0)',
    office: 'linear-gradient(135deg,#dce8f2,#eff5fb 55%,#dce5f0)',
    meeting: 'linear-gradient(135deg,#dce8f2,#eff5fb 55%,#dce5f0)',
    conference: 'linear-gradient(135deg,#dce8f2,#eff5fb 55%,#dce5f0)',
    hall: 'linear-gradient(135deg,#e7eddf,#f5f7ea 55%,#dde9dc)',
    garden: 'linear-gradient(135deg,#d8efdf,#eff8e8 55%,#d5e9d7)',
  };

  let devices = service.getDefaultDevices();
  let activeScene = null;
  let selectedRoom = 'All Devices';
  let searchTerm = '';
  let toastTimer;
  let loadNotice = '';
  let latestEnergyReading = null;
  let energyTelemetryError = '';
  let energyTelemetryRequest = 0;

  function showToast(message, error = false) {
    const toast = document.querySelector('#dashboard-toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.toggle('is-error', error);
    toast.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 3300);
  }

  function loadSavedState() {
    try {
      devices = service.getDevices();
      activeScene = service.getActiveScene();
    } catch (error) {
      loadNotice = error instanceof Error ? error.message : 'Saved demo data could not be loaded.';
      devices = service.getDefaultDevices();
      activeScene = null;
      try {
        devices = service.resetToDefaults();
        loadNotice = 'Saved demo data was unreadable; default demo devices have been restored.';
      } catch (storageError) {
        loadNotice = storageError instanceof Error ? `${loadNotice} ${storageError.message}` : loadNotice;
      }
    }
  }

  function runMutation(mutation) {
    try {
      devices = mutation();
      activeScene = service.getActiveScene();
      return true;
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'This demo action could not be completed.', true);
      return false;
    }
  }

  function deviceById(id) {
    return devices.find((device) => device.id === id);
  }

  function formatCount(count) {
    return `${count} ${count === 1 ? 'device' : 'devices'}`;
  }

  function renderEnergySummary() {
    const connectivity = window.HomiotConnectivityClient?.getSnapshot();
    const values = latestEnergyReading?.values;
    const energyWh = values?.energyTodayWh;
    const powerW = values?.powerW;
    const energyValue = typeof energyWh === 'number' && Number.isFinite(energyWh)
      ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(energyWh / 1000)} kWh`
      : energyTelemetryError ? 'Telemetry unavailable' : 'Waiting for sensor data';
    const powerValue = typeof powerW === 'number' && Number.isFinite(powerW)
      ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(powerW)} W`
      : energyTelemetryError ? 'Telemetry unavailable' : 'Current usage unavailable';
    const measuredAt = latestEnergyReading
      ? `Measured ${new Date(latestEnergyReading.measuredAt).toLocaleString()}`
      : energyTelemetryError || (connectivity?.connected ? 'No meter readings reported' : 'No meter source configured');
    const setText = (selector, value) => {
      const element = document.querySelector(selector);
      if (element) element.textContent = value;
    };
    setText('#dash-energy-kwh', energyValue);
    setText('#dash-energy-current', `${powerValue} · ${measuredAt}`);
    setText('#dash-energy-reading', energyValue);
    const card = document.querySelector('.stat-energy');
    if (card) card.setAttribute('aria-label', `${energyValue}. ${powerValue}. Open energy monitoring`);
  }

  async function refreshEnergySummary() {
    const requestId = ++energyTelemetryRequest;
    const client = window.HomiotConnectivityClient;
    if (!client || !client.getSnapshot().connected || typeof client.readTelemetry !== 'function') {
      latestEnergyReading = null;
      energyTelemetryError = '';
      renderEnergySummary();
      return;
    }
    try {
      const result = await client.readTelemetry({ limit: 100 });
      if (requestId !== energyTelemetryRequest) return;
      latestEnergyReading = result.readings.find((reading) => reading.channel === 'energy_meter'
        && (typeof reading.values.energyTodayWh === 'number' || typeof reading.values.powerW === 'number'))
        || result.readings.find((reading) => reading.channel === 'home_load'
          && (typeof reading.values.energyTodayWh === 'number' || typeof reading.values.powerW === 'number'))
        || null;
      energyTelemetryError = '';
    } catch (error) {
      if (requestId !== energyTelemetryRequest) return;
      latestEnergyReading = null;
      energyTelemetryError = error instanceof Error ? `Telemetry unavailable: ${error.message}` : 'Telemetry unavailable: backend request failed.';
    }
    renderEnergySummary();
  }

  function renderDate() {
    const date = document.querySelector('#dashboard-date');
    if (date) {
      date.textContent = new Intl.DateTimeFormat(undefined, { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date());
    }
  }

  function renderSummary() {
    const connectivity = window.HomiotConnectivityClient?.getSnapshot();
    const verifiedIntegration = connectivity?.connected
      ? connectivity.integrations.find((integration) => integration.status === 'connected')
      : null;
    const liveDevices = verifiedIntegration ? connectivity.devices : null;
    const inventory = liveDevices || devices;
    const previewActiveCount = devices.filter((device) => device.online && device.on).length;
    const previewInactiveCount = devices.filter((device) => device.online && !device.on).length;
    const activeCount = liveDevices
      ? liveDevices.filter((device) => device.availability === 'online' && device.capabilities?.includes('power') && device.state?.power === true).length
      : devices.filter((device) => device.online && device.on).length;
    const inactiveCount = liveDevices
      ? liveDevices.filter((device) => device.availability === 'online' && device.capabilities?.includes('power') && device.state?.power === false).length
      : devices.filter((device) => device.online && !device.on).length;
    const setText = (selector, value) => {
      const element = document.querySelector(selector);
      if (element) element.textContent = value;
    };
    setText('#dash-device-total', String(inventory.length));
    setText('#dash-device-active', String(activeCount));
    setText('#dash-device-inactive', String(inactiveCount));
    setText('#dash-device-total-detail', liveDevices ? 'Verified integration inventory' : 'Preview inventory');
    setText('#dash-device-active-detail', liveDevices ? 'Reported on · verified' : 'Simulated state');
    setText('#dash-device-inactive-detail', liveDevices ? 'Reported off · verified' : 'Simulated state');
    document.querySelector('[data-home-device-total]').textContent = String(devices.length);
    document.querySelector('[data-home-device-active]').textContent = String(previewActiveCount);
    document.querySelector('[data-home-device-inactive]').textContent = String(previewInactiveCount);
    if (window.SmartNestHomeService) {
      const homes = window.SmartNestHomeService.getSnapshot().homes;
      const allDevices = homes.flatMap((home) => service.getDevicesForHome(home.id));
      document.querySelector('#dash-home-count').textContent = String(homes.length);
      document.querySelector('#dash-room-count').textContent = String(homes.reduce((total, home) => total + home.rooms.length, 0));
      document.querySelector('#dash-global-device-count').textContent = String(allDevices.filter((device) => device.online && device.on).length);
      document.querySelector('#dash-online-count').textContent = String(allDevices.filter((device) => device.online).length);
    }
    const home = window.SmartNestHomeService?.getCurrentHome();
    const homeName = document.querySelector('#dashboard-home-name');
    const homeLocation = document.querySelector('#dashboard-home-location');
    const profile = window.SmartNestSettingsService?.getSnapshot().profile;
    const preferredName = profile?.preferredName || profile?.name?.trim().split(/\s+/)[0] || 'Home owner';
    const dashboardTitle = document.querySelector('#dashboard-title');
    if (dashboardTitle) {
      const hour = new Date().getHours();
      const timeGreeting = hour >= 5 && hour < 12 ? 'Good morning'
        : hour >= 12 && hour < 17 ? 'Good afternoon'
          : hour >= 17 && hour < 21 ? 'Good evening' : 'Good night';
      const name = document.createElement('em');
      name.textContent = `${preferredName}.`;
      dashboardTitle.replaceChildren(document.createTextNode(`${timeGreeting}, `), name);
    }
    if (homeName && home) homeName.textContent = home.name;
    if (homeLocation && home) homeLocation.textContent = [home.city, home.state].filter(Boolean).join(', ') || 'Your selected home';
    document.querySelectorAll('[data-user-name]').forEach((node) => {
      node.textContent = profile?.preferredName || profile?.name || 'Home owner';
    });
    document.querySelectorAll('[data-user-avatar]').forEach((node) => {
      if (profile?.avatar) {
        const image = document.createElement('img');
        image.src = profile.avatar;
        image.alt = '';
        node.replaceChildren(image);
      } else {
        node.textContent = preferredName.charAt(0).toUpperCase();
      }
    });
    const headerWelcome = document.querySelector('#dashboard-header-welcome');
    if (headerWelcome) headerWelcome.textContent = `Welcome back, ${preferredName}`;
    const profileHome = document.querySelector('#dashboard-profile-home');
    if (profileHome && profile) profileHome.textContent = profile.home;
    document.querySelector('#room-count-all').textContent = formatCount(devices.length);

    document.querySelectorAll('[data-room-count]').forEach((count) => {
      count.textContent = String(devices.filter((device) => device.room.toLowerCase() === count.dataset.roomCount.toLowerCase()).length);
    });
    document.querySelector('#room-count-all').textContent = `${formatCount(devices.length)} · ${previewActiveCount} active`;
    renderEnergySummary();
    setText('#dash-gateway-status', verifiedIntegration ? 'Connected' : 'Not connected');
    setText('#dash-gateway-detail', verifiedIntegration
      ? `${verifiedIntegration.protocol === 'home_assistant' ? 'Home Assistant' : 'MQTT'} · verified`
      : connectivity?.connected ? 'No connected integration' : 'Backend not connected');
    setText('#dashboard-gateway-label', verifiedIntegration ? 'Gateway connection verified' : 'Gateway not connected');
    setText('#dashboard-gateway-detail', verifiedIntegration
      ? `${verifiedIntegration.protocol === 'home_assistant' ? 'Home Assistant' : 'MQTT'} · verified`
      : connectivity?.connected ? 'No connected integration' : 'Backend not connected');
    setText('#dash-environment-gateway', verifiedIntegration ? 'Connected' : 'Not connected');
    setText('#dash-environment-gateway-detail', verifiedIntegration
      ? `${verifiedIntegration.protocol === 'home_assistant' ? 'Home Assistant' : 'MQTT'} · verified`
      : connectivity?.connected ? 'No connected integration' : 'Backend not connected');
    setText('#dash-environment-gateway-state', verifiedIntegration ? 'Verified' : 'Unavailable');
    const gatewayCard = document.querySelector('.stat-gateway');
    if (gatewayCard) {
      gatewayCard.setAttribute('aria-label', verifiedIntegration
        ? 'Home integration connected. Open device integrations'
        : 'No verified home connection. Open device integrations');
      gatewayCard.dataset.dashRoute = 'dash-connectivity';
    }
  }

  function renderRooms() {
    const selector = document.querySelector('.room-selector');
    selector.querySelectorAll('[data-custom-room-filter]').forEach((button) => button.remove());
    const fixedRooms = new Set(['All Devices', 'Living Room', 'Bedroom', 'Kitchen', 'Bathroom', 'Outdoor', 'Dining Room', 'Office', 'Meeting Room', 'Conference Room', 'Hall']);
    const homeRoomEntries = window.SmartNestHomeService?.getRooms() || [];
    const homeRooms = homeRoomEntries.map((room) => room.name);
    const customRooms = [...new Set([...homeRooms, ...devices.map((device) => device.room)].filter((room) => !fixedRooms.has(room)))];
    customRooms.forEach((room) => {
      const count = devices.filter((device) => device.room === room);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'room-pill room-card room-photo-custom';
      button.dataset.roomFilter = room;
      button.dataset.customRoomFilter = 'true';
      button.setAttribute('aria-pressed', 'false');
      const roomEntry = homeRoomEntries.find((item) => item.name === room);
      button.innerHTML = '<span class="room-card-top"><span class="room-pill-icon room-outdoor" aria-hidden="true"></span><span class="room-status"><i></i> HOME · DEMO</span></span><span class="room-card-copy"><b></b><small><span data-room-count></span> devices · sample readings</small><span class="room-card-open">Open room <i>↗</i></span></span>';
      button.querySelector('.room-pill-icon').textContent = roomEntry?.icon || '⌂';
      if (roomEntry?.wallpaper?.startsWith('data:image/')) {
        button.classList.add('has-room-wallpaper', 'is-custom-wallpaper');
        button.style.backgroundImage = `linear-gradient(100deg,#13233b99,#13233b36),url("${roomEntry.wallpaper}")`;
      } else if (roomWallpaperGradients[roomEntry?.wallpaper]) {
        button.classList.add('has-room-wallpaper');
        button.style.backgroundImage = roomWallpaperGradients[roomEntry.wallpaper];
      }
      const label = button.querySelector('.room-card-copy > b');
      label.append(document.createTextNode(room));
      button.querySelector('[data-room-count]').textContent = String(count.length);
      selector.append(button);
    });
    selector.querySelectorAll('[data-room-filter]').forEach((button) => {
      const roomEntry = homeRoomEntries.find((item) => item.name === button.dataset.roomFilter);
      if (!roomEntry) return;
      if (roomEntry.wallpaper?.startsWith('data:image/')) {
        button.classList.add('has-room-wallpaper', 'is-custom-wallpaper');
        button.style.backgroundImage = `linear-gradient(100deg,#13233b99,#13233b36),url("${roomEntry.wallpaper}")`;
      } else if (roomWallpaperGradients[roomEntry.wallpaper]) {
        button.classList.add('has-room-wallpaper');
        button.style.backgroundImage = roomWallpaperGradients[roomEntry.wallpaper];
      }
    });
    document.querySelectorAll('[data-room-filter]').forEach((button) => {
      const active = button.dataset.roomFilter === selectedRoom;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-pressed', 'true');
      else button.setAttribute('aria-pressed', 'false');
    });
  }

  function deviceControlMarkup(device) {
    if (device.kind === 'light') {
      const adjustable = device.on && device.online;
      return `<div class="device-control device-brightness${adjustable ? '' : ' is-disabled'}"><div class="device-control-heading"><span>Brightness</span><strong data-device-value="brightness">${device.brightness}%</strong></div><input class="device-range" type="range" min="0" max="100" step="1" value="${device.brightness}" data-device-setting="brightness" data-device-id="${device.id}" aria-label="${device.name} brightness"${adjustable ? '' : ' disabled'}><div class="device-mode-picker">${['warm', 'neutral', 'cool'].map((mode) => `<button type="button" class="${device.lightMode === mode ? 'active' : ''}" data-device-setting="lightMode" data-setting-value="${mode}" data-device-id="${device.id}" aria-pressed="${device.lightMode === mode}"${adjustable ? '' : ' disabled'}>${mode}</button>`).join('')}</div></div>`;
    }
    if (device.kind === 'fan' || device.kind === 'exhaust') {
      const adjustable = device.on && device.online;
      return `<div class="device-control device-stepper-control"><span>${device.kind === 'fan' ? 'Fan speed' : 'Vent speed'}</span><div class="device-stepper"><button type="button" data-device-adjust="speed" data-device-id="${device.id}" data-step="-1" aria-label="Decrease ${device.name} speed"${adjustable ? '' : ' disabled'}>−</button><strong data-device-value="speed">${device.speed}<small> / 5</small></strong><button type="button" data-device-adjust="speed" data-device-id="${device.id}" data-step="1" aria-label="Increase ${device.name} speed"${adjustable ? '' : ' disabled'}>+</button></div></div>`;
    }
    if (device.kind === 'ac' || device.kind === 'geyser') {
      const label = device.kind === 'ac' ? 'Temperature · Cool mode' : 'Water temperature';
      const adjustable = device.on && device.online;
      return `<div class="device-control device-stepper-control"><span>${label}</span><div class="device-stepper"><button type="button" data-device-adjust="temperature" data-device-id="${device.id}" data-step="-1" aria-label="Lower ${label.toLowerCase()}"${adjustable ? '' : ' disabled'}>−</button><strong data-device-value="temperature">${device.temperature}<small>°C</small></strong><button type="button" data-device-adjust="temperature" data-device-id="${device.id}" data-step="1" aria-label="Raise ${label.toLowerCase()}"${adjustable ? '' : ' disabled'}>+</button></div></div>`;
    }
    if (device.kind === 'tv') {
      const adjustable = device.on && device.online;
      return `<div class="device-control device-brightness${adjustable ? '' : ' is-disabled'}"><div class="device-control-heading"><span>Volume</span><strong data-device-value="volume">${device.volume}%</strong></div><input class="device-range" type="range" min="0" max="100" value="${device.volume}" data-device-setting="volume" data-device-id="${device.id}" aria-label="${device.name} volume"${adjustable ? '' : ' disabled'}></div>`;
    }
    const detail = device.kind === 'tv' ? 'Entertainment' : device.kind === 'pump' ? 'Water system' : 'Connected accessory';
    const detailValue = device.kind === 'plug'
      ? (device.online ? `${device.on ? device.watts : 0} W <small>demo</small>` : 'Unavailable · offline')
      : device.kind === 'pump'
        ? (device.online ? (device.on ? 'Running · demo' : 'Idle · demo') : 'State unknown · offline')
        : detail;
    return `<div class="device-control device-text-control"><span>${device.kind === 'plug' ? 'Power use' : 'Device type'}</span><strong>${detailValue}</strong></div>`;
  }

  function renderDeviceCard(device) {
    const onlineLabel = device.online ? 'Demo online' : 'Demo offline';
    const homeId = window.SmartNestHomeService?.getCurrentHomeId() || '';
    const actions = [
      ['device-settings', 'Device settings'], ['device-rename', 'Rename device'],
      ['device-edit', 'Edit device'], ['device-icon', 'Change device icon'],
      ['device-move', 'Move to another room'],
    ];
    return `<article class="device-card${device.online && device.on ? ' is-on' : ''}${device.online ? '' : ' is-offline'}" data-device-card="${device.id}" data-delete-action="device-remove" data-item-id="${device.id}" data-home-id="${homeId}" aria-description="Press and hold for three seconds, then drag to the delete target. You can also focus this card and press Delete.">
      <div class="device-card-heading"><button class="device-card-open" data-device-open="${device.id}" aria-label="Open ${device.name} details"><span class="device-icon device-icon-${device.kind}">${iconMarkup[device.kind]}</span><span class="device-card-title"><h3>${device.name}</h3><span>${device.room}</span></span></button><details class="home-action-menu" data-home-id="${homeId}"><summary aria-label="More device actions for ${device.name}" title="More actions">•••</summary><div class="home-action-menu-list" role="menu">${actions.map(([action, label]) => `<button type="button" role="menuitem" data-home-action="${action}" data-item-id="${device.id}"${action === 'device-remove' ? ' class="is-danger"' : ''}>${label}</button>`).join('')}</div></details><label class="device-toggle" title="Toggle ${device.name}"><input type="checkbox" data-device-toggle="${device.id}" aria-label="${device.online ? `Turn ${device.name} ${device.on ? 'off' : 'on'}` : `${device.name} state unavailable while offline`}" aria-checked="${device.online ? device.on : 'mixed'}"${device.online && device.on ? ' checked' : ''}${device.online ? '' : ' disabled'}><span class="device-toggle-track"></span></label></div>
      <div class="device-card-status"><span class="device-state-label"><i></i>${device.online ? (device.on ? 'On · simulated' : 'Off · simulated') : 'State unknown · offline'}</span><span class="device-connect-label"><i></i>${onlineLabel}</span></div>
      ${deviceControlMarkup(device)}
    </article>`;
  }

  function renderDevices() {
    const grid = document.querySelector('#dashboard-device-grid');
    const query = searchTerm.trim().toLowerCase();
    const filtered = devices.filter((device) => (selectedRoom === 'All Devices' || device.room === selectedRoom)
      && (!query || device.name.toLowerCase().includes(query) || device.room.toLowerCase().includes(query) || device.kind.toLowerCase().includes(query)));
    const showCameraPlaceholder = selectedRoom === 'All Devices'
      && (!query || ['camera', 'cctv', 'security'].some((term) => term.includes(query) || query.includes(term)));
    const cameraPlaceholder = showCameraPlaceholder
      ? `<article class="device-card security-camera-card" aria-label="Offline camera inventory preview">
          <div class="device-card-heading"><div class="device-card-open"><span class="device-icon device-icon-camera"><svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="8" width="17" height="16" rx="4"/><path d="m21 13 7-4v18l-7-4z"/><circle cx="12.5" cy="16" r="3"/></svg></span><span class="device-card-title"><h3>Security camera</h3><span>Not paired · offline</span></span></div><label class="device-toggle" title="Camera control unavailable"><input type="checkbox" disabled aria-label="Security camera is offline and cannot be controlled"><span class="device-toggle-track"></span></label></div>
          <div class="device-card-status"><span class="device-state-label"><i></i>Unavailable · offline</span><span class="device-connect-label"><i></i>Preview only</span></div>
          <div class="camera-preview-note"><span>◉</span><span><b>No live feed</b><small>Camera service not connected</small></span></div>
          <button type="button" class="camera-preview-link" data-dash-route="dash-cameras">Open security center <span>↗</span></button>
        </article>` : '';
    grid.innerHTML = `${filtered.map(renderDeviceCard).join('')}${cameraPlaceholder}`;
    document.querySelector('#device-result-count').textContent = String(filtered.length + (showCameraPlaceholder ? 1 : 0));
    document.querySelector('#device-empty-state').hidden = filtered.length !== 0 || showCameraPlaceholder;
    grid.hidden = filtered.length === 0 && !showCameraPlaceholder;
  }

  function renderScenes() {
    document.querySelectorAll('[data-scene]').forEach((button) => {
      const active = button.dataset.scene === activeScene;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    document.querySelector('#active-scene-label').textContent = activeScene ? `Active · ${sceneLabels[activeScene]}` : 'No scene active';
  }

  function renderDashboard() {
    renderDate();
    renderSummary();
    renderRooms();
    renderDevices();
    renderScenes();
  }

  function handleSettingInput(event) {
    const input = event.target.closest('[data-device-setting]');
    if (!input) return;
    const device = deviceById(input.dataset.deviceId);
    const value = Number(input.value);
    if (!device) return;
    const method = input.dataset.deviceSetting === 'brightness' ? service.updateBrightness
      : input.dataset.deviceSetting === 'volume' ? (id, amount) => service.updateDeviceSettings(id, { volume: amount }) : null;
    if (!method || !runMutation(() => method(input.dataset.deviceId, value))) return;
    const card = input.closest('[data-device-card]');
    const valueLabel = card.querySelector(`[data-device-value="${input.dataset.deviceSetting}"]`);
    if (valueLabel) valueLabel.textContent = `${value}%`;
    const isOn = deviceById(input.dataset.deviceId).on;
    input.setAttribute('aria-valuetext', `${value}%${isOn ? '' : ', device is off'}`);
  }

  function setRoute(route) {
    if (typeof window.setRoute === 'function') window.setRoute(route);
    else window.location.hash = route;
  }

  function handleRoute(route) {
    if (!route.startsWith('dash') && route !== 'dashboard') return;
    const content = document.querySelector('#dashboard-content');
    const advancedRoutes = new Set(['dash-automation', 'dash-schedules', 'dash-energy', 'dash-billing', 'dash-solar', 'dash-scenes', 'dash-notifications', 'dash-family', 'dash-security']);
    content.hidden = advancedRoutes.has(route);
    content.dataset.route = route;
    document.querySelector('#dashboard-profile-panel').hidden = route !== 'dash-profile';
    const selectedTab = route === 'dash-energy' || route === 'dash-billing' ? 'dash-energy'
      : route === 'dash-solar' ? 'dash-solar'
      : route === 'dash-automation' || route === 'dash-schedules' ? 'dash-automation'
        : route === 'dash-devices' || route === 'dash-all-devices' || route === 'dash-connectivity' || route.startsWith('dash-device-') ? 'dash-devices'
          : route === 'dash-profile' || route === 'dash-settings' || route === 'dash-wifi' || route === 'dash-user-profile' ? 'dash-profile'
            : 'dashboard';
    document.querySelectorAll('.dashboard-primary-link').forEach((tab) => {
      const active = tab.dataset.mainRoute === selectedTab;
      tab.classList.toggle('active', active);
      tab.classList.toggle('is-active', active);
      if (active) tab.setAttribute('aria-current', 'page');
      else tab.removeAttribute('aria-current');
    });
    const sideRoute = route === 'dash-all-devices' || route.startsWith('dash-device-') ? 'dash-devices'
      : route === 'dash-home-overview' || route === 'dash-home-rooms' || route === 'dash-room-detail' ? 'dash-home-rooms'
        : route === 'dash-security' || route === 'dash-camera-live' || route === 'dash-recordings' ? 'dash-cameras'
          : route === 'dash-automation' || route === 'dash-schedules' ? 'dash-automation'
            : route === 'dash-energy' || route === 'dash-billing' ? 'dash-energy'
              : route === 'dash-solar' ? 'dash-solar'
              : route === 'dash-settings' || route === 'dash-home-settings' || route.startsWith('dash-') && ['dash-wifi', 'dash-privacy', 'dash-preferences', 'dash-user-profile', 'dash-help'].includes(route) ? 'dash-settings'
                : route;
    document.querySelectorAll('.dashboard-side-link[data-dash-route]').forEach((link) => {
      const current = link.dataset.dashRoute === sideRoute;
      link.classList.toggle('is-current', current);
      if (current) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    closeSidebar();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (route === 'dashboard') {
      renderSummary();
      refreshEnergySummary();
    }
  }

  function closeSidebar() {
    const dashboard = document.querySelector('.dashboard-screen');
    const toggle = document.querySelector('#dashboard-menu-toggle');
    dashboard?.classList.remove('sidebar-open');
    toggle?.setAttribute('aria-expanded', 'false');
    toggle?.setAttribute('aria-label', 'Open navigation');
  }

  document.addEventListener('click', (event) => {
    const menuToggle = event.target.closest('#dashboard-menu-toggle');
    if (menuToggle) {
      const dashboard = document.querySelector('.dashboard-screen');
      const opened = dashboard.classList.toggle('sidebar-open');
      menuToggle.setAttribute('aria-expanded', String(opened));
      menuToggle.setAttribute('aria-label', opened ? 'Close navigation' : 'Open navigation');
      return;
    }
    if (event.target.closest('#dashboard-sidebar-backdrop')) {
      closeSidebar();
      return;
    }
    const assistantButton = event.target.closest('[data-assistant-listen]');
    if (assistantButton) {
      const status = document.querySelector('#assistant-status');
      const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!Recognition) {
        status.textContent = 'Voice input is not supported by this browser. Use the navigation above instead.';
        return;
      }
      const recognition = new Recognition();
      recognition.lang = window.SmartNestSettingsService?.getSnapshot().profile.preferredLanguage || navigator.language;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      recognition.onresult = (resultEvent) => {
        const command = resultEvent.results[0][0].transcript.trim().toLowerCase();
        const match = command.match(/(?:open|show|go to|navigate to)\s+(home|devices|automation|energy|solar|renewable energy|profile)/);
        const routes = { home: 'dashboard', devices: 'dash-devices', automation: 'dash-automation', energy: 'dash-energy', solar: 'dash-solar', 'renewable energy': 'dash-solar', profile: 'dash-profile' };
        if (!match) {
          status.textContent = `I couldn't match “${command}”. Try “open energy” or “show devices.”`;
          return;
        }
        status.textContent = `Opening ${match[1]}.`;
        setRoute(routes[match[1]]);
      };
      recognition.onerror = (errorEvent) => {
        status.textContent = `Voice input unavailable: ${errorEvent.error}.`;
      };
      status.textContent = 'Listening for a navigation command…';
      try {
        recognition.start();
      } catch (error) {
        status.textContent = `Voice input could not start: ${error instanceof Error ? error.message : 'browser permission is unavailable'}.`;
      }
      return;
    }
    const routeButton = event.target.closest('[data-dash-route]');
    if (routeButton) {
      event.preventDefault();
      setRoute(routeButton.dataset.dashRoute);
      return;
    }

    const deviceOpen = event.target.closest('[data-device-open]');
    if (deviceOpen) {
      setRoute(`dash-device-${deviceOpen.dataset.deviceOpen}`);
      return;
    }

    const roomButton = event.target.closest('[data-room-filter]');
    if (roomButton) {
      selectedRoom = roomButton.dataset.roomFilter;
      renderRooms();
      renderDevices();
      return;
    }

    if (event.target.closest('[data-clear-device-filter]')) {
      selectedRoom = 'All Devices';
      searchTerm = '';
      document.querySelector('#dashboard-search').value = '';
      renderRooms();
      renderDevices();
      return;
    }

    const masterButton = event.target.closest('[data-master-control]');
    if (masterButton) {
      const turnOn = masterButton.dataset.masterControl === 'on';
      if (runMutation(() => service.setAllDevices(turnOn))) {
        renderDashboard();
        showToast(`All demo devices ${turnOn ? 'turned on' : 'turned off'} · simulated only.`);
      }
      return;
    }

    const adjustButton = event.target.closest('[data-device-adjust]');
    if (adjustButton) {
      const device = deviceById(adjustButton.dataset.deviceId);
      if (!device) return;
      const setting = adjustButton.dataset.deviceAdjust;
      const nextValue = device[setting] + Number(adjustButton.dataset.step);
      const method = setting === 'speed' ? (device.kind === 'ac'
        ? (id, value) => service.updateDeviceSettings(id, { fanSpeed: value })
        : service.updateFanSpeed) : service.updateTemperature;
      if (runMutation(() => method(device.id, nextValue))) {
        renderSummary();
        renderDevices();
      }
      return;
    }

    const sceneButton = event.target.closest('[data-scene]');
    if (sceneButton) {
      if (runMutation(() => service.executeScene(sceneButton.dataset.scene))) {
        renderDashboard();
        showToast(`${sceneLabels[sceneButton.dataset.scene]} applied to the local demo · no hardware connected.`);
      }
      return;
    }

    const settingButton = event.target.closest('[data-device-setting]');
    if (settingButton && settingButton.tagName === 'BUTTON') {
      if (runMutation(() => service.updateDeviceSettings(settingButton.dataset.deviceId, { lightMode: settingButton.dataset.settingValue }))) {
        renderDashboard();
      }
      return;
    }

    if (event.target.closest('#dashboard-notifications')) {
      const button = document.querySelector('#dashboard-notifications');
      const popover = document.querySelector('#notification-popover');
      const open = popover.hidden;
      popover.hidden = !open;
      button.setAttribute('aria-expanded', String(open));
      return;
    }
    if (event.target.closest('#close-notifications')) {
      document.querySelector('#notification-popover').hidden = true;
      document.querySelector('#dashboard-notifications').setAttribute('aria-expanded', 'false');
      return;
    }
    if (document.querySelector('#notification-popover').hidden === false
      && !event.target.closest('#notification-popover')
      && !event.target.closest('#dashboard-notifications')) {
      document.querySelector('#notification-popover').hidden = true;
      document.querySelector('#dashboard-notifications').setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('change', (event) => {
    const toggle = event.target.closest('[data-device-toggle]');
    if (!toggle) return;
    if (runMutation(() => service.toggleDevice(toggle.dataset.deviceToggle, toggle.checked))) {
      renderDashboard();
      const device = deviceById(toggle.dataset.deviceToggle);
      showToast(`${device.name} ${device.on ? 'on' : 'off'} · simulated only.`);
    }
  });

  window.addEventListener('smartnest-devices-changed', () => {
    try {
      devices = service.getDevices();
      activeScene = service.getActiveScene();
      if (document.activeElement?.matches('[data-device-setting="brightness"], [data-device-setting="volume"]')) renderSummary();
      else renderDashboard();
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Device preview could not be refreshed.', true);
    }
  });
  window.addEventListener('smartnest-home-changed', () => {
    selectedRoom = 'All Devices';
    searchTerm = '';
    document.querySelector('#dashboard-search').value = '';
    renderDashboard();
  });
  window.addEventListener('smartnest-settings-changed', () => {
    renderSummary();
    if (window.location.hash !== '#dashboard') return;
  });
  window.addEventListener('homiot-connectivity-changed', () => {
    renderSummary();
    refreshEnergySummary();
  });

  window.addEventListener('smartnest-storage-error', (event) => {
    showToast(event.detail?.message || 'Shared device preview could not be refreshed.', true);
  });

  document.addEventListener('input', handleSettingInput);
  document.querySelector('#dashboard-search').addEventListener('input', (event) => {
    searchTerm = event.target.value;
    renderDevices();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeSidebar();
    if (event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey
      && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)
      && !screen.hidden) {
      event.preventDefault();
      document.querySelector('#dashboard-search').focus();
    }
  });

  loadSavedState();
  renderDashboard();
  if (loadNotice) showToast(loadNotice, true);

  window.SmartNestDashboard = { handleRoute };
})();
