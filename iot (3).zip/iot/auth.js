(() => {
  const service = window.HOMIOTDemoAuthService;
  const byId = (id) => document.getElementById(id);
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const rememberedEmailKey = 'homiot.demo.remembered-email';
  let verificationKind = null;
  let countdownTimer = null;
  let loginLockoutTimer = null;

  function routeTo(route) {
    if (typeof window.setRoute === 'function') window.setRoute(route);
    else window.location.hash = route;
  }

  function showMessage(id, message, isError = false) {
    const target = byId(id);
    if (!target) return;
    target.textContent = message;
    target.classList.toggle('is-error', Boolean(message) && isError);
    target.classList.toggle('is-success', Boolean(message) && !isError);
  }

  function setFieldError(input, message, errorId = `${input.id}-error`) {
    const error = byId(errorId);
    input.classList.toggle('has-error', Boolean(message));
    if (message) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
    if (error) error.textContent = message;
  }

  function setLoading(form, loading, label) {
    form.dataset.submitting = String(loading);
    const button = form.querySelector('.auth-submit');
    if (!button) return;
    button.disabled = loading;
    button.classList.toggle('is-loading', loading);
    button.setAttribute('aria-busy', String(loading));
    const text = button.querySelector('span');
    if (text) {
      if (loading) {
        button.dataset.idleLabel = text.textContent;
        text.textContent = label;
      } else {
        text.textContent = button.dataset.idleLabel || text.textContent;
        delete button.dataset.idleLabel;
      }
    }
  }

  function formatLockoutTime(milliseconds) {
    const totalSeconds = Math.max(1, Math.ceil(milliseconds / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    if (minutes > 0) return `${minutes}m ${String(seconds).padStart(2, '0')}s`;
    return `${seconds}s`;
  }

  function syncLoginLockout() {
    const form = byId('login-form');
    const button = form?.querySelector('.auth-submit');
    if (!form || !button || !service?.getLoginLockout) return;
    try {
      const state = service.getLoginLockout();
      if (state.locked) {
        button.disabled = true;
        showMessage('login-message', `Too many unsuccessful sign-in attempts. Try again in ${formatLockoutTime(state.remainingMs)}.`, true);
        byId('login-message').dataset.lockout = 'true';
        if (!loginLockoutTimer) loginLockoutTimer = window.setInterval(syncLoginLockout, 1000);
        return;
      }

      window.clearInterval(loginLockoutTimer);
      loginLockoutTimer = null;
      button.disabled = form.dataset.submitting === 'true';
      const message = byId('login-message');
      if (message?.dataset.lockout === 'true') {
        delete message.dataset.lockout;
        showMessage('login-message', '');
      }
    } catch (error) {
      button.disabled = true;
      showMessage('login-message', error instanceof Error ? error.message : 'Sign-in protection could not be checked.', true);
    }
  }

  function showDemoCode(code) {
    byId('auth-demo-code').innerHTML = `Demo code (not sent): <strong>${code}</strong>`;
  }

  function maskContact(contact, kind) {
    if (kind === 'email') {
      const [name, domain] = contact.split('@');
      return `${name.slice(0, 1)}${'*'.repeat(Math.max(2, Math.min(8, name.length - 1)))}@${domain}`;
    }
    return `${contact.slice(0, 3)} ${'*'.repeat(Math.max(4, contact.length - 7))} ${contact.slice(-4)}`;
  }

  function beginCountdown(resendAt) {
    window.clearInterval(countdownTimer);
    const button = byId('resend-otp');
    const initialSeconds = Math.max(0, Math.ceil((resendAt - Date.now()) / 1000));
    button.innerHTML = `Resend in <span id="resend-countdown">${initialSeconds}</span>s`;
    const update = () => {
      const seconds = Math.max(0, Math.ceil((resendAt - Date.now()) / 1000));
      button.disabled = seconds > 0;
      if (seconds > 0) {
        byId('resend-countdown').textContent = String(seconds);
      } else {
        button.textContent = 'Resend code';
        window.clearInterval(countdownTimer);
      }
    };
    update();
    countdownTimer = window.setInterval(update, 1000);
  }

  function prepareVerification(kind, contact, result) {
    verificationKind = kind;
    byId('verify-kicker').textContent = kind === 'recovery' ? 'VERIFY YOUR EMAIL' : 'VERIFY YOUR CONTACT';
    byId('verify-title').innerHTML = kind === 'recovery'
      ? 'A quick<br><em>security check.</em>'
      : 'One last<br><em>little check.</em>';
    byId('verify-description').textContent = kind === 'recovery'
      ? 'Enter the six-digit demo code to continue resetting your password.'
      : 'Enter the six-digit demo code to finish creating your account.';
    byId('verify-submit-label').textContent = kind === 'recovery' ? 'Verify & reset password' : 'Verify & continue';
    byId('change-contact').textContent = kind === 'recovery' ? 'Change email' : 'Change email or mobile';
    byId('verify-destination').textContent = `Code for ${maskContact(contact, kind === 'recovery' ? 'email' : byId('signup-method').value)}.`;
    showDemoCode(result.code);
    document.querySelectorAll('[data-otp-digit]').forEach((input) => {
      input.value = '';
      setFieldError(input, '');
    });
    showMessage('otp-error', '');
    showMessage('verify-message', '');
    routeTo('verify');
    beginCountdown(result.resendAt);
    window.setTimeout(() => document.querySelector('[data-otp-digit]')?.focus(), 0);
  }

  function setProfile(account) {
    const settings = window.SmartNestSettingsService;
    if (!settings) throw new Error('The local profile service is unavailable.');
    const currentProfile = settings.getSnapshot().profile;
    settings.saveProfile({
      ...currentProfile,
      name: account.name,
      email: account.email,
      phone: account.phone,
    });
  }

  function notifyProfileSaveFailure(error) {
    console.error('The verified demo account could not update the local profile.', error);
    if (typeof window.showToast === 'function') {
      window.showToast('Signed in, but the local profile could not be updated. Check profile settings.');
    }
  }

  async function submitRegistration(form) {
    const name = byId('signup-name');
    const email = byId('signup-email');
    const phone = byId('signup-phone');
    const password = byId('signup-password');
    const confirmation = byId('signup-confirm');
    const terms = byId('signup-terms');
    const callingCode = byId('signup-country').value;
    const normalizedEmail = email.value.trim().toLowerCase();
    const digits = phone.value.replace(/\D/g, '');
    const errors = {
      name: name.value.trim() ? '' : 'Enter your full name.',
      email: emailPattern.test(normalizedEmail) ? '' : 'Enter a valid email address.',
      phone: digits.length >= 7 && digits.length <= 15 ? '' : 'Enter a valid mobile number with 7 to 15 digits.',
      password: service.validatePassword(password.value),
      confirmation: confirmation.value === password.value && confirmation.value ? '' : 'Passwords do not match.',
      terms: terms.checked ? '' : 'Agree to the terms to create a demo account.',
    };
    setFieldError(name, errors.name);
    setFieldError(email, errors.email);
    setFieldError(phone, errors.phone);
    setFieldError(password, errors.password);
    setFieldError(confirmation, errors.confirmation);
    setFieldError(terms, errors.terms, 'signup-terms-error');
    if (Object.values(errors).some(Boolean)) {
      showMessage('signup-message', 'Check the highlighted fields and try again.', true);
      return;
    }

    setLoading(form, true, 'Preparing demo code…');
    try {
      const destinationKind = byId('signup-method').value;
      const fullPhone = `${callingCode} ${phone.value.trim()}`;
      const result = await service.beginRegistration({
        name: name.value.trim(),
        email: normalizedEmail,
        phone: fullPhone,
        password: password.value,
      });
      password.value = '';
      confirmation.value = '';
      prepareVerification('registration', destinationKind === 'email' ? normalizedEmail : fullPhone, result);
    } catch (error) {
      showMessage('signup-message', error instanceof Error ? error.message : 'The demo account could not be created.', true);
    } finally {
      setLoading(form, false);
    }
  }

  async function submitLogin(form) {
    const email = byId('login-email');
    const password = byId('login-password');
    const identifier = email.value.trim();
    const passwordError = password.value ? '' : 'Enter your password.';
    setFieldError(email, '');
    setFieldError(password, passwordError);
    if (!identifier || passwordError) {
      showMessage('login-message', 'Check the highlighted fields and try again.', true);
      return;
    }

    setLoading(form, true, 'Signing in…');
    try {
      const account = await service.login(identifier, password.value);
      password.value = '';
      let rememberWarning = '';
      try {
        if (byId('remember-me').checked) localStorage.setItem(rememberedEmailKey, account.email);
        else localStorage.removeItem(rememberedEmailKey);
      } catch (error) {
        console.error('The remembered email preference could not be saved.', error);
        rememberWarning = ' Your email preference could not be saved.';
      }
      try {
        setProfile(account);
      } catch (error) {
        notifyProfileSaveFailure(error);
      }
      showMessage('login-message', `Demo sign-in successful.${rememberWarning}`);
      if (rememberWarning && typeof window.showToast === 'function') {
        window.showToast('Signed in, but your remembered email preference could not be saved.');
      }
      routeTo('dashboard');
    } catch (error) {
      showMessage('login-message', error instanceof Error ? error.message : 'Sign-in failed.', true);
    } finally {
      setLoading(form, false);
      syncLoginLockout();
    }
  }

  async function submitVerification(form) {
    const digits = [...document.querySelectorAll('[data-otp-digit]')];
    const code = digits.map((input) => input.value).join('');
    if (!/^\d{6}$/.test(code)) {
      showMessage('otp-error', 'Enter all six digits.');
      digits.find((input) => !input.value)?.focus();
      return;
    }
    showMessage('otp-error', '');
    setLoading(form, true, 'Checking code…');
    try {
      const result = service.verify(code);
      if (result.type === 'registration') {
        try {
          setProfile(result.account);
        } catch (error) {
          notifyProfileSaveFailure(error);
        }
        routeTo('dashboard');
        if (typeof window.showToast === 'function') window.showToast('Demo account verified. No email or SMS was sent.');
      } else {
        byId('reset-password').value = '';
        byId('reset-confirm').value = '';
        routeTo('reset');
      }
    } catch (error) {
      showMessage('otp-error', error instanceof Error ? error.message : 'Verification failed.');
      showMessage('verify-message', '', true);
    } finally {
      setLoading(form, false);
    }
  }

  function submitRecovery(form) {
    const email = byId('forgot-email');
    const normalizedEmail = email.value.trim().toLowerCase();
    const errorMessage = emailPattern.test(normalizedEmail) ? '' : 'Enter a valid email address.';
    setFieldError(email, errorMessage);
    if (errorMessage) {
      showMessage('forgot-message', 'Check your email address and try again.', true);
      return;
    }
    setLoading(form, true, 'Preparing demo code…');
    try {
      const result = service.beginRecovery(normalizedEmail);
      prepareVerification('recovery', normalizedEmail, result);
    } catch (error) {
      showMessage('forgot-message', error instanceof Error ? error.message : 'The recovery code could not be created.', true);
    } finally {
      setLoading(form, false);
    }
  }

  async function submitPasswordReset(form) {
    const password = byId('reset-password');
    const confirmation = byId('reset-confirm');
    const passwordError = service.validatePassword(password.value);
    const confirmationError = confirmation.value === password.value && confirmation.value ? '' : 'Passwords do not match.';
    setFieldError(password, passwordError);
    setFieldError(confirmation, confirmationError);
    if (passwordError || confirmationError) {
      showMessage('reset-message', 'Check the highlighted fields and try again.', true);
      return;
    }

    setLoading(form, true, 'Updating password…');
    try {
      await service.resetPassword(password.value);
      byId('login-email').value = byId('forgot-email').value.trim().toLowerCase();
      byId('login-password').value = '';
      routeTo('login');
      showMessage('login-message', 'Demo password updated. Sign in with your new password.');
    } catch (error) {
      showMessage('reset-message', error instanceof Error ? error.message : 'The password could not be updated.', true);
    } finally {
      setLoading(form, false);
    }
  }

  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!form.matches('#signup-form, #login-form, #verify-form, #forgot-form, #reset-form')) return;
    event.preventDefault();
    if (form.dataset.submitting === 'true') return;
    if (form.id === 'signup-form') submitRegistration(form);
    else if (form.id === 'login-form') submitLogin(form);
    else if (form.id === 'verify-form') submitVerification(form);
    else if (form.id === 'forgot-form') submitRecovery(form);
    else submitPasswordReset(form);
  });

  window.addEventListener('app-route-change', (event) => {
    if (event.detail?.route === 'login') syncLoginLockout();
  });
  window.addEventListener('storage', (event) => {
    if (event.key === 'homiot.demo.login-attempts') syncLoginLockout();
  });

  document.addEventListener('click', (event) => {
    const legalLink = event.target.closest('[data-legal-link]');
    if (legalLink) {
      event.preventDefault();
      const isPrivacy = legalLink.dataset.legalLink === 'Privacy Policy';
      byId('auth-legal-title').textContent = legalLink.dataset.legalLink;
      byId('auth-legal-terms').hidden = isPrivacy;
      byId('auth-legal-privacy').hidden = !isPrivacy;
      byId('auth-legal-dialog').showModal();
      return;
    }
    if (event.target.closest('[data-legal-close]')) {
      byId('auth-legal-dialog').close();
      return;
    }
    const toggle = event.target.closest('[data-password-toggle]');
    if (toggle) {
      const input = byId(toggle.dataset.passwordToggle);
      const visible = input.type === 'password';
      input.type = visible ? 'text' : 'password';
      toggle.setAttribute('aria-pressed', String(visible));
      toggle.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
      input.focus();
      return;
    }
    if (event.target.closest('[data-auth-google]')) {
      showMessage('google-message', 'Google sign-in is unavailable: no Google identity provider is connected.', true);
      return;
    }
    if (event.target.closest('[data-flow-action="auth-back"]')) {
      routeTo(verificationKind === 'recovery' ? 'forgot' : 'signup');
      return;
    }
    if (event.target.closest('[data-flow-action="change-contact"]')) {
      routeTo(verificationKind === 'recovery' ? 'forgot' : 'signup');
      return;
    }
    if (event.target.closest('#resend-otp')) {
      try {
        const result = service.resend();
        showDemoCode(result.code);
        document.querySelectorAll('[data-otp-digit]').forEach((input) => { input.value = ''; });
        showMessage('otp-error', '');
        showMessage('verify-message', 'A new code was generated locally. Nothing was sent.');
        beginCountdown(result.resendAt);
        document.querySelector('[data-otp-digit]')?.focus();
      } catch (error) {
        showMessage('verify-message', error instanceof Error ? error.message : 'A new code could not be generated.', true);
      }
    }
  });

  document.addEventListener('input', (event) => {
    const input = event.target;
    if (input.matches('[data-otp-digit]')) {
      const otpFields = [...document.querySelectorAll('[data-otp-digit]')];
      const index = otpFields.indexOf(input);
      const pastedDigits = input.value.replace(/\D/g, '');
      if (pastedDigits.length > 1) {
        pastedDigits.slice(0, 6).split('').forEach((digit, digitIndex) => {
          if (otpFields[digitIndex]) otpFields[digitIndex].value = digit;
        });
        otpFields[Math.min(pastedDigits.length, 6) - 1]?.focus();
      } else {
        input.value = pastedDigits.slice(-1);
        if (input.value && otpFields[index + 1]) otpFields[index + 1].focus();
      }
      showMessage('otp-error', '');
      return;
    }
    if (input.id === 'signup-password' || input.id === 'reset-password') updateStrength(input);
    if (input.id.endsWith('-error')) return;
    if (input.getAttribute('aria-invalid') === 'true' && input.value.trim()) setFieldError(input, '');
    if (input.id === 'signup-password') {
      const confirmation = byId('signup-confirm');
      if (confirmation.value && confirmation.value !== input.value) setFieldError(confirmation, 'Passwords do not match.');
      else if (confirmation.value) setFieldError(confirmation, '');
    }
  });

  document.addEventListener('keydown', (event) => {
    const input = event.target;
    if (!input.matches('[data-otp-digit]')) return;
    const digits = [...document.querySelectorAll('[data-otp-digit]')];
    const index = digits.indexOf(input);
    if (event.key === 'Backspace' && !input.value && digits[index - 1]) {
      digits[index - 1].focus();
    } else if (event.key === 'ArrowLeft' && digits[index - 1]) {
      event.preventDefault();
      digits[index - 1].focus();
    } else if (event.key === 'ArrowRight' && digits[index + 1]) {
      event.preventDefault();
      digits[index + 1].focus();
    }
  });

  document.addEventListener('paste', (event) => {
    const input = event.target;
    if (!input.matches('[data-otp-digit]')) return;
    const pastedText = String(event.clipboardData?.getData('text') || '');
    const pastedDigits = pastedText.replace(/\D/g, '').slice(0, 6);
    if (!pastedDigits) return;
    event.preventDefault();
    const digits = [...document.querySelectorAll('[data-otp-digit]')];
    pastedDigits.split('').forEach((digit, index) => { digits[index].value = digit; });
    digits[Math.min(pastedDigits.length, 6) - 1]?.focus();
    showMessage('otp-error', '');
  });

  function updateStrength(input) {
    const container = document.querySelector(`[data-strength-for="${input.id}"]`);
    if (!container) return;
    const password = input.value;
    const checks = [
      password.length >= 8,
      /[a-z]/.test(password) && /[A-Z]/.test(password),
      /\d/.test(password),
      /[^A-Za-z0-9]/.test(password),
    ];
    const score = checks.filter(Boolean).length;
    const level = score <= 1 ? 'weak' : score <= 2 ? 'fair' : 'strong';
    container.dataset.level = password ? level : '';
    container.querySelectorAll('.strength-bars i').forEach((bar, index) => {
      bar.classList.toggle('is-filled', index < score);
    });
    const description = container.querySelector('small');
    description.textContent = password
      ? `${level[0].toUpperCase()}${level.slice(1)} password`
      : 'Use 8+ characters with uppercase, lowercase, and a number.';
    input.setAttribute('aria-describedby', `${input.id}-strength`);
    container.id = `${input.id}-strength`;
  }

  try {
    const rememberedEmail = localStorage.getItem(rememberedEmailKey);
    if (rememberedEmail && emailPattern.test(rememberedEmail)) {
      byId('login-email').value = rememberedEmail;
      byId('remember-me').checked = true;
    }
  } catch (error) {
    console.error('The remembered email preference could not be loaded.', error);
    showMessage('login-message', 'The remembered email preference could not be loaded.', true);
  }
  syncLoginLockout();
})();
